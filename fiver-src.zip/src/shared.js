/* ---------- SHARED LAYER: Supabase (what students teach Fiver) + Google Places (the Teach search) ----------
   Only on the Fiver website (GitHub Pages). Inside claude.ai, or if either service fails, the app carries on with what is on the phone.
   Keys here are the public ones (Supabase publishable key, a Google key restricted to the site). The Supabase secret key is never in the app. Photos are never uploaded. */
const SB_URL="https://fctqyxhxbxoojejcyfon.supabase.co";
const SB_KEY="sb_publishable_WLXyQ-ETrW3aQ3k_C9oIJw_Bi79zZU5";
const GP_KEY="AIzaSyDlV1NllOA93DmFjt7bcc8x5u-s70KNg2g"; // restricted to https://oliviagallego.github.io/* — works nowhere else
const ON_SITE=(()=>{try{return !(window.claude&&window.claude.use)&&typeof fetch==="function"&&(/github\.io$/.test(location.hostname)||localStorage.getItem("fiver.shared")==="1");}catch(e){return false;}})();
const DEVICE_ID=(()=>{try{let d=localStorage.getItem("fiver.device");if(!d){d=(crypto&&crypto.randomUUID?crypto.randomUUID():Math.random().toString(36).slice(2)+Date.now().toString(36));localStorage.setItem("fiver.device",d);}return d;}catch(e){return "anon";}})();
const shared={rows:[],places:[],at:0,ok:null,loading:false};
function fetchT(url,opts,ms){const ctl=typeof AbortController==="function"?new AbortController():null;const timer=ctl?setTimeout(()=>ctl.abort(),ms):null;
  return fetch(url,Object.assign({},opts,{signal:ctl?ctl.signal:undefined})).finally(()=>{if(timer)clearTimeout(timer);});}
const SB_HEADERS={apikey:SB_KEY,Authorization:"Bearer "+SB_KEY,"Content-Type":"application/json"};
/* A contribution row → a place the ranker understands. Older than 30 days: "checked N days ago" and a lower rank. */
function sharedPlace(r){
  const age=Math.max(0,Math.floor((Date.now()-new Date(r.created_at).getTime())/86400000));
  const items=Array.isArray(r.items)?r.items.slice(0,60):[];
  const base={id:"sb-"+r.id,name:String(r.place_name||"Somewhere").slice(0,48),lat:Number(r.lat),lon:Number(r.lon),addr:String(r.address||"").slice(0,80),status:"added",addedBy:String(r.added_by||"a student").slice(0,24),shared:true,age,placeId:r.place_id||"",coordSource:r.coord_source||""};
  if(r.kind==="event"){const s=r.starts_at?new Date(r.starts_at):null,e=r.ends_at?new Date(r.ends_at):null;if(!s||isNaN(s))return null;
    const hhmm=d=>String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");const date=s.getFullYear()+"-"+String(s.getMonth()+1).padStart(2,"0")+"-"+String(s.getDate()).padStart(2,"0");
    return Object.assign(base,{when:{date,start:hhmm(s),end:e&&!isNaN(e)?hhmm(e):addHours(hhmm(s),2)},offers:[{cat:"free",item:items[0]&&items[0].item||"free food",price:0,status:"added",tags:[]}],why:"Added from an invite by "+base.addedBy+"."});}
  const offers=items.filter(x=>x&&x.item&&typeof x.price==="number"&&x.price>=0&&x.price<=15).map(x=>({cat:CATS.some(c=>c.id===x.cat)?x.cat:"snack",item:String(x.item).slice(0,60),price:Math.round(x.price*100)/100,status:"added",tags:Array.isArray(x.diet)?x.diet.filter(t=>typeof t==="string"):[]}));
  if(!offers.length||isNaN(base.lat)||isNaN(base.lon))return null;
  return Object.assign(base,{hoursUnknown:true,offers,why:"Taught to Fiver by "+base.addedBy+(age>30?" · checked "+age+" days ago":"")+". Hours unknown. Not verified yet."});
}
/* Read everything 'live' when Results opens (3 s, then we stop waiting). Mine stay local, so they are skipped here. */
async function loadShared(force){
  if(!ON_SITE||shared.loading||(!force&&Date.now()-shared.at<60000))return;
  shared.loading=true;
  try{const res=await fetchT(SB_URL+"/rest/v1/contributions?select=id,created_at,kind,place_name,address,lat,lon,items,starts_at,ends_at,added_by,device_id,status,place_id,coord_source&status=eq.live&order=created_at.desc&limit=500",{headers:SB_HEADERS},3000);
    if(!res.ok)throw new Error("sb "+res.status);const rows=await res.json();
    const before=shared.places.map(p=>p.id).join(",");
    shared.rows=rows;shared.places=rows.filter(r=>r.device_id!==DEVICE_ID).map(sharedPlace).filter(Boolean);shared.ok=true;shared.at=Date.now();
    if(before!==shared.places.map(p=>p.id).join(",")&&state.step===S.results&&!document.getElementById("sheetHost").firstChild)render();}
  catch(e){shared.ok=false;shared.at=Date.now();}
  finally{shared.loading=false;}
}
/* Save a contribution. Returns true when everyone near UCL can see it; false means it stayed on this phone. Never the photo. */
async function saveShared(row){
  if(!ON_SITE)return false;
  try{const res=await fetchT(SB_URL+"/rest/v1/contributions",{method:"POST",headers:Object.assign({Prefer:"return=minimal"},SB_HEADERS),body:JSON.stringify(Object.assign({device_id:DEVICE_ID,status:"live"},row))},5000);
    return res.ok;}
  catch(e){return false;}
}
/* ---------- Google Places (New): autocomplete, details, nearby. Photon is plan B, typing is plan C. ---------- */
let gpSession=null;
function gpToken(){if(!gpSession)gpSession=(crypto&&crypto.randomUUID?crypto.randomUUID():Math.random().toString(36).slice(2));return gpSession;}
const GP_FOOD=new Set(["cafe","coffee_shop","restaurant","bakery","fast_food_restaurant","sandwich_shop","meal_takeaway","supermarket","convenience_store","grocery_store","food","store","bar","pub","food_store","dessert_shop","ice_cream_shop","juice_shop","tea_house","pizza_restaurant","chinese_restaurant","indian_restaurant","italian_restaurant","japanese_restaurant","sushi_restaurant","vegan_restaurant","vegetarian_restaurant","meal_delivery","breakfast_restaurant","brunch_restaurant","deli","food_court","market","shopping_mall","train_station","subway_station","transit_station","university","library","point_of_interest","establishment"]);
async function gpAutocomplete(q,bias){ // → rows {place,name,sub,placeId,src:"google"} (no coordinates yet)
  if(!ON_SITE)throw {code:"offline"};
  const body={input:q,sessionToken:gpToken(),regionCode:"gb",languageCode:"en",includedRegionCodes:["gb"],locationBias:{circle:{center:{latitude:bias.lat,longitude:bias.lon},radius:2000}}};
  const res=await fetchT("https://places.googleapis.com/v1/places:autocomplete",{method:"POST",headers:{"Content-Type":"application/json","X-Goog-Api-Key":GP_KEY},body:JSON.stringify(body)},5000);
  if(!res.ok)throw {code:"google "+res.status};
  const j=await res.json();const rows=[];
  for(const s of (j.suggestions||[])){const p=s.placePrediction;if(!p||!p.placeId)continue;const types=p.types||[];
    const place=types.some(t=>GP_FOOD.has(t))&&!types.some(t=>["street_address","route","premise","subpremise","postal_code","locality","sublocality","neighborhood","geocode"].includes(t)&&!types.includes("establishment"));
    rows.push({place,name:(p.structuredFormat&&p.structuredFormat.mainText&&p.structuredFormat.mainText.text)||(p.text&&p.text.text)||"",sub:(p.structuredFormat&&p.structuredFormat.secondaryText&&p.structuredFormat.secondaryText.text)||"",placeId:p.placeId,src:"google"});}
  return rows.sort((a,b)=>(b.place?1:0)-(a.place?1:0)).slice(0,8);
}
async function gpDetails(placeId){ // → {lat,lon,addr}; ends the autocomplete session
  const tok=gpToken();gpSession=null;
  const res=await fetchT("https://places.googleapis.com/v1/places/"+encodeURIComponent(placeId)+"?sessionToken="+encodeURIComponent(tok)+"&languageCode=en&regionCode=gb",{headers:{"X-Goog-Api-Key":GP_KEY,"X-Goog-FieldMask":"location,shortFormattedAddress"}},5000);
  if(!res.ok)throw {code:"google "+res.status};const j=await res.json();
  if(!j.location)throw {code:"google nolocation"};return {lat:j.location.latitude,lon:j.location.longitude,addr:j.shortFormattedAddress||""};
}
async function gpNearby(at,radius){ // the food places within ~100 m, closest first
  if(!ON_SITE)return [];
  try{const body={includedTypes:["cafe","coffee_shop","restaurant","bakery","fast_food_restaurant","sandwich_shop","meal_takeaway","supermarket","convenience_store","grocery_store","dessert_shop","tea_house","pub"],maxResultCount:12,rankPreference:"DISTANCE",languageCode:"en",regionCode:"gb",locationRestriction:{circle:{center:{latitude:at.lat,longitude:at.lon},radius}}};
    const res=await fetchT("https://places.googleapis.com/v1/places:searchNearby",{method:"POST",headers:{"Content-Type":"application/json","X-Goog-Api-Key":GP_KEY,"X-Goog-FieldMask":"places.id,places.displayName,places.location,places.shortFormattedAddress"},body:JSON.stringify(body)},5000);
    if(!res.ok)return [];const j=await res.json();
    return (j.places||[]).filter(p=>p.location&&p.displayName).map(p=>({place:true,name:p.displayName.text||"",sub:p.shortFormattedAddress||"",lat:p.location.latitude,lon:p.location.longitude,placeId:p.id,src:"google"}));}
  catch(e){return [];}
}
