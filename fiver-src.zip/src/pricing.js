/* ---------- PRICING ---------- */
function cardName(id){return (CARDS.find(c=>c.id===id)||{}).name||id;}
function r2(v){return Math.round(v*100)/100;}
// price ladder for an offer: [{label, price, mine:boolean, note, promo, status}]
function ladder(p,o,t){
  const rows=[];
  if(o.cat==="deal"&&p.deal){const d=DEALS[p.deal];rows.push({label:"No card",price:d.base,mine:true,status:d.status});
    for(const c in d.with)rows.push({label:cardName(c),price:d.with[c],mine:state.cards.has(c),status:d.status});
  }else{
    rows.push({label:o.price===0?"Everyone":"No card",price:o.price,mine:true,status:o.status});
    if(o.with)for(const c in o.with){const w=o.with[c];const ok=!w.days||w.days.includes(t.day);rows.push({label:cardName(c),price:w.price,mine:state.cards.has(c)&&ok,status:o.status,note:w.label+(ok?"":" (not today)"),promo:!!w.promo});}
    if(p.disc&&o.price>0)for(const c in p.disc){if(o.with&&o.with[c]&&o.with[c].price<=r2(o.price*(1-p.disc[c])))continue;rows.push({label:cardName(c),price:r2(o.price*(1-p.disc[c])),mine:state.cards.has(c),status:o.status,note:Math.round(p.disc[c]*100)+"% off everything with "+cardName(c)});}
    // end-of-day windows: Pret's last hour, itsu's and Wasabi's last half hour (no card, not on top of a card)
    if(p.last&&o.price>0&&p.last.cats.includes(o.cat)&&t){const w=openWindow(p,t.day);
      if(w&&t.minutes>=w[1]-p.last.mins&&t.minutes<w[1])rows.push({label:"Last "+p.last.mins+" min",price:r2(o.price*(1-p.last.off)),mine:true,status:o.status,time:true,note:Math.round(p.last.off*100)+"% off in the last "+p.last.mins+" minutes before closing: whatever is left"});}
  }
  return rows;
}
function bestPrice(p,o,t){
  const rows=ladder(p,o,t).filter(r=>r.mine&&!r.promo);
  const best=rows.reduce((a,b)=>b.price<a.price?b:a,rows[0]);
  return {price:best.price,label:best.label==="No card"||best.label==="Everyone"?"":best.time?"in the last "+(best.label.replace("Last ","")):"with "+best.label,status:best.status,time:!!best.time};
}
/* ---------- DIET ---------- */
// What we know about an item vs what the student avoids. hide = we know it won't work; ask = we don't know, ask staff.
function dietCheck(o){
  const tags=o.tags||[];const ask=[];
  for(const id of state.diet){const d=DIETS.find(x=>x.id===id);if(!d)continue;
    if(d.no.some(x=>tags.includes(x))){if(d.soft&&d.soft.some(x=>tags.includes(x))){ask.push(d.name.toLowerCase()+": alt milk, ask");continue;}return {hide:true,why:d.name};}
    if(!d.ok.some(x=>tags.includes(x)))ask.push(d.name.toLowerCase()+": ask staff");
  }
  return {hide:false,ask};
}
function dietLabel(o){const d=dietCheck(o);if(d.hide)return "not for you ("+d.why.toLowerCase()+")";return d.ask.length?d.ask.join(" · "):(state.diet.size?"fits your diet, on what we know":"");}
