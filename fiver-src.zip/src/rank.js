/* ---------- RANK ---------- */
function metres(a,b){const R=6371000,toR=x=>x*Math.PI/180;const dLat=toR(b.lat-a.lat),dLon=toR(b.lon-a.lon);const s=Math.sin(dLat/2)**2+Math.cos(toR(a.lat))*Math.cos(toR(b.lat))*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(s));}
let _uniPlaces=null;
/* Chains are for everyone: a branch shows to whoever is near it. Only uni_only offers depend on state.uni. */
const CHAIN_WHY={pret:"50% off all food in the last hour before closing (most shops; whatever is left).",wasabi:"30% off whatever is left in the last 30 minutes.",tortilla:"Burritos are £9+, but the sides add up to a cheap hot snack. Card only.",
  gails:"Everything is 15–20% more if you sit in. Own cup: 20p off drinks.",black_sheep:"20% off everything for students. Oat milk free.",itsu:"Cold food is 50% off in the last half hour.",caffe_nero:"UK average prices; central London runs 15–25% higher.",
  greggs:"Shelf prices from a fan site; London may be a step higher.",costa:"Drink prices from a station board; a street Costa is usually a touch cheaper.",starbucks:"UK price tracker; London in line or a touch higher."};
const PC_RX=/\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\b/;
function pcOf(a){const m=PC_RX.exec(String(a||""));return m?m[1]+" "+m[2]:null;}
function chainKey(n){const s=String(n||"").toLowerCase().replace(/[’'`.]/g,"");if(/^m ?& ?s|marks/.test(s))return "ms";if(/^co-?op/.test(s))return "coop";if(/waitrose/.test(s))return "waitrose";if(/sainsbury/.test(s))return "sains";if(/black sheep/.test(s))return "bsc";if(/nero/.test(s))return "nero";return s.split(/[\s-]+/)[0];}
function houseNo(a){const m=/^\D*?(\d+)/.exec(String(a||""));return m?m[1]:null;}
function dupOfPlaces(b,nm){ // already in the hand-made catalogue? same place_id, or the same chain at the same postcode / within 40 m / same door number or station
  const kb=chainKey(nm),pb=b.pc||pcOf(b.addr),nb=houseNo(b.addr),sb=/(\w+) station/.exec((nm+" "+b.addr).toLowerCase());
  return PLACES.some(p=>{if(b.placeId&&p.placeId===b.placeId)return true;if(chainKey(p.name)!==kb)return false;const pp=pcOf(p.addr),np=houseNo(p.addr);
    if(pp&&pb&&pp===pb)return true; // same chain at the same postcode: the same shop, whatever the pin says (252 Tottenham Court Road, the Brunswick Centre)
    const m=metres(p,b);if(m<40)return true;if(m>150)return false;
    if(np&&nb&&np===nb)return true;const sp=/(\w+) station/.exec((p.name+" "+p.addr).toLowerCase());if(sp&&sb&&sp[1]===sb[1])return true;return false;});
}
function uniPlaces(){ // the other universities' outlets and every chain branch in the catalogue (UCL campuses too), built once from the templates in PLACES
  if(_uniPlaces)return _uniPlaces;
  const byId={};for(const p of PLACES.concat(typeof CHAIN_TEMPLATES!=="undefined"?CHAIN_TEMPLATES:[]))byId[p.id]=p;const out=[];
  for(const p of UNI_PLACES)out.push(p);
  for(const b of UNI_BRANCHES){const t=b.tpl?byId[b.tpl]:null;if(b.tpl&&!t)continue;
    const nm=b.name||(t&&t.name)||"";
    if(dupOfPlaces(b,nm))continue;
    const c=t?Object.assign({},t,{id:b.id,name:nm,lat:b.lat,lon:b.lon,addr:b.addr,placeId:b.placeId,coordSource:"google",cachedAt:UNIS_CACHED_AT,uniBranch:b.campus,chain:b.chain,status:"shop",why:CHAIN_WHY[b.chain]||"Chain prices from another branch; the board here may differ. Snap it to fix."})
                :{id:b.id,name:nm,lat:b.lat,lon:b.lon,addr:b.addr,placeId:b.placeId,coordSource:"google",cachedAt:UNIS_CACHED_AT,uniBranch:b.campus,chain:b.chain||null,independent:!!b.independent,status:"shop",offers:[],unpriced:true,why:"Price not checked. Snap the menu →"};
    if(b.hours)c.hours=b.hours;else{delete c.hours;c.hoursUnknown=true;}
    out.push(c);}
  return _uniPlaces=out;
}
function uniOk(p){return !p.uni||p.audience!=="uni_only"||p.uni===state.uni;}
function allPlaces(){return PLACES.concat(state.added,shared.places,uniPlaces().filter(uniOk));}
/* "Something specific": words typed or tapped, matched against item names. Generic words are ignored. */
/* Typos: every word is checked against the words on the menus; a near miss (edit distance ≤ 2) is corrected. */
let VOCAB=null;
function vocab(){if(VOCAB)return VOCAB;const set=new Set();const add=s=>String(s).toLowerCase().replace(/[^a-z0-9\s]/g," ").split(/\s+/).forEach(w=>{if(w.length>2)set.add(w);});
  for(const p of PLACES){add(p.name);for(const o of p.offers)add(o.item);}for(const k in SPECIFIC)SPECIFIC[k].forEach(add);for(const k in SYN)if(SYN[k])add(SYN[k]);
  return VOCAB=[...set];}
function lev(a,b){ // edit distance where a swapped pair ("dael") counts as one slip
  const m=a.length,n=b.length;if(!m)return n;if(!n)return m;const D=[];for(let i=0;i<=m;i++){D[i]=[i];}for(let j=1;j<=n;j++)D[0][j]=j;
  for(let i=1;i<=m;i++)for(let j=1;j<=n;j++){const c=a[i-1]===b[j-1]?0:1;D[i][j]=Math.min(D[i-1][j]+1,D[i][j-1]+1,D[i-1][j-1]+c);if(i>1&&j>1&&a[i-1]===b[j-2]&&a[i-2]===b[j-1])D[i][j]=Math.min(D[i][j],D[i-2][j-2]+1);}
  return D[m][n];}
function nearest(w){if(w.length<4)return w;let best=w,bd=w.length<=5?1:2;for(const v of vocab()){if(Math.abs(v.length-w.length)>bd)continue;const d=lev(w,v);if(d<bd||(d===bd&&v.startsWith(w[0])&&best===w)){bd=d;best=v;if(d===0)break;}}return best;}
function fuzzyQ(q){return String(q||"").toLowerCase().replace(/[^a-z0-9£.\s]/g," ").split(/\s+/).filter(Boolean).map(w=>SYN[w]!==undefined?SYN[w]:(vocab().includes(w)?w:nearest(w))).filter(Boolean).join(" ").trim();}
function qTokens(q){return fuzzyQ(q).split(/\s+/).filter(t=>t&&t.length>1);}
function qMatch(o,q,p){const toks=qTokens(q);if(!toks.length)return true;const name=((o.item||"")+" "+(p?p.name:"")).toLowerCase();return toks.every(t=>name.includes(t));}
function eatMins(o){return o.cat==="deal"||o.cat==="coffee"||o.cat==="snack"?6:12;}
function rank(){
  const t=selectedTime();const here=state.where||VENUES[0];
  const rows=[],unpriced=[];let hidden=0;
  for(const p of allPlaces()){
    let offers=p.offers.filter(o=>state.cats.has(o.cat)&&(!o.uniOnly||p.uni===state.uni));
    offers=offers.filter(o=>!o.until||t.minutes<hm(o.until)).filter(o=>!o.from||t.minutes>=hm(o.from)).filter(o=>!o.needs||state.cards.has(o.needs));
    if(state.q)offers=offers.filter(o=>qMatch(o,state.q,p));
    if(state.diet.size){const keep=offers.filter(o=>!dietCheck(o).hide);hidden+=offers.length-keep.length;offers=keep;}
    const o=isOpen(p,t);const m=metres(here,p);const walk=Math.max(1,Math.round(m/80));
    if(!offers.length){if(p.unpriced&&state.cats.size&&!state.q&&o.open&&walk<=Math.min(state.mins,MAX_WALK))unpriced.push({p,o,m,walk,unpriced:true,fits:false,t});continue;}
    let best=null;
    for(const of of offers){const bp=bestPrice(p,of,t);const dk=dietCheck(of);const sc=bp.price*10+(dk.ask.length?0.4:0);if(!best||sc<best.sc)best={of,pr:bp,sc,ask:dk.ask};}
    const eat=eatMins(best.of);const need=walk*2+eat;
    const fits=o.open&&best.pr.price<=state.budget+1e-9&&walk<=state.mins&&o.closesIn>walk;
    let score=best.pr.price*10+walk*0.6; if(best.of.cat==="free")score-=5; if(!p.ucl&&best.of.cat!=="deal")score+=0.5; if(best.ask.length)score+=0.3; if(p.age>30)score+=1.5; if(p.hoursUnknown&&!p.when)score+=0.8; // a place with checked hours wins a near tie
    const ladderRows=ladder(p,best.of,t);
    const saved=ladderRows.find(r=>r.label==="No card")?Math.max(0,(ladderRows.find(r=>r.label==="No card").price-best.pr.price)):0;
    rows.push({p,o,m,walk,eat,need,fits,score,of:best.of,pr:best.pr,ask:best.ask,saved,t});
  }
  const fit=rows.filter(r=>r.fits).sort((a,b)=>a.score-b.score);
  const rest=rows.filter(r=>!r.fits&&r.walk<=MAX_WALK).sort((a,b)=>(a.o.open===b.o.open?0:(a.o.open?-1:1))||a.score-b.score);
  unpriced.sort((a,b)=>a.walk-b.walk);
  return {fit,rest,unpriced,t,here,hidden};
}
// Why nothing fits, from the data: what would unlock the nearest cheap thing.
const MAX_WALK=45,MAX_BUDGET=15;
function unlock(r){
  const open=r.rest.filter(x=>x.o.open&&x.o.closesIn>x.walk);
  const out={};
  const money=open.filter(x=>x.walk<=state.mins&&x.pr.price<=MAX_BUDGET);if(money.length){const m=Math.min(...money.map(x=>x.pr.price));out.budget=Math.ceil(m*2)/2;out.budgetRow=money.find(x=>x.pr.price===m);out.budgetN=money.filter(x=>x.pr.price<=out.budget+1e-9).length;}
  const time=open.filter(x=>x.pr.price<=state.budget+1e-9&&x.walk<=MAX_WALK);if(time.length){const n=Math.min(...time.map(x=>x.walk));out.mins=Math.min(MAX_WALK,Math.ceil(n/5)*5);out.minsRow=time.find(x=>x.walk===n);out.minsN=time.filter(x=>x.walk<=out.mins).length;}
  if(!out.budget&&!out.mins){const both=open.filter(x=>x.walk<=MAX_WALK&&x.pr.price<=MAX_BUDGET).sort((a,b)=>a.walk-b.walk);if(both.length)out.both=both[0];}
  out.anyOpen=open.length>0;out.anyNear=open.some(x=>x.walk<=MAX_WALK&&x.pr.price<=MAX_BUDGET);
  if(state.q&&qTokens(state.q).length){const keep=state.q;state.q="";try{const r3=rank();if(r3.fit.length){out.noq=r3.fit[0];out.noqN=r3.fit.length;}}finally{state.q=keep;}}
  if(state.cats.size<CATS.length){const keep=state.cats;state.cats=new Set(CATS.map(c=>c.id));try{const r2=rank();if(r2.fit.length){out.cats=r2.fit[0];out.catsN=r2.fit.length;}}finally{state.cats=keep;}}
  const nearest=r.rest.slice().sort((a,b)=>a.walk-b.walk)[0];out.nearest=nearest;
  return out;
}

/* Group "£2 latte / £2 americano / …" into one line per place, card and price */
function shortItem(s){return String(s).toLowerCase().replace(/ \(.*?\)/g,"").replace(/^tall /,"");}
function groupDeals(list){
  const g={};
  for(const x of list){const k=x.p.name+"|"+(x.card||"")+"|"+x.price+"|"+(x.days||"");(g[k]=g[k]||{p:x.p,card:x.card,price:x.price,days:x.days,items:[]}).items.push(shortItem(x.item));}
  for(const k in g)g[k].items=[...new Set(g[k].items)];
  return Object.values(g).map(x=>({p:x.p,card:x.card,price:x.price,text:(x.price===0?"Free ":"£"+x.price.toFixed(2)+" ")+(x.items.length>2?x.items.slice(0,2).join(", ")+" and "+(x.items.length-2)+" more":x.items.join(", "))+" at "+x.p.name+(x.days?" on "+x.days.map(d=>DAYS[d]+"s").join(", "):"")}));
}
/* What a card unlocks, from the data (for the menu and the home screen) */
function cardUnlocks(c){
  const out=[];const seen=new Set();const add=s=>{if(!seen.has(s)){seen.add(s);out.push(s);}};
  for(const k in DEALS){const d=DEALS[k];if(d.with&&d.with[c]!=null){const ps=PLACES.filter(p=>p.deal===k);if(ps.length)add("Meal deal £"+d.with[c].toFixed(2)+" instead of £"+d.base.toFixed(2)+" at "+ps[0].name);}}
  const withs=[],needs=[];
  for(const p of PLACES){
    if(p.disc&&p.disc[c])add(Math.round(p.disc[c]*100)+"% off everything at "+p.name);
    for(const o of p.offers){if(o.with&&o.with[c]){const w=o.with[c];withs.push({p,card:c,price:w.price,item:o.item,days:w.days});}
      if(o.needs===c)needs.push({p,text:(o.price===0?"":"£"+o.price.toFixed(2)+": ")+o.item});}
    if(p.promos)for(const x of p.promos)if(x.card===c)add(x.label.replace(/ \((UNiDAYS|Student Beans)\)$/,"")+" at "+p.name);
  }
  const byItem={};for(const n of needs)(byItem[n.text]=byItem[n.text]||[]).push(n.p);
  for(const k in byItem){const ps=byItem[k];const ucl=ps.filter(p=>p.ucl).length;add(k+" at "+(ps.length>2&&ucl===ps.length?"every UCL café":ps.length>2?ps.length+" places":[...new Set(ps.map(p=>p.name))].join(", ")));}
  const cnt={};for(const x of withs)if(x.p.ucl){const k=x.item+"|"+x.price;cnt[k]=(cnt[k]||0)+1;}
  const EVERY={name:"every UCL café"};const seenU=new Set();const merged=[];
  for(const x of withs){const k=x.item+"|"+x.price;if(x.p.ucl&&cnt[k]>2){if(seenU.has(k))continue;seenU.add(k);merged.push(Object.assign({},x,{p:EVERY}));}else merged.push(x);}
  for(const g of groupDeals(merged))add(g.text);
  const card=CARDS.find(x=>x.id===c);if(card&&card.perk)add(card.perk);
  return out;
}
/* Today's time-boxed deals: card days + end-of-day windows */
function todayDeals(t){
  const withs=[];const promos=[];
  for(const p of PLACES){
    for(const o of p.offers)if(o.with)for(const c in o.with){const w=o.with[c];if(w.days&&w.days.includes(t.day))withs.push({p,card:c,price:w.price,item:o.item});}
    if(p.promos)for(const x of p.promos)if(x.days&&x.days.includes(t.day))promos.push({p,card:x.card,text:x.label.replace(/ \(.*\)$/,"")+" at "+p.name});
  }
  const seen=new Set();const cards=[];
  for(const g of groupDeals(withs)){const k=g.p.name.split(" ")[0]+g.card+g.price;if(seen.has(k))continue;seen.add(k);cards.push({p:g.p,card:g.card,text:g.text+" today",mine:state.cards.has(g.card)});}
  for(const x of promos){const k=x.p.name.split(" ")[0]+x.text;if(seen.has(k))continue;seen.add(k);cards.push({p:x.p,card:x.card,text:x.text+" today",mine:!x.card||state.cards.has(x.card)});}
  const late=[];const seenL=new Set();
  for(const p of PLACES)if(p.late){const o=isOpen(p,t);if(!o.open)continue;const k=p.name.split(" ")[0]+p.late;if(seenL.has(k))continue;seenL.add(k);late.push({p,text:p.late+" at "+p.name+(o.closes?" (closes "+o.closes+")":"")});}
  return {cards:cards.sort((a,b)=>(b.mine?1:0)-(a.mine?1:0)),late};
}
