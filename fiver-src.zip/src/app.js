
/* ---------- STATE ---------- */
const state={step:0,intro:0,uni:"ucl",where:null,cats:new Set(["hot","deal","free"]),q:"",budget:5,mins:30,dayOff:0,minute:null,cards:new Set(["unidays"]),diet:new Set(),note:"",name:"",added:[],setupDone:false,crumbs:0};
try{const s=JSON.parse(localStorage.getItem("fiver.v7")||localStorage.getItem("fiver.v6")||localStorage.getItem("fiver.v5")||localStorage.getItem("fiver.v4")||"{}");
  if(s.cards)state.cards=new Set(s.cards); if(s.cats)state.cats=new Set(s.cats); if(s.diet)state.diet=new Set(s.diet);
  if(typeof s.budget==="number")state.budget=s.budget; if(typeof s.mins==="number")state.mins=Math.min(45,s.mins); if(s.seenResults)state.seenResults=true;
  if(typeof s.name==="string")state.name=s.name; if(typeof s.note==="string")state.note=s.note;
  if(s.where&&typeof s.where.lat==="number")state.where=s.where; if(typeof s.uni==="string")state.uni=s.uni;
  if(Array.isArray(s.added))state.added=s.added; if(s.setupDone&&s.diet)state.setupDone=true; if(typeof s.crumbs==="number")state.crumbs=s.crumbs;
}catch(e){}
function persist(){try{localStorage.setItem("fiver.v7",JSON.stringify({cards:[...state.cards],cats:[...state.cats],diet:[...state.diet],budget:state.budget,mins:state.mins,name:state.name,note:state.note,where:state.where&&state.where.label!=="your location"?state.where:null,added:state.added,setupDone:state.setupDone,crumbs:state.crumbs,seenResults:!!state.seenResults,uni:state.uni}));}catch(e){}}
const UNI_LIST=UNIS.map(u=>({id:u.id,short:u.short,name:u.name})); // UCL first (the catalogue's order)
function uniShort(id){const u=UNI_LIST.find(x=>x.id===(id||state.uni));return u?u.short:"your uni";}
function uniMain(id){const u=UNIS.find(x=>x.id===(id||state.uni));if(!u)return null;return u.campuses[0]||null;}
function uniChips(id,sel){return '<div class="chips" id="'+id+'">'+UNI_LIST.map(u=>'<button type="button" class="chip'+(sel===u.id?" on":"")+'" data-uni="'+u.id+'">'+esc(u.short)+'</button>').join("")+'<button type="button" class="chip'+(sel==="other"?" on":"")+'" data-uni="other">Other</button></div>';}
function uniName(){return state.uni&&state.uni!=="other"&&UNI_LIST.find(x=>x.id===state.uni)?uniShort():null;} // null = Other / not chosen
function footText(){return "Made for "+(uniName()||"London")+" students · run by a rat with standards";}
function cardsFor(){return CARDS.filter(c=>!c.uni||c.uni===state.uni);} // each uni's own food app only for its students
function firstCardsFor(){const app=CARDS.find(c=>c.uni&&c.uni===state.uni);return ["unidays","beans",app?app.id:"totum","clubcard","clubpret","greggsapp"];}
function uniReply(id){return id==="ucl"?"UCL. My home turf.":id==="other"?"Somewhere new. I’ll learn it.":uniShort(id)+". Good choice. I know a few shortcuts.";}
/* Crumbs: recognition only, kept on this phone. No redeeming, no promises. */
const RANKS=[[150,"Bloomsbury legend"],[50,"Menu hunter"],[10,"Crumb finder"],[0,"New in town"]];
function rankName(n){return (RANKS.find(r=>n>=r[0])||RANKS[RANKS.length-1])[1];}
function addCrumbs(n){state.crumbs=(state.crumbs||0)+n;persist();}
const STEPS=["hello","where","results"];
const S={hello:0,where:1,results:2};
if(state.setupDone)state.step=state.where?S.results:S.where;
const UI={later:false,spec:false,bOther:false,mOther:false,lastFkey:""};
function getKey(){try{return localStorage.getItem("fiver.key")||"";}catch(e){return "";}}
const REDUCED=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
const RAT_BOX=[150,150];
/* Moment → line → pose. The code picks a row; it never pairs a line with a pose from another row.
   A moment with several rows rotates and never repeats the row used last time. Every one of the 42 drawings has a moment. */
const MOMENTS={
  pick:[["Found it{name}. Don’t tell the pigeons.","point"]],
  hot:[["Hot, cheap, and nobody’s watching. Go.","pizza"],["Hot, cheap, and nobody’s watching. Go.","a_pizza"]],
  deal:[["Meal deal. The Londoner’s love language.","bag"],["Meal deal. The Londoner’s love language.","a_sandwich"]],
  coffee:[["Caffeine under a fiver. You’re welcome.","a_coffee"]],
  snack:[["Snack sorted. Crumbs are mine.","a_croissant"]],
  sweet:[["Pudding first. I won’t tell.","a_icecream"]],
  fruit:[["An apple a day keeps the overdraft away.","a_apple"]],
  drink:[["Sip, walk, save.","a_backpack"]],
  library:[["Study fuel. Under a fiver, obviously.","a_books"]],
  free:[["Free. As in free. Go before the second-years find it.","ticket"]],
  card:[["You had this discount on your phone the whole time. I’m not angry. Just disappointed.","threeq"],["With your card it’s under a fiver. Told you I’d remember.","cheer"]],
  late:[["Closing-time price. Walk fast.","walk"]],
  deals:[["Today’s deals. I’ve already been shopping.","a_bags"]],
  budget:[["That’s more than a fiver. And I’d know.","s_pockets"]],
  time:[["Nothing under {b} within {m} min. Even I’m impressed, London.","s_shrug"]],
  far:[["East London? I’m still digging the tunnel.","s_peek"]],
  shut:[["Everything’s shut. So am I.{t}","sleep"]],
  loading:[["Sniffing around…","sniff"],["Asking the pigeons…","a_headphones"],["Hold on, I’m in the zone…","a_headphones"]],
  where:[["Where are you{name}?","a_map"]],
  back:[["Oh, you again. Hungry?","front"]],
  first:[["Here’s what’s open near you. Change anything below, I’ll keep up.","point"]],
  install:[["Pop me on your home screen. I’m small, I don’t take up much room.","s_sit"]],
  invite:[["Got an invite in your inbox? Paste it, I’ll read it.","a_laptop"]],
  support:[["Free food if money’s tight. One of each item, no questions.","s_sit"]]
};
const MOM={last:{},cur:{}};
function moment(key,ctx,vars){const rows=MOMENTS[key];let i;
  if(MOM.cur[key]&&MOM.cur[key].ctx===ctx)i=MOM.cur[key].i;else{i=rows.length>1?((MOM.last[key]==null?-1:MOM.last[key])+1)%rows.length:0;MOM.cur[key]={ctx,i};MOM.last[key]=i;}
  let line=rows[i][0];for(const k in (vars||{}))line=line.split("{"+k+"}").join(vars[k]);return {line,pose:rows[i][1]};}
const FRUITY=/apple|banana|fruit|salad|greens|porridge|oats|yogurt|yoghurt|granola|hummus|veg box|veggie pot/i;
const DRINKY=/bubble tea|boba|smoothie|juice|milkshake|frapp|iced tea|lemonade|kombucha/i;
function pickMoment(x,q){ // which row of the table fits this pick
  if(x.p.support)return "support";if(x.of.cat==="free")return "free";if(x.pr.time)return "late";
  const cardWin=x.saved>0&&x.pr.label&&x.pr.label!=="No card"&&x.pr.label!=="Everyone";if(cardWin)return "card";
  if(q)return "pick";
  if(/library/i.test((state.where||{}).label||"")||/library/i.test(x.p.name))return "library";
  if(DRINKY.test(x.of.item))return "drink";if(FRUITY.test(x.of.item))return "fruit";
  return MOMENTS[x.of.cat]?x.of.cat:"pick";}
function ratSize(k){const [w,h]=ARTW[k];const sc=Math.min(RAT_BOX[0]/w,RAT_BOX[1]/h,1);return [Math.round(w*sc),Math.round(h*sc)];}
const SVGCACHE={};
function svgOf(k,w,h,cls){ // the pose as inline SVG with an explicit box
  if(!SVGCACHE[k])SVGCACHE[k]=decodeURIComponent(ART[k].slice("data:image/svg+xml,".length)).replace(/^<svg /,'<svg aria-hidden="true" focusable="false" ');
  return SVGCACHE[k].replace(/^<svg /,'<svg class="rat '+(cls||"")+'" width="'+w+'" height="'+h+'" style="width:'+w+'px;height:'+h+'px" ');
}
function setRat(box,k){const [w,h]=ratSize(k);box.innerHTML=svgOf(k,w,h);box.dataset.pose=k;}
const WALK_SC=130/Math.max(ARTW.walk1[1],ARTW.walk2[1],ARTW.walk3[1],ARTW.walk4[1]); // every stride frame at the same scale, feet on the same line
function setWalk(box,n){const k="walk"+n;const [W,H]=ARTW[k];box.innerHTML=svgOf(k,Math.round(W*WALK_SC),Math.round(H*WALK_SC));}
function ratPose(k){const box=view.querySelector(".stage-rat");if(box&&ART[k])setRat(box,k);}
function walkLoop(box){ // closing-time price: Fiver keeps walking, about 8 frames a second; still with reduced motion
  if(box.__loop)clearInterval(box.__loop);box.classList.remove("walk","hop","idle");let f=0;setWalk(box,1);box.dataset.pose="walk";
  box.__loop=setInterval(()=>{if(!box.isConnected||box.dataset.pose!=="walk"){clearInterval(box.__loop);box.__loop=null;return;}f++;setWalk(box,f%4+1);box.dataset.pose="walk";},125);}

/* ---------- TIME ---------- */
const DAYS=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const DAYL=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const DEMO=(()=>{try{const u=new URLSearchParams(location.search);const at=u.get("at")?new Date(u.get("at")):null;return {at:at&&!isNaN(at)?at:null,where:u.get("where")||""};}catch(e){return {at:null,where:""};}})();
function nowParts(){const d=DEMO.at?new Date(DEMO.at):new Date();return {day:d.getDay(),minutes:d.getHours()*60+d.getMinutes(),date:d};}
function selectedTime(){
  const n=nowParts();const off=state.dayOff||0;const date=new Date(n.date);date.setDate(date.getDate()+off);
  const day=date.getDay();const minutes=state.minute===null?(off===0?n.minutes:12*60):state.minute;
  const iso=date.getFullYear()+"-"+String(date.getMonth()+1).padStart(2,"0")+"-"+String(date.getDate()).padStart(2,"0");
  return {day,minutes,dateISO:iso,isNow:off===0&&state.minute===null,label:(off===0?"Today":DAYS[day]+" "+date.getDate())+" · "+(state.minute===null&&off===0?"now":fmt(minutes))};
}
function hm(s){const [h,m]=s.split(":").map(Number);return h*60+m;}
function fmt(m){if(m>=1439)return "midnight";const h=Math.floor(m/60),mm=m%60;return (h%12||12)+(mm?":"+String(mm).padStart(2,"0"):"")+(h<12?"am":"pm");}
const DAYK=["sun","mon","tue","wed","thu","fri","sat"];
function openWindow(p,day){if(p.when)return [hm(p.when.start),hm(p.when.end)];const h=p.hours||{};const dk=DAYK[day];const k=(dk in h)?h[dk]:day===0?h.sun:day===6?h.sat:h.wk;return k?[hm(k[0]),hm(k[1])]:null;}
function isOpen(p,t){
  if(p.when&&p.when.date!==t.dateISO)return {open:false,reason:"not that day"};
  if(p.hoursUnknown)return {open:true,closesIn:999,closes:"",unknown:true};
  const w=openWindow(p,t.day); if(!w)return {open:false,reason:"closed that day"};
  if(t.minutes<w[0])return {open:false,reason:"opens "+fmt(w[0])};
  if(t.minutes>=w[1])return {open:false,reason:"closed at "+fmt(w[1])};
  const allDay=w[0]===0&&w[1]>=1439;
  return {open:true,closesIn:w[1]-t.minutes,closes:fmt(w[1]),allDay};
}
function openLabel(o){return o.unknown?"hours not checked":o.allDay?"open 24h":"closes "+o.closes;}

/* ---------- HELPERS ---------- */
const NS="http://www.w3.org/2000/svg";
function el(tag,attrs,text){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;return e;}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}
function money(v){return v===0?"FREE":"£"+v.toFixed(2);}
function rectLL(a,b,fill){const [x1,y1]=P(a[0],a[1]),[x2,y2]=P(b[0],b[1]);return el("rect",{x:Math.min(x1,x2),y:Math.min(y1,y2),width:Math.abs(x2-x1),height:Math.abs(y2-y1),rx:6,fill});}
const AR='<svg class="arr" viewBox="0 0 64 24" aria-hidden="true"><path d="M3 13 C 18 10, 36 14, 56 11.5 M46 4 C 50 7, 54 9.5, 59 11.5 C 54 13.5, 50 16.5, 47 20"/></svg>';
const AL='<svg class="arr" viewBox="0 0 64 24" aria-hidden="true"><path d="M61 11 C 46 14, 28 10, 8 12.5 M18 4 C 14 7, 10 9.5, 5 12.5 C 10 14.5, 14 17.5, 17 20"/></svg>';
const PIN='<svg class="ico-inline" viewBox="0 0 22 22" aria-hidden="true"><path d="M11 20 C 7 14, 4 11, 4 8 a7 7 0 0 1 14 0 c0 3 -3 6 -7 12 z"/><circle cx="11" cy="8" r="2.4"/></svg>';
const MIC='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></svg>';
const GO='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>';
const X='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
const CAM='<svg class="ico-inline" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>';
const DL='<svg class="ico-inline" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>';
const CHEV='<svg class="ico-inline chev" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const PAW='<svg class="ico-inline" viewBox="0 0 24 24" aria-hidden="true"><circle cx="6.5" cy="9.5" r="1.7"/><circle cx="10.5" cy="6" r="1.7"/><circle cx="15.5" cy="6.5" r="1.7"/><circle cx="19" cy="10.5" r="1.7"/><path d="M7.5 17.5c0-3.2 2.4-5.5 5.3-5.5s5.2 2.3 5.2 5.5c0 1.8-1.3 2.8-2.7 2.8-1 0-1.6-.5-2.5-.5s-1.5.5-2.5.5c-1.4 0-2.8-1-2.8-2.8z"/></svg>';
const TICK='<svg class="ico-inline tick" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7"/></svg>';
const SRCH='<svg class="ico-inline" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 21 21"/></svg>';
const navNext=(id,word,dis)=>'<button type="button" class="arrbtn big" id="'+id+'"'+(dis?' disabled':'')+'><span class="ms" data-ms="'+word+'" style="--ms:11px"></span>'+AR+'</button>';
const navBack=(id,word)=>'<button type="button" class="arrbtn back" id="'+id+'">'+AL+'<span class="ms" data-ms="'+word+'" style="--ms:11px"></span></button>';
const title=(t,size)=>'<h2 class="ms" data-ms="'+esc(t)+'" style="--ms:'+(size||32)+'px"></h2>';
const rat=(k,h,cls)=>{const [W,H]=ARTW[k];const sc=Math.min(h/H,(h*1.4)/W);return svgOf(k,Math.round(W*sc),Math.round(H*sc),cls);};
const REAL_MAP=!(window.claude&&window.claude.use)&&!!window.maplibregl;
const IN_CLAUDE=!!(window.claude&&window.claude.use);
function gmaps(p){
  const byAddr=p.status==="event"||p.status==="added";
  const q=(byAddr?"":(p.name||"")+", ")+(p.addr||"")+", London";
  return "https://www.google.com/maps/dir/?api=1&destination="+encodeURIComponent(q)+"&travelmode=walking";}
function firstName(){return (state.name||"").trim().split(/\s+/)[0]||"";}
function cardsSummary(){const c=[...state.cards].map(cardName);return c.length?c.join(", "):"No cards yet";}
function dietSummary(){const d=[...state.diet].map(id=>(DIETS.find(x=>x.id===id)||{}).name).filter(Boolean);return (d.length?d.join(", "):"I eat everything")+(state.note?" · "+state.note:"");}

/* ---------- VIEWS ---------- */
const view=document.getElementById("view");
let ratPos=null;
function dots(){
  const d=document.getElementById("dots");d.hidden=true;
  const n=STEPS.length-S.where;const cur=state.step-S.where;
  d.innerHTML=Array.from({length:n},(_,i)=>'<i class="'+(i<cur?"done":i===cur?"on":"")+'"></i>').join("")+'<img class="rat" id="rat" src="'+ART.front+'" alt="" width="'+ARTW.front[0]+'" height="'+ARTW.front[1]+'">';
  if(d.hidden){ratPos=null;return;}
  const img=d.querySelector("#rat");const from=ratPos===null?cur:ratPos;const dir=cur>=from?1:-1;
  img.style.left=(from*14)+"px";img.style.setProperty("--dir",dir);
  if(ratPos!==null&&ratPos!==cur){
    if(REDUCED){img.style.left=(cur*14)+"px";}
    else{void img.offsetWidth;img.style.left=(cur*14)+"px";let f=0;img.src=ART.walk1;
      const iv=setInterval(()=>{f++;if(f>=7){clearInterval(iv);img.src=ART.front;img.style.setProperty("--dir",1);img.classList.add("hop");return;}img.src=ART["walk"+(f%4+1)];},90);}
  }
  ratPos=cur;
}
function go(n){state.step=n;render();window.scrollTo({top:0,behavior:"smooth"});}
function render(){dots();const f=[vHello,vWhere,vResults][state.step];view.innerHTML="";view.appendChild(f());msRender(view);paintInstall();stageEnter();if(state.step===S.results)loadShared();}
document.getElementById("home").onclick=()=>{document.getElementById("sheetHost").innerHTML="";go(state.setupDone?(state.where?S.results:S.where):S.hello);};
document.getElementById("menuBtn").onclick=()=>openMenu();
document.getElementById("teachBtn").onclick=()=>openTeach();

/* First run: a conversation with your rat, on one screen */
/* First run: one bubble, the rat talks line by line (typed), tiny ‹ › to re-read or skip */
const TALK={f_neutral:"f_oh",f_oh:"f_neutral",f_smug:"f_laugh",f_laugh:"f_smug",f_sniff:"f_laugh",f_tongue:"f_laugh",f_wink:"f_hearts",f_hearts:"f_wink",f_sad:"f_oh",f_excited:"f_laugh"};
// the six on the welcome: firstCardsFor() (the uni's own food app in the third slot, TOTUM when it has none); the rest behind "More…"
function introSteps(){
  const nm=firstName();const hh=nowParts().minutes/60;const night=hh>=23||hh<7;
  return [
    {text:"Hi, I’m Fiver. Yes, like the note. No, you can’t spend me.",face:"f_laugh"},
    night?{text:"It’s late. I’m up anyway.",face:"f_sleep"}:{text:"I’ve lived under Bloomsbury longer than you’ve been alive. I know where every cheap lunch is.",face:"f_smug"},
    {text:"What should I call you?",face:"f_neutral",input:"name"},
    {text:(nm?"Nice to meet you, "+nm+". ":"")+"Where do you study?",face:nm?"f_excited":"f_neutral",input:"uni"},
    {text:uniReply(state.uni)+" Which student cards are hiding in your phone? They stay on this phone.",face:"f_neutral",input:"cards"},
    {text:"Sorted"+(nm?", "+nm:"")+". Made for London students. Run by a rat with standards.",face:"f_wink",input:"go"}
  ];
}
let talkTimer=null,autoTimer=null;
function stopTalk(){if(talkTimer){clearInterval(talkTimer);talkTimer=null;}if(autoTimer){clearTimeout(autoTimer);autoTimer=null;}}
function vHello(){
  stopTalk();
  const d=document.createElement("div");d.className="step convo";
  const steps=introSteps();const i=Math.max(0,Math.min(state.intro||0,steps.length-1));state.intro=i;const st=steps[i];
  let inputH="";
  if(st.input==="name")inputH='<div class="turn me new"><div class="wishrow"><input class="line" id="nameIn" placeholder="Your first name" maxlength="24" autocomplete="given-name" value="'+esc(state.name)+'"><button type="button" class="iconbtn" id="nameGo" aria-label="That’s me">'+GO+'</button></div><p class="note"><button type="button" class="linkbtn" id="nameSkip">Skip</button></p></div>';
  else if(st.input==="uni")inputH='<div class="turn me new">'+uniChips("uniChips",state.uni)+'<p class="note">Fiver prices your own canteens and the shops round your campus.</p><div class="chips"><button type="button" class="chip on" id="uniGo">That’s me</button><button type="button" class="linkbtn" id="uniSkip">Skip</button></div></div>';
  else if(st.input==="cards"){const chip=c=>'<label class="chip'+(state.cards.has(c.id)?" on":"")+'"><input type="checkbox" value="'+c.id+'"'+(state.cards.has(c.id)?" checked":"")+'>'+esc(c.name)+'</label>';
    const FIRST=firstCardsFor(),ALL=cardsFor();const first=FIRST.map(id=>ALL.find(c=>c.id===id)).filter(Boolean),more=ALL.filter(c=>!FIRST.includes(c.id));
    inputH='<div class="turn me new"><div class="chips" id="cardChips">'+first.map(chip).join("")+'<button type="button" class="chip" id="moreCards">More…</button></div><div class="chips" id="moreChips" hidden>'+more.map(chip).join("")+'</div><p class="note">UNiDAYS and Student Beans are free with your uni email. The apps are free too.</p><div class="chips"><button type="button" class="chip on" id="cardsGo">That’s all of them</button><button type="button" class="linkbtn" id="cardsSkip">Skip</button></div></div>';}
  else if(st.input==="diet")inputH='<div class="turn me new"><div class="chips" id="dietChips">'+DIETS.map(c=>'<label class="chip'+(state.diet.has(c.id)?" on":"")+'"><input type="checkbox" value="'+c.id+'"'+(state.diet.has(c.id)?" checked":"")+'>'+esc(c.name)+'</label>').join("")+'</div><textarea class="line" id="noteIn" rows="2" placeholder="Other allergies or notes (optional)" style="font-family:var(--body);font-style:normal;font-size:15px;resize:none">'+esc(state.note)+'</textarea><p class="note">I hide what I know won’t work and flag the rest “ask staff”. Allergens change, so always ask.</p><div class="chips"><button type="button" class="chip on" id="dietGo">Done</button></div></div>';
  else if(st.input==="go")inputH='<div class="turn me"><div class="installBox"></div></div><div class="cta">'+rat("s_follow",120)+navNext("next","Follow me")+'</div>';
  d.innerHTML='<div class="talk"><div class="bubble"><p data-line="'+esc(st.text)+'"></p></div><div class="talk-row"><div class="face" id="face">'+rat(st.face,84)+'</div>'+
    '<div class="talk-nav"><button type="button" id="prevLine" aria-label="Back one line"'+(i===0?' disabled':'')+'>‹</button><span class="meta">'+(i+1)+'/'+steps.length+'</span><button type="button" id="nextLine" aria-label="Next line"'+(i===steps.length-1?' disabled':'')+'>›</button></div></div></div>'+inputH;
  const q=sel=>d.querySelector(sel);
  const goTo=n=>{stopTalk();state.intro=Math.max(0,Math.min(n,steps.length-1));render();};
  q("#prevLine").onclick=()=>goTo(i-1);q("#nextLine").onclick=()=>goTo(i+1);
  // the rat talks: the mouth moves while the line is typed, then settles
  const p=q(".bubble p"),face=q("#face");
  const done=()=>{stopTalk();face.innerHTML=rat(st.face,84);if(!st.input&&!REDUCED)autoTimer=setTimeout(()=>goTo(i+1),1900);};
  if(REDUCED){p.innerHTML=esc(st.text);}
  else{let k=0;talkTimer=setInterval(()=>{k++;face.innerHTML=rat(k%2?(TALK[st.face]||st.face):st.face,84);},170);
    const plain=st.text;p.innerHTML='<span class="cur"></span>';let n=0;
    const tick=()=>{if(!p.isConnected){stopTalk();return;}n++;if(n>plain.length){p.innerHTML=esc(plain);done();return;}p.innerHTML=esc(plain.slice(0,n))+'<span class="cur"></span>';setTimeout(tick,plain[n-1]===" "?16:24+Math.random()*16);};
    setTimeout(tick,220);}
  if(q("#nameIn")){const n=q("#nameIn");const goN=()=>{state.name=n.value.trim();persist();goTo(i+1);};q("#nameGo").onclick=goN;n.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();goN();}};q("#nameSkip").onclick=()=>goTo(i+1);}
  if(q("#uniChips")){q("#uniChips").addEventListener("click",e=>{const b=e.target.closest("button[data-uni]");if(!b)return;const id=b.dataset.uni;
      if(id==="other"){state.uni="other";persist();stopTalk();state.setupDone=true;UI.pickOther=true;go(S.where);return;}
      state.uni=id;q("#uniChips").querySelectorAll(".chip").forEach(c=>c.classList.toggle("on",c.dataset.uni===id));const m=uniMain(id);if(id!=="ucl"&&m&&!state.where){state.where={lat:m.lat,lon:m.lon,label:m.name};}if(id==="ucl"&&state.where&&UNIS.some(u=>u.id!=="ucl"&&u.campuses.some(c=>c.name===state.where.label)))state.where=null;persist();});
    q("#uniGo").onclick=()=>{persist();goTo(i+1);};q("#uniSkip").onclick=()=>goTo(i+1);}
  if(q("#cardChips")){const onCard=e=>{const c=e.target;if(c.type!=="checkbox")return;if(c.checked)state.cards.add(c.value);else state.cards.delete(c.value);c.closest(".chip").classList.toggle("on",c.checked);persist();if(c.checked){stopTalk();face.innerHTML=rat("f_tongue",84);}};
    q("#cardChips").addEventListener("change",onCard);q("#moreChips").addEventListener("change",onCard);
    q("#moreCards").onclick=()=>{q("#moreChips").hidden=false;q("#moreCards").hidden=true;};
    q("#cardsGo").onclick=()=>{persist();goTo(i+1);};q("#cardsSkip").onclick=()=>goTo(i+1);}
  if(q("#dietChips")){q("#dietChips").addEventListener("change",e=>{const c=e.target;if(c.type!=="checkbox")return;if(c.checked)state.diet.add(c.value);else state.diet.delete(c.value);c.closest(".chip").classList.toggle("on",c.checked);persist();});
    q("#dietGo").onclick=()=>{state.note=q("#noteIn").value.trim();persist();goTo(i+1);};}
  if(q("#next"))q("#next").onclick=()=>{stopTalk();state.setupDone=true;persist();go(S.where);};
  return d;
}

/* ---------- THE STAGE: the rat presents, one question at a time ---------- */
let lastScene=null;
function typeInto(el,html){ // typewriter for the bubble; instant with reduced motion
  const plain=html.replace(/<[^>]+>/g,"");
  if(REDUCED||plain.length>190){el.innerHTML=html;return;}
  el.innerHTML='<span class="cur"></span>';let i=0;const cur=el.querySelector(".cur");
  const tick=()=>{i++;if(i>plain.length){el.innerHTML=html;return;}el.innerHTML=esc(plain.slice(0,i)).replace(/\n/g,"<br>")+'<span class="cur"></span>';setTimeout(tick,plain[i-1]===" "?14:22+Math.random()*18);};
  setTimeout(tick,180);
}
function stageEnter(){ // called after every render: walk the rat in when the scene changed, then idle; type the line; speak it
  const st=view.querySelector(".stage");if(!st){lastScene=null;return;}
  const key=st.dataset.scene;const ratBox=st.querySelector(".stage-rat");const b=st.querySelector(".bubble p");
  if(ratBox){ratBox.classList.remove("walk","idle","hop");
    if(key!==lastScene&&!REDUCED){const pose=ratBox.dataset.pose;let f=0;setWalk(ratBox,1);ratBox.dataset.pose=pose;ratBox.classList.add("walk");
      const iv=setInterval(()=>{f++;if(!ratBox.isConnected){clearInterval(iv);return;}if(f>=10){clearInterval(iv);if(pose==="walk"){walkLoop(ratBox);return;}setRat(ratBox,pose);ratBox.classList.remove("walk");ratBox.classList.add("hop");setTimeout(()=>{ratBox.classList.remove("hop");ratBox.classList.add("idle");},520);return;}setWalk(ratBox,f%4+1);ratBox.dataset.pose=pose;},100);}
    else if(ratBox.dataset.pose==="walk"&&!REDUCED)walkLoop(ratBox);
    else ratBox.classList.add("idle");}
  if(b&&b.dataset.line){if(key!==lastScene)typeInto(b,b.dataset.line);else b.innerHTML=b.dataset.line;}
  lastScene=key;
}
function saidRow(upTo){ // where you are, small, tappable
  if(upTo>S.where&&upTo!==S.results&&state.where)return '<div class="said-row"><button type="button" class="said" data-go="'+S.where+'">'+PIN+' '+esc(state.where.label)+' · change</button></div>';
  return '<div class="said-row"></div>';
}
function stage(scene,pose,line,body,actions,upTo){
  const d=document.createElement("div");d.className="step stage";d.dataset.scene=scene;
  const pk=pose==="walk"?"walk1":pose;const [rw,rh]=ratSize(pk);
  d.innerHTML='<div class="stage-top"><div class="bubble"><p data-line="'+esc(line)+'"></p></div><div class="stage-rat" data-pose="'+pose+'">'+svgOf(pk,rw,rh)+'</div><div class="stage-side">'+saidRow(upTo)+'</div></div>'+
    '<div class="scene">'+body+'<div class="act">'+actions+'</div></div><p class="note stage-foot">'+footText()+'</p>';
  d.querySelectorAll(".said-row .said").forEach(b=>b.onclick=()=>go(Number(b.dataset.go)));
  return d;
}

function vWhere(){
  const nm=firstName();
  const campus=[["main","Main campus","quad"],["cw","Canary Wharf campus","cw"],["east","East campus","marshgate"]];
  const uni=UNIS.find(u=>u.id===state.uni);
  const facLine=c=>{const f=c.facs||[];if(!f.length)return "";return '<small>'+esc(f.slice(0,2).join(" · "))+(f.length>2?' · +'+(f.length-2)+' more':'')+'</small>';};
  const campRow=c=>'<button type="button" class="camp'+(state.where&&state.where.label===c.name?" on":"")+'" data-camp="'+esc(c.id)+'"><span>'+esc(c.name.replace(/ \(.*$/,"").replace(/ Campus$/,""))+'</span>'+facLine(c)+'</button>';
  const SHOW=5;const chipsH=uni?uni.campuses.slice(0,SHOW).map(campRow).join("")+(uni.campuses.length>SHOW?'<button type="button" class="chip" id="moreCamps">'+(uni.campuses.length-SHOW)+' more</button><div id="moreCampsBox" hidden>'+uni.campuses.slice(SHOW).map(campRow).join("")+'</div>':'')+'<button type="button" class="chip" id="campSearch">Search an address</button>'
    :campus.map(([id,label,vid])=>{const v=VENUES.find(x=>x.id===vid);const on=!!(state.where&&v&&VENUES.some(x=>x.name===state.where.label&&x.g===v.g));return '<button type="button" class="chip'+(on?" on":"")+'" data-id="'+vid+'">'+label+'</button>';}).join("");
  const body='<div class="reveal"><div class="'+(uni?"camps":"chips scroll")+'" id="campusChips">'+chipsH+'</div>'+
    '<div class="combo" id="combo"><div class="wishrow"><span class="iconbtn" aria-hidden="true">'+SRCH+'</span><input class="line" id="venueIn" placeholder="Search a building, a station or any address" autocomplete="off" style="font-family:var(--body);font-style:normal;font-size:16px"><button type="button" class="iconbtn" id="venueClear" aria-label="Close" hidden>'+X+'</button></div><div class="list" id="venueList" hidden></div></div>'+
    '<p class="meta" id="geoNote"></p><div class="mapbox" id="mapbox1"></div>'+(state.where?'<p class="meta">'+PIN+' '+esc(state.where.label)+' · tap the map to move</p>':'<p class="meta">Tap the map to drop yourself anywhere.</p>')+'</div>';
  const mw=moment("where","where",{name:nm?", "+nm:""});
  const d=stage("where",mw.pose,mw.line,body,
    navNext("geo","Use my location")+(state.where?navNext("next","Next"):''),S.where);
  const inp=d.querySelector("#venueIn"),list=d.querySelector("#venueList"),clr=d.querySelector("#venueClear");
  const GRP={ucl:"Main campus",east:"East campus (Stratford)",cw:"Canary Wharf",tube:"Stations"};
  const paint=()=>{const q=inp.value.trim().toLowerCase();const hits=VENUES.filter(v=>!q||v.name.toLowerCase().includes(q)||(v.addr||"").toLowerCase().includes(q));
    if(!hits.length){list.innerHTML='<div class="grp">Nothing called that here. Press enter to search the address, or tap the map.</div>';return;}
    let h="",g="";for(const v of hits){if(v.g!==g){g=v.g;h+='<div class="grp">'+(GRP[g]||g)+'</div>';}h+='<button type="button" data-id="'+v.id+'" class="'+(state.where&&state.where.label===v.name?"on":"")+'">'+esc(v.name)+(v.addr?'<span class="meta">'+esc(v.addr)+'</span>':'')+'</button>';}
    list.innerHTML=h;};
  const open=()=>{paint();list.hidden=false;clr.hidden=false;};const close=()=>{list.hidden=true;clr.hidden=!inp.value;};
  inp.onfocus=open;inp.oninput=()=>{paint();list.hidden=false;clr.hidden=false;};
  inp.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();const b=list.querySelector("button[data-id]");if(b)b.click();else geocode(inp.value.trim());}if(e.key==="Escape"){close();inp.blur();}};
  inp.onblur=()=>setTimeout(close,180);
  clr.onclick=()=>{inp.value="";close();clr.hidden=true;};
  list.addEventListener("mousedown",e=>e.preventDefault());
  const pickVenue=id=>{const v=VENUES.find(x=>x.id===id);if(!v)return;state.where={lat:v.lat,lon:v.lon,label:v.name};persist();go(S.results);};
  list.addEventListener("click",e=>{const b=e.target.closest("button[data-id]");if(b)pickVenue(b.dataset.id);});
  d.querySelector("#campusChips").addEventListener("click",e=>{const b=e.target.closest("button[data-id]");if(b){pickVenue(b.dataset.id);return;}
    const c=e.target.closest("button[data-camp]");if(c&&uni){const cp=uni.campuses.find(x=>x.id===c.dataset.camp);if(cp){state.where={lat:cp.lat,lon:cp.lon,label:cp.name};persist();go(S.results);}return;}
    if(e.target.closest("#campSearch")){inp.focus();}
    if(e.target.closest("#moreCamps")){const box=d.querySelector("#moreCampsBox");box.hidden=false;e.target.closest("#moreCamps").remove();}});
  if(UI.pickOther){UI.pickOther=false;setTimeout(()=>inp.focus(),300);}
  const note=d.querySelector("#geoNote");
  async function geocode(q){ // any address: OpenStreetMap's Nominatim, London only
    if(!q)return;note.textContent="Looking up “"+q+"”…";
    try{const res=await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=gb&viewbox=-0.35,51.65,0.1,51.4&bounded=1&q="+encodeURIComponent(q),{headers:{"Accept":"application/json"}});
      const j=await res.json();if(!j.length){note.textContent="Couldn’t find that in London. Try the map.";return;}
      state.where={lat:Number(j[0].lat),lon:Number(j[0].lon),label:q};persist();go(S.results);}
    catch(e){note.textContent="Address search needs the internet. Tap the map instead.";}
  }
  setTimeout(()=>{const m=view.querySelector("#mapbox1");if(m)mountMap(m,{tap:()=>go(S.results)});},0);
  d.querySelector("#geo").onclick=()=>{
    note.textContent="Asking your phone…";let done=false;const fail=msg=>{if(done)return;done=true;note.textContent=msg;};
    try{if(!navigator.geolocation){fail("No location on this device.");return;}
      const timer=setTimeout(()=>fail("Location is blocked here. Search a building or tap the map."),6000);
      navigator.geolocation.getCurrentPosition(pos=>{clearTimeout(timer);if(done)return;done=true;state.where={lat:pos.coords.latitude,lon:pos.coords.longitude,label:"your location"};go(S.results);},
        ()=>{clearTimeout(timer);fail("Location is blocked here. Search a building or tap the map.");},{enableHighAccuracy:true,timeout:5000,maximumAge:60000});
    }catch(e){fail("Location is blocked here. Search a building or tap the map.");}
  };
  const n=d.querySelector("#next");if(n)n.onclick=()=>go(S.results);
  return d;
}

let lastRank=null;
function breakdown(row){return row.walk+" min walk · back in "+(row.walk*2+row.eat)+" min";}
/* The card's status, for the time the student picked (not necessarily now) */
function statusLine(row,t){
  const o=row.o,p=row.p;const soft=p.hoursUnknown||p.status==="approx"||p.status==="added";
  let s;
  if(p.when){ // an event: it's on, or it isn't
    if(o.open)return (o.closesIn<=row.walk?"Ends before you get there":(t.isNow?"On now":"On at "+fmt(t.minutes))+" · until "+o.closes);
    return o.reason==="not that day"?"Not that day":o.reason.replace(/^opens/,"Starts").replace(/^closed at/,"Ended at");}
  if(o.open&&o.unknown)s="Hours not checked";
  else if(o.open&&o.closesIn<=row.walk)s="Closes before you get there";
  else if(o.open)s=(t.isNow?"Open now":"Open at "+fmt(t.minutes))+(o.allDay?" · open 24h":" · closes "+o.closes);
  else s=o.reason.charAt(0).toUpperCase()+o.reason.slice(1);
  if(soft&&!o.unknown)s+=" · hours not confirmed";
  return s;
}
/* Why this price: the card, the closing-time window or the event */
function whyPrice(row,t){
  const base=row.pr.price+(row.saved||0);
  if(row.pr.time)return "closing-time price · usually "+money(base);
  if(row.saved>0&&row.pr.label)return row.pr.label.replace(/^with /,"with your ").split(" (")[0]+" · usually "+money(base);
  if(row.of.cat==="free"&&row.p.status==="event")return "free for registered attendees";
  return "";
}
/* Diet, from the tags only. Never "safe". */
function dietLine(o){
  if(!state.diet.size)return "";const tags=o.tags||[];const out=[];
  for(const id of state.diet){const d=DIETS.find(x=>x.id===id);if(!d)continue;
    if(d.no.some(x=>tags.includes(x)))out.push("Not "+d.name.toLowerCase());
    else if(d.ok.some(x=>tags.includes(x)))out.push("Likely "+d.name.toLowerCase());
    else out.push(d.name+" not checked");}
  return out.join(" · ")+" · ask staff";
}
const UNCHECKED=new Set(["est","guide-hint","avg","fan"]);
function pickCard(x,t,o){o=o||{};
  return '<div class="hero pick'+(o.compact?" compact":"")+'" data-id="'+esc(x.p.id)+'"><div class="k">'+(o.label||"Fiver’s pick")+(state.q&&!o.compact?' · “'+esc(state.q)+'”':'')+'</div>'+
    '<span class="ms wine" data-ms="'+money(x.pr.price)+'" style="--ms:'+(o.compact?30:40)+'px"></span>'+
    (whyPrice(x,t)?'<p class="why">'+esc(whyPrice(x,t))+'</p>':'')+
    '<span class="ms" data-ms="'+esc(x.p.name)+'" style="--ms:16px"></span>'+
    '<p class="lead">'+esc(x.of.item)+'</p>'+
    '<p class="meta"><b>'+esc(statusLine(x,t))+'</b></p>'+
    '<p class="meta">'+breakdown(x)+(x.of.in?' · '+money(x.of.in)+' if you sit in':'')+(x.p.addedBy?' · added by '+esc(x.p.addedBy)+' · not verified yet':'')+(x.p.age>30?' · checked '+x.p.age+' days ago':'')+'</p>'+
    (dietLine(x.of)?'<p class="diet">'+esc(dietLine(x.of))+'</p>':'')+
    (UNCHECKED.has(x.of.status)?'<button type="button" class="linkbtn teach" data-teach="'+esc(x.p.id)+'">Price not checked. Snap the menu →</button>':'')+
    (o.compact?'<div class="actions"><a class="arrbtn big" href="'+gmaps(x.p)+'" target="_blank" rel="noopener"><span class="ms" data-ms="Walk there" style="--ms:11px"></span>'+AR+'</a><button type="button" class="chip" data-open="'+esc(x.p.id)+'">Details</button></div>':
      '<div class="actions"><a class="chip" href="'+gmaps(x.p)+'" target="_blank" rel="noopener">'+PIN+' Walk there</a><button type="button" class="chip" id="open0">Details</button><button type="button" class="chip" id="ask" hidden>Why?</button></div><p class="meta" id="askHint"></p><div class="ai" id="aiOut" hidden></div>')+'</div>';
}
function viewsRow(){return '<div class="views"><button type="button" class="'+(UI.view!=="map"?"on":"")+'" data-view="list">List</button><span>·</span><button type="button" class="'+(UI.view==="map"?"on":"")+'" data-view="map">Map</button></div>';}
const PICK_RAT={free:"ticket",deal:"bag",coffee:"a_coffee",sweet:"a_icecream",snack:"a_croissant",hot:"pizza"};
function opensAt(t){let m=null;for(const p of allPlaces()){if(p.when)continue;const w=openWindow(p,t.day);if(w&&w[0]>t.minutes&&(m===null||w[0]<m))m=w[0];}return m;}
const BUDGETS=[3,5,10],TIMES=[5,10,15,30];
function whenLabel(t){if(t.isNow)return "Now";const off=state.dayOff||0;const hhmm=String(Math.floor(t.minutes/60)).padStart(2,"0")+":"+String(t.minutes%60).padStart(2,"0");return (off===0?"Today":off===1?"Tomorrow":DAYS[t.day]+" "+Number(t.dateISO.slice(8)))+" "+hhmm;}
function placeShort(){const l=(state.where||VENUES[0]).label||"";return l.split(" / ")[0].split(", ")[0];}
function fitText(r){const n=r.fit.length;return (n?n+" place"+(n>1?"s":"")+" fit":"Nothing fits yet")+" · "+money(state.budget).replace(".00","")+" · "+state.mins+" min walk"+(state.q?" · “"+state.q+"”":"");}
function moneyNote(b){return b<=2?"Coffee money.":b<5?"Under a fiver. The brief.":b===5?"A fiver, exactly.":b<=8?"A fiver and a bit.":b<=12?"Treat day.":"Big spender.";}
function walkNote(m){return m<=5?"Round the corner.":m<=10?"A short stroll.":m<=15?"A proper walk. Worth it.":m<=30?"Half an hour each way.":"That’s a hike. Pack a snack.";}
function filterKey(){return [state.budget,state.mins,[...state.cats].join(","),state.q,state.dayOff||0,state.minute,(state.where||{}).label,[...state.diet].join(",")].join("|");}
function laterHTML(){
  const n=nowParts();const t=selectedTime();
  const days=Array.from({length:2},(_,i)=>{const dt=new Date(n.date);dt.setDate(dt.getDate()+i);return {off:i,label:i===0?"Today":"Tomorrow"};});if((state.dayOff||0)>1){state.dayOff=1;}
  const tv=state.minute===null?"":String(Math.floor(state.minute/60)).padStart(2,"0")+":"+String(state.minute%60).padStart(2,"0");
  return '<div class="chips scroll" id="dayChips">'+days.map(x=>'<button type="button" class="chip'+((state.dayOff||0)===x.off?" on":"")+'" data-off="'+x.off+'">'+x.label+'</button>').join("")+'</div>'+
    '<div class="wishrow"><button type="button" class="chip'+(state.minute===null?" on":"")+'" id="nowBtn">Now</button><input type="time" class="line tline" id="timeIn" value="'+tv+'" aria-label="Time"><span class="lead" id="whenLead">'+(t.isNow?"Right now.":"Going at "+fmt(t.minutes)+(state.dayOff?" "+(state.dayOff===1?"tomorrow":days[state.dayOff].label):" today")+".")+'</span></div>';
}
function filtersHTML(){
  const t=selectedTime();
  const cat=c=>'<button type="button" class="cat-tile'+(state.cats.has(c.id)?" on":"")+'" data-id="'+c.id+'" aria-pressed="'+state.cats.has(c.id)+'"><img class="ico" src="'+ICONS[c.ico]+'" alt=""><span class="lbl">'+c.name+'</span></button>';
  const bOther=!BUDGETS.includes(state.budget),mOther=!TIMES.includes(state.mins);
  return '<div class="filters"><div class="cats" id="catChips">'+CATS.map(cat).join("")+'</div>'+
    '<div class="chips scroll" id="howChips"><button type="button" class="chip place" id="placeChip" aria-label="Change where you are">'+PIN+'<span>'+esc(placeShort())+'</span>'+CHEV+'</button><i class="gap"></i>'+
    BUDGETS.map(b=>'<button type="button" class="chip'+(state.budget===b?" on":"")+'" data-b="'+b+'">£'+b+'</button>').join("")+'<button type="button" class="chip'+(bOther?" on":"")+'" id="bOther">'+(bOther?money(state.budget).replace(".00",""):"Other")+'</button><i class="gap"></i>'+
    TIMES.map(m=>'<button type="button" class="chip'+(state.mins===m?" on":"")+'" data-m="'+m+'">'+m+' min</button>').join("")+'<button type="button" class="chip'+(mOther?" on":"")+'" id="mOther">'+(mOther?state.mins+" min":"Other")+'</button><i class="gap"></i>'+
    '<button type="button" class="chip'+(!t.isNow?" on":"")+'" id="laterChip">'+esc(whenLabel(t))+CHEV+'</button></div>'+
    '<div class="reveal slider" id="bBox"'+(UI.bOther?'':' hidden')+'><div class="k">How much?</div><span class="ms wine" id="bBig" data-ms="'+money(state.budget)+'" style="--ms:24px"></span><input type="range" class="sl" id="bRange" min="1" max="15" step="0.5" value="'+state.budget+'" aria-label="Budget"><div class="sl-ticks"><span style="left:0">£1</span><span style="left:28.6%">A fiver</span><span style="left:100%">£15</span></div><p class="sl-note" id="bVal">'+moneyNote(state.budget)+'</p></div>'+
    '<div class="reveal slider" id="mBox"'+(UI.mOther?'':' hidden')+'><div class="k">How far?</div><span class="ms wine" id="mBig" data-ms="'+state.mins+' min" style="--ms:24px"></span><input type="range" class="sl" id="mRange" min="5" max="45" step="5" value="'+state.mins+'" aria-label="Walking time"><div class="sl-ticks"><span style="left:0">5</span><span style="left:50%">25 min walk</span><span style="left:100%">45</span></div><p class="sl-note" id="mVal">'+walkNote(state.mins)+'</p></div>'+
    '<div class="reveal" id="laterBox"'+(UI.later?'':' hidden')+'>'+laterHTML()+'</div>'+
    '<p class="meta fitline" id="fitLine"></p>'+
    '<button type="button" class="linkbtn" id="specLink">'+(state.q?'“'+esc(state.q)+'” · change':'Something specific?')+'</button>'+
    '<div class="reveal" id="specBox"'+(UI.spec?'':' hidden')+'><div class="wishrow"><input class="line" id="qIn" placeholder="cappuccino · pumpkin spice latte · sausage roll" autocomplete="off" value="'+esc(state.q)+'"><button type="button" class="iconbtn" id="mic" aria-label="Speak" hidden>'+MIC+'</button><button type="button" class="iconbtn" id="qGo" aria-label="Search">'+GO+'</button></div><div class="chips scroll" id="specChips"></div><p class="note" id="qNote"></p></div></div>';
}
function wireFilters(d){
  const q=sel=>d.querySelector(sel);
  q("#catChips").addEventListener("click",e=>{const b=e.target.closest(".cat-tile");if(!b)return;const id=b.dataset.id;if(state.cats.has(id)){if(state.cats.size>1)state.cats.delete(id);}else state.cats.add(id);persist();UI.catScroll=q("#catChips").scrollLeft;render();});
  q("#howChips").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
    if(b.dataset.b){state.budget=Number(b.dataset.b);UI.bOther=false;persist();render();}
    else if(b.dataset.m){state.mins=Number(b.dataset.m);UI.mOther=false;persist();render();}
    else if(b.id==="bOther"){UI.bOther=!UI.bOther;q("#bBox").hidden=!UI.bOther;if(UI.bOther){UI.mOther=false;q("#mBox").hidden=true;}}
    else if(b.id==="mOther"){UI.mOther=!UI.mOther;q("#mBox").hidden=!UI.mOther;if(UI.mOther){UI.bOther=false;q("#bBox").hidden=true;}}
    else if(b.id==="placeChip"){go(S.where);}
    else if(b.id==="laterChip"){UI.later=!UI.later;q("#laterBox").hidden=!UI.later;}});
  // the sliders: the chip, the line and the fit count follow the thumb; the pick re-renders when you let go
  const live=()=>{const r=rank();lastRank=r;q("#fitLine").textContent=fitText(r);};
  const bR=q("#bRange"),mR=q("#mRange");
  bR.addEventListener("input",()=>{state.budget=Number(bR.value);q("#bVal").textContent=moneyNote(state.budget);q("#bBig").dataset.ms=money(state.budget);msRender(q("#bBox"));q("#bOther").textContent=money(state.budget).replace(".00","");q("#bOther").classList.add("on");q("#howChips").querySelectorAll("[data-b]").forEach(c=>c.classList.remove("on"));live();});
  bR.addEventListener("change",()=>{persist();render();});
  mR.addEventListener("input",()=>{state.mins=Number(mR.value);q("#mVal").textContent=walkNote(state.mins);q("#mBig").dataset.ms=state.mins+" min";msRender(q("#mBox"));q("#mOther").textContent=state.mins+" min";q("#mOther").classList.add("on");q("#howChips").querySelectorAll("[data-m]").forEach(c=>c.classList.remove("on"));live();});
  mR.addEventListener("change",()=>{persist();render();});
  q("#fitLine").textContent=fitText(lastRank||rank());
  q("#dayChips").addEventListener("click",e=>{const c=e.target.closest("button");if(!c)return;state.dayOff=Number(c.dataset.off);if(state.dayOff>0&&state.minute===null)state.minute=12*60;UI.later=true;render();});
  q("#nowBtn").onclick=()=>{state.minute=null;state.dayOff=0;UI.later=false;render();};
  const ti=q("#timeIn");ti.addEventListener("change",()=>{state.minute=ti.value?hm(ti.value):null;UI.later=true;render();});
  const qIn=q("#qIn"),spec=q("#specChips"),qNote=q("#qNote"),specBox=q("#specBox");
  const paintSpec=()=>{const list=[...state.cats].flatMap(c=>SPECIFIC[c]||[]);spec.hidden=!list.length;spec.innerHTML=list.map(x=>'<button type="button" class="chip'+(qIn.value.trim().toLowerCase()===x.toLowerCase()?" on":"")+'" data-q="'+esc(x)+'">'+esc(x)+'</button>').join("");};
  paintSpec();qIn.oninput=paintSpec;
  qNote.textContent=claudeAvailable()?"Or say it all in one go: “something hot and veggie, £4, back in 20 min”.":"Type what you’re after and Fiver matches it by name.";
  spec.addEventListener("click",e=>{const b=e.target.closest("button[data-q]");if(!b)return;state.q=state.q.toLowerCase()===b.dataset.q.toLowerCase()?"":b.dataset.q;UI.spec=true;render();});
  q("#specLink").onclick=()=>{UI.spec=!UI.spec;specBox.hidden=!UI.spec;if(UI.spec)qIn.focus();};
  wireSay(d,qIn);
  const apply=async()=>{const text=qIn.value.trim();
    if(text&&claudeAvailable()){state.q="";const r=await parseWish(text,qNote);if(r===null){state.q=text;}}
    else state.q=text;
    if(state.q){const fixed=fuzzyQ(state.q);if(fixed!==state.q)state.q=fixed;}
    UI.spec=!!state.q;persist();render();};
  q("#qGo").onclick=apply;qIn.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();apply();}};
}
function unpricedBox(r){return r.unpriced.length?'<div class="k" style="margin-top:8px">Not priced yet · '+r.unpriced.length+' nearby</div><div class="list" id="unpriced"></div>':'';}
function vResults(){
  const r=rank();lastRank=r;const t=r.t;const here=state.where||VENUES[0];const nm=firstName();
  let line,pose,body,actions;
  const sparse=r.fit.concat(r.rest).filter(x=>x.walk<=45).length<3; // little data round this spot yet
  const far=sparse&&state.uni==="ucl"&&metres(here,UCL_LL)>2000; // somewhere east with nothing priced: the tunnel isn't dug yet
  const few=sparse&&!far;
  const fkey=filterKey();const changed=!!UI.lastFkey&&UI.lastFkey!==fkey;UI.lastFkey=fkey;
  const first=!state.seenResults;state.seenResults=true;
  if(UI.back===undefined){try{UI.back=!!(state.seenResults&&!DEMO.where&&!sessionStorage.getItem("fiver.sess"));sessionStorage.setItem("fiver.sess","1");}catch(e){UI.back=false;}}
  if(r.fit.length){const x=r.fit[0];
    const mk=pickMoment(x,state.q);const m=moment(mk,x.p.id+"|"+x.of.item,{name:nm?", "+nm:""});line=m.line;pose=m.pose;
    if(first&&mk!=="free"){const f=moment("first","first");line=f.line;pose=f.pose;}
    else if(UI.back&&mk!=="free"){const bk=moment("back","back");line=bk.line;pose=bk.pose;}
    UI.back=false;
    if(far){const fm=moment("far","far");line=fm.line;pose=fm.pose;}
    else if(few){line="I’m new around "+uniShort()+". Teach me your spots →";pose="s_peek";}
    if(UI.view==="map"){
      body=filtersHTML()+viewsRow()+'<div class="mapbox big" id="mapbox2"></div><div id="mapCard">'+pickCard(x,t,{compact:true})+'</div>';
      actions='';
    }else{
      body=filtersHTML()+viewsRow()+pickCard(x,t)+
        '<div class="reveal" id="allBox" hidden><div class="k">All that fit · best first</div><div class="list" id="fit"></div>'+unpricedBox(r)+(r.rest.length?'<div class="k" style="margin-top:8px">Out of reach right now</div><div class="list" id="rest"></div>':'')+(r.hidden?'<p class="note">'+r.hidden+' item'+(r.hidden>1?'s':'')+' hidden for your diet.</p>':'')+'</div>';
      actions=navNext("seeAll","See all "+r.fit.length);
    }
    if(far)actions=navNext("farTeach","Teach me a place there")+'<button type="button" class="chip" id="farMain">Or try Main campus</button>'+actions;
    else if(few)actions=navNext("farTeach","Teach me your spots")+(uniMain()&&state.where&&state.where.label!==uniMain().name?'<button type="button" class="chip" id="farMain">Or try '+esc(uniMain().name.replace(/ Campus$/,""))+'</button>':'')+actions;
  }else{
    const u=unlock(r);const oa=!u.anyOpen?opensAt(t):null;UI.back=false;
    const catsTxt=[...state.cats].map(c=>((CATS.find(x=>x.id===c)||{}).name||c).toLowerCase()).join(" or ");
    let em;
    if(!u.anyOpen&&u.cats){em={pose:"s_shrug",line:"No "+catsTxt+" open"+(t.isNow?" right now":" then")+". "+u.cats.p.name+" is, though."};}
    else if(!u.anyOpen)em=moment("shut","shut",{t:oa!==null?" Try me at "+fmt(oa)+".":" Try me tomorrow."});
    else if(!u.anyNear&&!u.cats&&!u.noq)em={pose:"s_shrug",line:"Nothing within 45 minutes. That’s far, even for me."};
    else if(state.q&&u.noq)em={pose:"s_shrug",line:"No “"+state.q+"” for that. Without it I’d say "+u.noq.p.name+"."};
    else if(u.budget&&!u.mins)em=moment("budget","budget");
    else em=moment("time","time",{b:money(state.budget).replace(".00",""),m:state.mins});
    line=em.line;pose=em.pose;
    const places=n=>n+" place"+(n===1?"":"s");
    const bt=[];const btn=(id,label,pri)=>pri?navNext(id,label):'<button type="button" class="chip" id="'+id+'">'+label+'</button>';
    // the smallest change that works, with its count; walking never past 45 min
    if(u.mins)bt.push(btn("fixM","Try "+u.mins+" min · "+places(u.minsN),true));
    if(u.budget)bt.push(btn("fixB","Up to "+money(u.budget).replace(".00","")+" · "+places(u.budgetN),!bt.length));
    if(u.both)bt.push(btn("fixBoth",money(Math.ceil(u.both.pr.price*2)/2).replace(".00","")+" and "+Math.ceil(u.both.walk/5)*5+" min · 1 place",!bt.length));
    if(u.cats)bt.push(btn("fixC","Any food type · "+places(u.catsN),!bt.length));
    if(state.q&&u.noq)bt.push(btn("fixQ","Drop “"+esc(state.q)+"” · "+places(u.noqN),!bt.length));
    if(!u.anyOpen&&t.isNow)bt.push(btn("fixTm","Tomorrow at 12:30",!bt.length));
    if(!u.anyOpen)bt.push(btn("fixT","Pick another time",!bt.length));
    bt.push(btn("fixL","Try another spot",!bt.length));
    if(far){const fm=moment("far","far");line=fm.line;pose=fm.pose;bt.length=0;bt.push(navNext("farTeach","Teach me a place there"),'<button type="button" class="chip" id="farMain">Or try Main campus</button>');}
    else if(few){line="I’m new around "+uniShort()+". Teach me your spots →";pose="s_peek";bt.length=0;bt.push(navNext("farTeach","Teach me your spots"));if(uniMain()&&state.where&&state.where.label!==uniMain().name)bt.push('<button type="button" class="chip" id="farMain">Or try '+esc(uniMain().name.replace(/ Campus$/,""))+'</button>');else if(state.uni==="ucl")bt.push('<button type="button" class="chip" id="farMain">Or try Main campus</button>');}
    if(UI.view==="map"){body=filtersHTML()+viewsRow()+'<div class="mapbox big" id="mapbox2"></div><div id="mapCard"></div>';actions=bt.join("")+'<button type="button" class="linkbtn teach" data-teach="">Know somewhere I don’t? Teach me →</button>';}
    else{body=filtersHTML()+viewsRow()+'<div class="reveal" id="allBox" hidden>'+unpricedBox(r)+(r.rest.length?'<div class="k">Out of reach right now</div><div class="list" id="rest"></div>':'')+'</div>';
    actions=bt.join("")+(r.rest.length||r.unpriced.length?'<button type="button" class="linkbtn" id="seeAll">Show the list</button>':'')+'<button type="button" class="linkbtn teach" data-teach="">Know somewhere I don’t? Teach me →</button>';}
    lastRank._unlock=u;
  }
  const d=stage("results-"+(r.fit[0]?r.fit[0].p.id:"none"),pose,line,body,actions,S.results);
  if(changed){const h=d.querySelector(".hero.pick");if(h)h.classList.add("pulse");const fl=d.querySelector("#fitLine");if(fl)fl.classList.add("pulse");}
  const ft=d.querySelector("#farTeach");if(ft)ft.onclick=()=>openTeach();const fm=d.querySelector("#farMain");if(fm)fm.onclick=()=>{const m=state.uni!=="ucl"&&uniMain();const v=m||VENUES.find(x=>x.id==="quad");state.where={lat:v.lat,lon:v.lon,label:v.name};persist();render();};
  wireFilters(d);d.querySelectorAll(".teach").forEach(b=>b.onclick=()=>openTeach(b.dataset.teach?allPlaces().find(p=>p.id===b.dataset.teach):null));if(UI.catScroll)setTimeout(()=>{const c=view.querySelector("#catChips");if(c)c.scrollLeft=UI.catScroll;},0);
  const item=row=>'<button type="button" class="item'+(row.fits?"":" dim")+'" data-id="'+esc(row.p.id)+'"><span class="ms wine" data-ms="'+money(row.pr.price)+'" style="--ms:14px;min-width:64px"></span>'+
    '<div style="min-width:0"><h3>'+esc(row.p.name)+(row.saved>0?'<span class="saved">−£'+row.saved.toFixed(2)+'</span>':'')+'</h3><div class="meta">'+esc(row.of.item)+' · '+(row.o.open?openLabel(row.o):row.o.reason)+(row.ask.length?' · <span class="diet">ask staff</span>':'')+(row.p.age>30?' · checked '+row.p.age+' days ago':'')+'</div></div>'+
    '<div class="walk">'+row.walk+' min<small>walk</small>'+(row.more?'<small>+'+row.more+' more</small>':'')+'</div></button>';
  const seenB={};const fitRows=[];for(const row of r.fit){const k=row.p.name+"|"+row.of.item+"|"+row.pr.price;if(seenB[k]){seenB[k].more=(seenB[k].more||0)+1;continue;}seenB[k]=row;fitRows.push(row);}
  const fitEl=d.querySelector("#fit");if(fitEl)fitEl.innerHTML=fitRows.map(item).join("");
  const restEl=d.querySelector("#rest");if(restEl){const near=r.rest.filter(x=>x.walk<=30);restEl.innerHTML=near.slice(0,40).map(item).join("")+(r.rest.length>near.length?'<p class="note">'+(r.rest.length-near.length)+' more over 30 min away.</p>':'');}
  const unEl=d.querySelector("#unpriced");if(unEl)unEl.innerHTML=r.unpriced.slice(0,20).map(row=>'<button type="button" class="item unp" data-id="'+esc(row.p.id)+'"><span class="ms" data-ms="£?" style="--ms:14px;min-width:64px"></span><div style="min-width:0"><h3>'+esc(row.p.name)+'</h3><div class="meta">Price not checked. Snap the menu →'+(row.o.unknown?' · hours not checked':'')+'</div></div><div class="walk">'+row.walk+' min<small>walk</small></div></button>').join("");
  d.addEventListener("click",e=>{const b=e.target.closest(".item");if(!b)return;if(b.classList.contains("unp")){const u=r.unpriced.find(x=>x.p.id===b.dataset.id);if(u)openTeach(u.p);return;}const row=r.fit.concat(r.rest).find(x=>x.p.id===b.dataset.id);if(row)openSheet(row);});
  d.querySelectorAll(".views button").forEach(b=>b.onclick=()=>{UI.view=b.dataset.view;render();});
  const sa=d.querySelector("#seeAll");if(sa)sa.onclick=()=>{const box=d.querySelector("#allBox");box.hidden=false;msRender(box);sa.hidden=true;};
  if(UI.view==="map"){const priced=new Set(r.fit.slice(0,8).map(x=>x.p.id));const card=d.querySelector("#mapCard");
    const showRow=row=>{card.innerHTML=pickCard(row,t,{compact:true,label:row.fits?(row===r.fit[0]?"Fiver’s pick":"On the map"):"Out of reach"});msRender(card);
      card.querySelector("[data-open]").onclick=()=>openSheet(row);card.querySelectorAll(".teach").forEach(b=>b.onclick=()=>openTeach(row.p));
      d.querySelectorAll(".pin.sel,.rpin.sel").forEach(e=>e.classList.remove("sel"));d.querySelectorAll(".pin.top,.rpin.top").forEach(e=>e.classList.remove("top"));
      d.querySelectorAll('.pin[data-id="'+row.p.id+'"],.rpin[data-id="'+row.p.id+'"]').forEach(e=>e.classList.add("sel"));
      if(card.scrollIntoView)card.scrollIntoView({block:"nearest",behavior:"smooth"});};
    setTimeout(()=>{const m=view.querySelector("#mapbox2");if(m)mountMap(m,{pins:r.fit.concat(r.rest),priced,top:r.fit[0]?[r.fit[0].p.id]:[],pick:showRow});},0);}
  if(r.fit.length){if(UI.view!=="map"){d.querySelector("#open0").onclick=()=>openSheet(r.fit[0]);wireAsk(d,r);}}
  else{const u=lastRank._unlock;const q=s=>d.querySelector(s);
    if(q("#fixQ"))q("#fixQ").onclick=()=>{state.q="";UI.spec=false;render();};
    if(q("#fixB"))q("#fixB").onclick=()=>{state.budget=Math.min(MAX_BUDGET,u.budget);persist();render();};
    if(q("#fixM"))q("#fixM").onclick=()=>{state.mins=u.mins;persist();render();};
    if(q("#fixBoth"))q("#fixBoth").onclick=()=>{state.budget=Math.min(MAX_BUDGET,Math.ceil(u.both.pr.price*2)/2);state.mins=Math.min(MAX_WALK,Math.ceil(u.both.walk/5)*5);persist();render();};
    if(q("#fixC"))q("#fixC").onclick=()=>{state.cats=new Set(CATS.map(c=>c.id));persist();render();};
    if(q("#fixTm"))q("#fixTm").onclick=()=>{state.dayOff=1;state.minute=12*60+30;UI.later=true;render();};
    if(q("#fixT"))q("#fixT").onclick=()=>{UI.later=true;render();const b=view.querySelector("#laterBox");if(b&&b.scrollIntoView)b.scrollIntoView({block:"center",behavior:"smooth"});};
    if(q("#fixL"))q("#fixL").onclick=()=>go(S.where);}
  return d;
}

const PSTATUS={uni:"Price: the university’s own food pages, Oct 2026. Student price where it says so.","guide-hint":"Price: UCL says “under a fiver”; exact menu price to confirm.",press:"Price: press, 2025–26.",photo:"Price: menu photographed in store, 13 Oct 2026. Takeaway; sitting in can cost more.",tracked:"Price: UK price tracker, Oct 2026. London can be a touch higher.",fan:"Price: fan site, Oct 2026. London shelf price may be a step higher.",avg:"Price: UK average, 2025–26. Central London usually 15–25% more.",event:"",added:"Price: read by Claude from your photo. Check the board.",app:"Price: Food at UCL app, 13 Oct 2026.",web:"Price: the shop’s own website, Oct 2026.",est:"Price: estimate, to confirm."};
function openSheet(row){
  const host=document.getElementById("sheetHost");const t=row.t||selectedTime();const rows=ladder(row.p,row.of,t);
  const src=row.p.status==="guide"?'<span class="badge ok">'+(row.p.uni?esc(uniShort(row.p.uni))+" food pages":"Food at UCL guide")+'</span>':row.p.status==="event"?'<span class="badge ok">confirmed event</span>':row.p.status==="added"?'<span class="badge">added by '+esc(row.p.addedBy||"you")+' · not verified yet</span>':'<span class="badge">'+(row.p.status==="approx"?"hours to confirm":"address checked")+'</span>';
  const pstatus=(row.of.status==="uni"&&row.p.uni?"Price: "+uniShort(row.p.uni)+" food pages, Oct 2026. Student price where it says so.":PSTATUS[row.of.status]!==undefined?PSTATUS[row.of.status]:PSTATUS.est)+(row.of.check?" Check at the till.":"")+(row.of.uniOnly?" "+uniShort(row.p.uni)+" students only.":"");
  const dl=state.diet.size?dietLabel(row.of):"";
  host.innerHTML='<div class="sheetWrap" id="sheetWrap"><div class="sheet" role="dialog" aria-modal="true" aria-label="'+esc(row.p.name)+'">'+
    '<button class="close" id="closeSheet">Close</button>'+
    '<span class="ms" data-ms="'+esc(row.p.name)+'" style="--ms:18px"></span><p class="meta">'+esc(row.p.addr||"")+src+'</p>'+
    '<p class="lead">'+esc(row.of.item)+'</p><p class="meta"><b>'+esc(statusLine(row,t))+'</b></p>'+
    '<p class="meta">'+breakdown(row)+(row.of.in?' · '+money(row.of.in)+' if you sit in':'')+'</p>'+(row.p.why?'<p class="body">'+esc(row.p.why)+'</p>':'')+
    (dl?'<p class="diet">Diet: '+esc(dl)+'. Allergens change: ask staff.</p>':'')+
    '<div class="chips"><a class="chip" href="'+gmaps(row.p)+'" target="_blank" rel="noopener">'+PIN+' Walk there</a></div>'+
    '<div class="k" style="margin-top:10px">Your price</div><div class="prices">'+rows.map(x=>'<div class="pr'+(x.mine&&!x.promo?" mine":"")+'"><div>'+esc(x.label)+(x.mine&&x.label!=="No card"&&x.label!=="Everyone"?' · you have it':'')+(x.note?'<span class="why">'+esc(x.note)+'</span>':'')+'</div><span class="ms'+(x.mine&&!x.promo?' wine':'')+'" data-ms="'+money(x.price)+'" style="--ms:13px"></span></div>').join("")+'</div>'+
    (row.p.promos&&row.p.promos.length?'<p class="note">'+row.p.promos.map(x=>esc(x.label)+(x.card&&state.cards.has(x.card)?" · you have it":"")).join("<br>")+'</p>':'')+
    (row.p.ucl&&state.cards.has("foodatucl")?'<p class="note">Food at UCL app: 1 point = £0.05 on every purchase; 9 stamps on barista drinks, 10th free; first coffee free on download.</p>':'')+
    (pstatus?'<p class="note">'+pstatus+'</p>':'')+'<p class="note"><button type="button" class="linkbtn" id="sheetTeach">Is this still right? Snap the menu →</button></p>'+
    (row.p.offers.length>1?'<div class="k" style="margin-top:10px">Also here</div><p class="note">'+row.p.offers.filter(o=>o!==row.of).map(o=>esc(o.item)+(o.price!=null||row.p.deal?" · "+money(bestPrice(row.p,o,t).price):"")+(state.diet.size&&dietCheck(o).hide?" (not for you)":"")).join(" · ")+'</p>':'')+
    '</div></div>';
  msRender(host);
  const wrap=document.getElementById("sheetWrap");const close=()=>{host.innerHTML="";};
  document.getElementById("closeSheet").onclick=close;wrap.addEventListener("click",e=>{if(e.target===wrap)close();});
  document.addEventListener("keydown",function onk(e){if(e.key==="Escape"){close();document.removeEventListener("keydown",onk);}});
  const st=document.getElementById("sheetTeach");if(st)st.onclick=()=>openTeach(row.p);
  document.getElementById("closeSheet").focus();
}

/* ---------- MENU: name, cards & apps (what each unlocks), diet, teach Fiver, install ---------- */
const menuOpen=new Set();
/* Teach Fiver: snap a menu, paste an invite. Opens from the camera up top and from the hints. */
function openTeach(place){
  const host=document.getElementById("sheetHost");
  host.innerHTML='<div class="sheetWrap" id="sheetWrap"><div class="sheet menu" role="dialog" aria-modal="true" aria-label="Teach Fiver"><button class="close" id="closeSheet">Close</button>'+
    '<h2 class="sr">Teach Fiver</h2><div class="thead" id="teachHead">'+signRat(190)+'<p class="lead">I’ve got paws, not a camera. You snap, I read.</p></div>'+
    '<div class="trow" id="trow"><button type="button" class="tst" data-s="1">'+PIN+'<span>Where'+TICK+'</span><small id="ts1"></small></button><i></i><button type="button" class="tst" data-s="2">'+CAM+'<span>Menu'+TICK+'</span><small id="ts2"></small></button><i></i><button type="button" class="tst" data-s="3">'+PAW+'<span>Send'+TICK+'</span><small id="ts3">+10 crumbs</small></button></div>'+
    '<div class="tpanel" id="t1"><p class="note">'+(place?'Is <b>'+esc(place.name)+'</b> still right?':'Which café, shop or address?')+'</p><p class="meta" id="tAt" hidden></p><div id="tFind"><div class="combo"><div class="wishrow"><span class="iconbtn" aria-hidden="true">'+SRCH+'</span><input class="line" id="tWhereIn" placeholder="Search a café, restaurant or address" autocomplete="off" style="font-family:var(--body);font-style:normal;font-size:16px"><button type="button" class="iconbtn" id="tWhereClear" aria-label="Close" hidden>'+X+'</button></div><div class="list" id="tWhereList" hidden></div></div>'+
      '<div class="chips" style="margin-top:8px"><button type="button" class="chip" id="tGeo">'+PIN+' Use my location</button></div><p class="meta" id="tWhereNote"></p><div class="nearlist" id="tNear" hidden></div></div>'+
      '<div id="tShopAsk" hidden><input class="line" id="tShopIn" placeholder="Shop name" autocomplete="off" style="font-family:var(--body);font-style:normal;font-size:16px"></div></div>'+
    '<div class="tpanel" id="t2" hidden><div class="chips" id="tPhotoRow"><label class="chip">'+CAM+' Take a photo<input type="file" id="menuFile" accept="image/*" capture="environment" hidden></label><label class="chip">Choose a photo<input type="file" id="menuFile2" accept="image/*" hidden></label><button type="button" class="chip" id="tTypeBtn">Type it instead</button></div>'+
      '<div id="tTypeBox" hidden style="margin-top:8px"><textarea id="tTypeIn" class="line" rows="3" placeholder="Flat white £2.60, sausage roll £1.85…" style="font-family:var(--body);font-style:normal;font-size:15px"></textarea><div class="chips" style="margin-top:6px"><button type="button" class="chip" id="tTypeGo">Read it</button></div></div>'+
      '<p class="note" id="menuNote"></p><p class="note" id="tCheck"></p><div class="chips" id="tWhich"></div><div id="menuOut"></div></div>'+
    '<div class="tpanel" id="t3" hidden><div id="sendBox"></div></div>'+
    '<p class="note" style="margin-top:18px"><button type="button" class="linkbtn" id="evtOpen">Got a free-food invite? Paste it →</button></p>'+
    '<div class="reveal" id="evtBox" hidden>'+(()=>{const im=moment("invite","invite");return '<div class="mhead">'+rat(im.pose,72)+'<p class="lead">'+esc(im.line)+'</p></div>';})()+'<p class="note">Claude checks there really is free food, picks the date and time, and adds it as a FREE result (+10 crumbs).</p>'+
    '<textarea id="evtText" class="line" rows="3" placeholder="Paste the event text here" style="font-family:var(--body);font-style:normal;font-size:15px"></textarea><div class="chips"><select id="evtVenue" class="chip"></select><button type="button" class="chip" id="evtBtn">Check it with Claude</button></div><p class="note" id="evtNote"></p></div>'+
    '<p class="note" style="margin-top:14px"><b id="teachRank">'+(state.crumbs||0)+' crumbs · '+esc(rankName(state.crumbs||0))+'</b>. A menu photo accepted is +10, a typed menu +3, a free-food invite +10. Everything you add is marked “added by '+esc(firstName()||"you")+' · not verified yet”.</p>'+
    '</div></div>';
  msRender(host);
  const wrap=document.getElementById("sheetWrap");const sheet=wrap.querySelector(".sheet");const close=()=>{host.innerHTML="";};
  document.getElementById("closeSheet").onclick=close;wrap.addEventListener("click",e=>{if(e.target===wrap)close();});
  document.addEventListener("keydown",function onk(e){if(e.key==="Escape"){close();document.removeEventListener("keydown",onk);}});
  const eo=sheet.querySelector("#evtOpen");eo.onclick=()=>{const b=sheet.querySelector("#evtBox");b.hidden=!b.hidden;if(!b.hidden)sheet.querySelector("#evtText").focus();};
  wireMenu(sheet,place);wireEvents(sheet);
}
function signRat(w){ // s_sign with "TEACH FIVER" written on the board, in the brand lettering
  const [W,H]=ARTW.s_sign;const h=Math.round(w*H/W);
  return '<div class="signwrap" style="width:'+w+'px;height:'+h+'px">'+svgOf("s_sign",w,h)+'<span class="ms signtxt" data-ms="Teach Fiver" style="--ms:'+Math.round(w*0.06)+'px"></span></div>';
}
function teachFace(sheet,face,line){const h=sheet.querySelector("#teachHead");if(h)h.innerHTML=rat(face,84)+'<p class="lead">'+esc(line)+'</p>';}
function teachCelebrate(sheet,n,first){ // Fiver celebrates a contribution; crumbs are recognition only
  const before=rankName(state.crumbs||0);addCrumbs(n);const after=rankName(state.crumbs||0);
  const h=sheet.querySelector("#teachHead");if(h)h.innerHTML=rat("cheer",96)+'<p class="lead">'+(first?esc(first)+' ':'')+'+'+n+' crumbs. The pigeons are furious.</p>';
  const r=sheet.querySelector("#teachRank");if(r)r.textContent=(state.crumbs||0)+" crumbs · "+after;
  if(after!==before&&h)setTimeout(()=>{if(h.isConnected)h.innerHTML=rat("f_hearts",84)+'<p class="lead">'+esc(after)+'. The pigeons have heard of you.</p>';},2600);
}
function openMenu(section){
  if(section)menuOpen.add(section);
  const host=document.getElementById("sheetHost");const nm=firstName();
  const sec=(id,label,body)=>'<details id="m-'+id+'"'+(menuOpen.has(id)?' open':'')+'><summary>'+label+'</summary>'+body+'</details>';
  const kinds=[["student","Student discounts"],["app","Free apps with perks"],["loyalty","Loyalty cards"],["sub","Paid subscriptions"]];
  const cardsBody='<p class="note">Tick what you have. Fiver prices everything with it.</p>'+kinds.map(([k,label])=>'<div class="k" style="margin-top:10px">'+label+'</div><div class="chips" data-cards>'+cardsFor().filter(c=>c.kind===k).map(c=>'<label class="chip'+(state.cards.has(c.id)?" on":"")+'"><input type="checkbox" value="'+c.id+'"'+(state.cards.has(c.id)?" checked":"")+'>'+esc(c.name)+'</label>').join("")+'</div>').join("")+
    '<details id="m-unlocks" class="sub"'+(menuOpen.has("unlocks")?' open':'')+'><summary>What each one unlocks'+(uniName()?" near "+esc(uniName()):"")+'</summary><div id="unlocks">'+
    cardsFor().slice().sort((a,b)=>(state.cards.has(b.id)?1:0)-(state.cards.has(a.id)?1:0)).map(c=>{const u=cardUnlocks(c.id);const on=state.cards.has(c.id);return '<details class="unl"><summary><span>'+esc(c.name)+' <span class="meta">· '+esc(c.cost)+(on?' · you have it':'')+'</span></span></summary>'+(u.length?'<div class="prices">'+u.slice(0,8).map(x=>'<div class="pr'+(on?" mine":"")+'"><div>'+esc(x)+'</div></div>').join("")+'</div>':'<p class="note">Nothing priced with this yet. It still counts for Claude’s advice.</p>')+(c.url?'<p class="note"><a class="linkbtn" href="'+c.url+'" target="_blank" rel="noopener">Open '+esc(c.name.split(" (")[0])+'</a></p>':'')+'</details>';}).join("")+
    '</div><p class="note">Fiver never logs in to these or stores passwords: it works out your price from what you tick.</p></details>';
  host.innerHTML='<div class="sheetWrap" id="sheetWrap"><div class="sheet menu" role="dialog" aria-modal="true" aria-label="Menu"><button class="close" id="closeSheet">Close</button>'+
    '<div class="mhead">'+rat("f_neutral",64)+'<div><span class="ms" data-ms="'+esc(nm||"Your rat")+'" style="--ms:18px"></span><p class="meta"><b>'+(state.crumbs||0)+' crumbs · '+esc(rankName(state.crumbs||0))+'</b></p><p class="meta">Your name and cards stay on this phone. Menus you teach me are shared.</p></div></div>'+
    '<div class="k mgrp">You</div>'+
    sec("name","Your name",'<input class="line" id="mName" placeholder="Your first name" maxlength="24" value="'+esc(state.name)+'">')+
    sec("cards","Cards &amp; apps",cardsBody)+
    sec("uni","Your uni",'<p class="note">Your own canteens and the shops round your campus. Prices come from each university’s food pages.</p>'+uniChips("mUni",state.uni))+
    sec("diet","Diet &amp; allergies",'<div class="chips" id="mDiet">'+DIETS.map(c=>'<label class="chip'+(state.diet.has(c.id)?" on":"")+'"><input type="checkbox" value="'+c.id+'"'+(state.diet.has(c.id)?" checked":"")+'>'+esc(c.name)+'</label>').join("")+'</div><textarea class="line" id="mNote" rows="2" placeholder="Other allergies or notes" style="font-family:var(--body);font-style:normal;font-size:15px;resize:none">'+esc(state.note)+'</textarea><p class="note">Fiver hides what it knows won’t work and flags the rest “ask staff”. Allergens change: always ask.</p>')+
    sec("crumbs","Crumbs",'<p class="body"><b>'+(state.crumbs||0)+' crumbs · '+esc(rankName(state.crumbs||0))+'</b></p><p class="note">A menu photo accepted is +10, a typed menu +3, a free-food invite +10. Crumb finder at 10 · Menu hunter at 50 · Bloomsbury legend at 150. Bragging rights only.</p>')+
    '<div class="k mgrp">Deals</div>'+
    sec("deals",DAYL[nowParts().day]+"’s deals",(()=>{const n=nowParts();const t=selectedTime();const dl=todayDeals({day:n.day,minutes:n.minutes,dateISO:t.dateISO});const dm=moment("deals","deals");return '<div class="mhead">'+rat(dm.pose,72)+'<p class="lead">'+esc(dm.line)+'</p></div>'+(dl.cards.length?dl.cards.slice(0,5).map(x=>'<div class="deal'+(x.mine?"":" off")+'"><span class="tag">'+esc(cardName(x.card||"").split(" (")[0]||"today")+'</span><span>'+esc(x.text)+(x.mine?"":" · you don’t have this card")+'</span></div>').join(""):'<div class="deal"><span class="tag">today</span><span>No card deals today.</span></div>')+dl.late.slice(0,3).map(x=>'<div class="deal"><span class="tag">later</span><span>'+esc(x.text)+'</span></div>').join("");})())+
    sec("teach","Teach Fiver",'<p class="body">Snap a menu or paste a free-food invite. Claude reads it; it lands on the map.</p><p class="note"><button type="button" class="linkbtn" id="mTeach">Open Teach Fiver →</button></p>')+
    '<div class="k mgrp">Help</div>'+
    sec("install","Install the app",(()=>{const im=moment("install","install");return '<div class="mhead">'+rat(im.pose,96)+'<p class="lead">'+esc(im.line)+'</p></div>';})()+'<div class="installBox"></div><p class="note">On iPhone, Apple only allows installing from Safari’s Share menu; the button shows you the three taps. Android and desktop install directly.</p>')+
    sec("sources","Where prices come from",SOURCES)+
    '<div class="chips" style="margin-top:14px"><button type="button" class="chip" id="mStart">Start over</button><button type="button" class="chip" id="mReset">Forget me</button></div><p class="note">Forget me wipes your name, cards, diet and everything you added from this phone.</p><p class="note estd">Fed for a Fiver · estd 2026 · London</p>'+
    '</div></div>';
  msRender(host);paintInstall();
  const wrap=document.getElementById("sheetWrap");const sheet=wrap.querySelector(".sheet");const close=()=>{host.innerHTML="";};
  document.getElementById("closeSheet").onclick=close;wrap.addEventListener("click",e=>{if(e.target===wrap)close();});
  document.addEventListener("keydown",function onk(e){if(e.key==="Escape"){close();document.removeEventListener("keydown",onk);}});
  sheet.querySelectorAll("details[id^=m-]").forEach(dt=>dt.addEventListener("toggle",()=>{const id=dt.id.slice(2);if(dt.open)menuOpen.add(id);else menuOpen.delete(id);}));
  const mName=sheet.querySelector("#mName");mName.oninput=()=>{state.name=mName.value;persist();};mName.onchange=()=>{state.name=mName.value.trim();persist();render();};
  sheet.querySelectorAll("[data-cards]").forEach(row=>row.addEventListener("change",e=>{const i=e.target;if(i.type!=="checkbox")return;if(i.checked)state.cards.add(i.value);else state.cards.delete(i.value);persist();menuOpen.add("cards");openMenu();if(state.step===S.results)render();}));
  sheet.querySelector("#mUni").addEventListener("click",e=>{const b=e.target.closest("button[data-uni]");if(!b)return;const id=b.dataset.uni;
    if(id==="other"){state.uni="other";persist();close();UI.pickOther=true;go(S.where);return;}
    state.uni=id;sheet.querySelectorAll("#mUni .chip").forEach(c=>c.classList.toggle("on",c.dataset.uni===id));const m=uniMain(id);if(id!=="ucl"&&m){state.where={lat:m.lat,lon:m.lon,label:m.name};}else if(id==="ucl"){const v=VENUES.find(x=>x.id==="quad");state.where={lat:v.lat,lon:v.lon,label:v.name};}persist();if(state.step===S.results)render();});
  sheet.querySelector("#mDiet").addEventListener("change",e=>{const i=e.target;if(i.type!=="checkbox")return;if(i.checked)state.diet.add(i.value);else state.diet.delete(i.value);i.closest(".chip").classList.toggle("on",i.checked);persist();if(state.step===S.results)render();});
  const mNote=sheet.querySelector("#mNote");mNote.onchange=()=>{state.note=mNote.value.trim();persist();};
  sheet.querySelector("#mTeach").onclick=()=>openTeach();
  sheet.querySelector("#mStart").onclick=()=>{close();state.where=null;state.q="";go(S.where);};
  sheet.querySelector("#mReset").onclick=()=>{if(!confirm("Fine. I’ll pretend we never met. Forget everything Fiver knows about you on this phone?"))return;try{["fiver.v7","fiver.v6","fiver.v5","fiver.v4"].forEach(k=>localStorage.removeItem(k));}catch(e){}location.reload();};
  if(section){const dt=sheet.querySelector("#m-"+section);if(dt&&dt.scrollIntoView)setTimeout(()=>dt.scrollIntoView({block:"start",behavior:"smooth"}),50);}
}

/* ---------- INSTALL (PWA) ---------- */
let installEvt=null;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installEvt=e;paintInstall();});
window.addEventListener("appinstalled",()=>{installEvt=null;paintInstall();});
function standalone(){return (window.matchMedia&&matchMedia("(display-mode: standalone)").matches)||navigator.standalone===true;}
function isIOS(){return /iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1);}
function installable(){return !standalone()&&!IN_CLAUDE&&location.protocol==="https:";}
function paintInstall(){document.querySelectorAll(".installBox").forEach(b=>{b.innerHTML=installable()?'<button type="button" class="chip">'+DL+' Install the app</button>':(standalone()?'<p class="note">Installed. You’re in the app.</p>':'');const btn=b.querySelector("button");if(btn)btn.onclick=doInstall;});}
async function doInstall(){
  if(installEvt){try{installEvt.prompt();const r=await installEvt.userChoice;if(r&&r.outcome==="accepted")installEvt=null;}catch(e){}paintInstall();return;}
  openInstallSheet();
}
function openInstallSheet(){
  const host=document.getElementById("sheetHost");
  const steps=isIOS()?[["Open this page in Safari","If you are in another app’s browser, tap the ••• menu and choose Open in Safari."],["Tap Share","The square with an arrow, at the bottom of the screen."],["Tap “Add to Home Screen”","Scroll down the list if you don’t see it."],["Tap Add","Fiver lands on your home screen with the pizza icon and opens full-screen."]]:
    [["Open your browser’s menu","The ⋮ or ··· button."],["Choose “Install app” or “Add to Home screen”","Chrome, Edge and Samsung Internet all have it."],["Confirm","Fiver opens full-screen, like any app."]];
  host.innerHTML='<div class="sheetWrap" id="sheetWrap"><div class="sheet" role="dialog" aria-modal="true" aria-label="Install the app"><button class="close" id="closeSheet">Close</button>'+
    '<span class="ms" data-ms="Install the app" style="--ms:18px"></span><div class="mhead">'+rat(moment("install","install").pose,110)+'<img class="appicon" src="apple-touch-icon.png" alt="" onerror="this.remove()"></div><p class="lead">'+esc(moment("install","install").line)+'</p><p class="body">'+(isIOS()?"Apple only lets you install from Safari’s Share menu. Three taps:":"Install it like an app. No store, no account:")+'</p>'+
    '<div class="steps">'+steps.map((s,i)=>'<div><b>'+(i+1)+'</b><div><div class="body">'+esc(s[0])+'</div><div class="note" style="margin-top:2px">'+esc(s[1])+'</div></div></div>').join("")+'</div>'+
    '<p class="note" style="margin-top:14px">No app store, no account. Updates arrive on their own.</p></div></div>';
  msRender(host);
  const wrap=document.getElementById("sheetWrap");const close=()=>{host.innerHTML="";};
  document.getElementById("closeSheet").onclick=close;wrap.addEventListener("click",e=>{if(e.target===wrap)close();});
  document.getElementById("closeSheet").focus();
}
if("serviceWorker" in navigator&&location.protocol==="https:"&&!IN_CLAUDE){window.addEventListener("load",()=>{navigator.serviceWorker.register("sw.js").catch(()=>{});});}

/* ---------- MAP MOUNT: real map when hosted, walk radar inside claude.ai ---------- */
let rmap=null,rmarkers=[];
function mountMap(box,opts){
  if(REAL_MAP){box.innerHTML='<div id="rmap"></div>';setTimeout(()=>buildRealMap(box.querySelector("#rmap"),opts),0);}
  else{box.innerHTML='<svg viewBox="0 0 1000 640" role="img" aria-label="Walking distances around you"></svg>';buildDrawnMap(box.querySelector("svg"),opts);}
}

const INK="#59211F",PAPER="#FFF7EB";
const RSTYLE={version:8,glyphs:"https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf",sources:{omt:{type:"vector",url:"https://tiles.openfreemap.org/planet"}},layers:[
  {id:"bg",type:"background",paint:{"background-color":PAPER}},
  {id:"landcover",type:"fill",source:"omt","source-layer":"landcover",filter:["in","class","grass","wood","farmland","wetland"],paint:{"fill-color":INK,"fill-opacity":0.05}},
  {id:"landuse",type:"fill",source:"omt","source-layer":"landuse",filter:["in","class","grass","park","garden","cemetery","pitch","playground","school","university","college","hospital","stadium"],paint:{"fill-color":INK,"fill-opacity":0.05}},
  {id:"park",type:"fill",source:"omt","source-layer":"park",paint:{"fill-color":INK,"fill-opacity":0.07}},
  {id:"park-line",type:"line",source:"omt","source-layer":"park",paint:{"line-color":INK,"line-opacity":0.35,"line-width":0.7}},
  {id:"water",type:"fill",source:"omt","source-layer":"water",paint:{"fill-color":INK,"fill-opacity":0.12}},
  {id:"water-line",type:"line",source:"omt","source-layer":"water",paint:{"line-color":INK,"line-opacity":0.5,"line-width":0.8}},
  {id:"waterway",type:"line",source:"omt","source-layer":"waterway",paint:{"line-color":INK,"line-opacity":0.4,"line-width":1}},
  {id:"building",type:"fill",source:"omt","source-layer":"building",minzoom:13,paint:{"fill-color":INK,"fill-opacity":["interpolate",["linear"],["zoom"],13,0.04,16,0.08]}},
  {id:"building-line",type:"line",source:"omt","source-layer":"building",minzoom:14,paint:{"line-color":INK,"line-opacity":["interpolate",["linear"],["zoom"],14,0.2,16,0.45],"line-width":0.6}},
  {id:"rail",type:"line",source:"omt","source-layer":"transportation",filter:["all",["==","class","rail"],["!=","brunnel","tunnel"]],paint:{"line-color":INK,"line-opacity":0.35,"line-width":1,"line-dasharray":[4,3]}},
  {id:"path",type:"line",source:"omt","source-layer":"transportation",minzoom:15,filter:["in","class","path","track"],paint:{"line-color":INK,"line-opacity":0.35,"line-width":0.8,"line-dasharray":[2,2]}},
  {id:"road-minor-casing",type:"line",source:"omt","source-layer":"transportation",filter:["all",["in","class","minor","service","pedestrian","living_street"],["!=","brunnel","tunnel"]],layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":INK,"line-opacity":0.55,"line-width":["interpolate",["linear"],["zoom"],13,1.2,16,5.5,18,12]}},
  {id:"road-main-casing",type:"line",source:"omt","source-layer":"transportation",filter:["all",["in","class","motorway","trunk","primary","secondary","tertiary"],["!=","brunnel","tunnel"]],layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":INK,"line-opacity":0.8,"line-width":["interpolate",["linear"],["zoom"],12,2,16,9,18,18]}},
  {id:"road-minor",type:"line",source:"omt","source-layer":"transportation",filter:["all",["in","class","minor","service","pedestrian","living_street"],["!=","brunnel","tunnel"]],layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":PAPER,"line-width":["interpolate",["linear"],["zoom"],13,0.4,16,3.8,18,9.5]}},
  {id:"road-main",type:"line",source:"omt","source-layer":"transportation",filter:["all",["in","class","motorway","trunk","primary","secondary","tertiary"],["!=","brunnel","tunnel"]],layout:{"line-cap":"round","line-join":"round"},paint:{"line-color":PAPER,"line-width":["interpolate",["linear"],["zoom"],12,0.8,16,6.5,18,14.5]}},
  {id:"road-label",type:"symbol",source:"omt","source-layer":"transportation_name",minzoom:14,filter:["!in","class","rail","path","service"],layout:{"symbol-placement":"line","text-field":["get","name"],"text-font":["Noto Sans Regular"],"text-size":["interpolate",["linear"],["zoom"],14,9.5,17,12],"text-letter-spacing":0.1,"text-transform":"uppercase","symbol-spacing":320},paint:{"text-color":"#6B5A58","text-halo-color":PAPER,"text-halo-width":1.6}},
  {id:"poi-station",type:"symbol",source:"omt","source-layer":"poi",minzoom:14,filter:["in","subclass","station","subway","subway_entrance"],layout:{"text-field":["get","name"],"text-font":["Noto Sans Bold"],"text-size":10,"text-transform":"uppercase","text-letter-spacing":0.08,"text-offset":[0,0.9],"text-anchor":"top"},paint:{"text-color":"#111111","text-halo-color":PAPER,"text-halo-width":1.4}},
  {id:"place-label",type:"symbol",source:"omt","source-layer":"place",filter:["in","class","suburb","neighbourhood","quarter","town","village"],layout:{"text-field":["get","name"],"text-font":["Noto Sans Bold"],"text-size":12,"text-transform":"uppercase","text-letter-spacing":0.14},paint:{"text-color":INK,"text-halo-color":PAPER,"text-halo-width":1.6}},
  {id:"city-label",type:"symbol",source:"omt","source-layer":"place",maxzoom:12,filter:["==","class","city"],layout:{"text-field":["get","name"],"text-font":["Noto Sans Bold"],"text-size":14,"text-transform":"uppercase","text-letter-spacing":0.16},paint:{"text-color":INK,"text-halo-color":PAPER,"text-halo-width":1.6}}
]};
function circlePoly(lat,lon,r){const pts=[];for(let i=0;i<=64;i++){const a=i/64*2*Math.PI;pts.push([lon+r/111320/Math.cos(lat*Math.PI/180)*Math.cos(a),lat+r/110540*Math.sin(a)]);}return {type:"Feature",geometry:{type:"Polygon",coordinates:[pts]}};}
function buildRealMap(container,opts){
  const here=state.where||VENUES[0];
  if(rmap){try{rmap.remove();}catch(e){}rmap=null;}rmarkers=[];
  rmap=new maplibregl.Map({container,style:RSTYLE,center:[here.lon,here.lat],zoom:15.4,minZoom:9,maxZoom:18.5,attributionControl:false});
  rmap.addControl(new maplibregl.AttributionControl({compact:true,customAttribution:"© OpenFreeMap © OpenMapTiles © OpenStreetMap"}),"bottom-right");
  rmap.on("load",()=>{
    if(state.where){rmap.addSource("ring",{type:"geojson",data:circlePoly(here.lat,here.lon,800)});rmap.addLayer({id:"ring",type:"line",source:"ring",paint:{"line-color":"#59211F","line-width":1.5,"line-dasharray":[3,3],"line-opacity":0.7}});}
  });
  if(opts&&opts.tap){rmap.on("click",e=>{state.where={lat:e.lngLat.lat,lon:e.lngLat.lng,label:"where you tapped"};opts.tap();});}
  if(state.where){const y=document.createElement("div");y.className="ryou";rmarkers.push(new maplibregl.Marker({element:y}).setLngLat([here.lon,here.lat]).addTo(rmap));}
  if(opts&&opts.pins){const top=new Set(opts.top||[]);const bounds=new maplibregl.LngLatBounds([here.lon,here.lat],[here.lon,here.lat]);
    for(const row of opts.pins){const e=document.createElement("div");
      if(!row.fits){e.className="rpin dim";e.title=row.p.name;}
      else{e.className="rpin"+(row.of.cat==="free"?" free":"")+(top.has(row.p.id)?" top":"");e.textContent=money(row.pr.price).replace(".00","");bounds.extend([row.p.lon,row.p.lat]);}
      if(row.fits&&opts.priced&&!opts.priced.has(row.p.id)){e.className="rpin small";e.textContent="";e.title=row.p.name+" · "+money(row.pr.price);}
      e.dataset.id=row.p.id;
      e.addEventListener("click",ev=>{ev.stopPropagation();if(opts.pick)opts.pick(row);else openSheet(row);});
      rmarkers.push(new maplibregl.Marker({element:e,anchor:"center"}).setLngLat([row.p.lon,row.p.lat]).addTo(rmap));}
    if(opts.pins.some(r=>r.fits))rmap.fitBounds(bounds,{padding:48,maxZoom:16,duration:0});}
  const ctl=document.createElement("div");ctl.className="mapctl";ctl.innerHTML='<button type="button" aria-label="Zoom in">+</button><button type="button" aria-label="Zoom out">−</button><button type="button" aria-label="Centre on me" style="font-size:12px">me</button>';
  const [bIn,bOut,bMe]=ctl.querySelectorAll("button");bIn.onclick=()=>rmap.zoomIn();bOut.onclick=()=>rmap.zoomOut();bMe.onclick=()=>rmap.flyTo({center:[here.lon,here.lat],zoom:15});
  container.parentElement.appendChild(ctl);
}


/* ---------- CLAUDE: inside claude.ai via sample, elsewhere via the API key ---------- */
let sampleFn=null;
async function askClaude(prompt,o){o=o||{};
  if(sampleFn&&!o.image){if(o.json)return sampleFn.json(prompt,{modelTier:"quick"});const r=await sampleFn(prompt,{modelTier:"quick",onText:o.onText});return r.text;}
  const key=getKey();if(!key)throw {code:o.image&&sampleFn?"no_vision":"no_key"};
  const content=o.image?[{type:"image",source:{type:"base64",media_type:"image/jpeg",data:o.image}},{type:"text",text:prompt}]:prompt;
  const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"content-type":"application/json","x-api-key":key,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:"claude-haiku-5-5",max_tokens:o.max||400,messages:[{role:"user",content}]})});
  if(!res.ok)throw {code:res.status===401?"not_granted":res.status===429?"rate_limited":"upstream_error"};
  const j=await res.json();const text=(j.content||[]).map(c=>c.text||"").join("");
  if(o.json){const m=text.match(/\{[\s\S]*\}/);try{return JSON.parse(m?m[0]:text);}catch(e){throw {code:"invalid_json"};}}return text;
}
function claudeAvailable(){return !!sampleFn||!!getKey();}
function claudeErr(e,fallback){return e&&e.code==="no_key"?(IN_CLAUDE?"Needs Claude: add an API key under Cards & apps.":"Snapping needs Claude. Type it instead →"):e&&e.code==="no_vision"?"Photos need the installed app with an API key. Type it instead →":e&&e.code==="not_granted"?"Claude wasn’t allowed here.":e&&e.code==="rate_limited"?"Too many asks. Try again in a minute.":e&&e.code==="invalid_json"?"Claude’s answer wasn’t readable. Try again.":fallback;}
function profileLine(){const t=selectedTime();return "The student"+(state.name?" ("+state.name+")":"")+" is at "+(state.where||VENUES[0]).label+", it is "+DAYS[t.day]+" "+fmt(t.minutes)+", cards: "+([...state.cards].map(cardName).join(", ")||"none")+", diet: "+([...state.diet].map(id=>(DIETS.find(d=>d.id===id)||{}).name).join(", ")||"none")+(state.note?", notes: "+state.note:"")+".";}
function wireAsk(d,r){
  const b=d.querySelector("#ask"),hint=d.querySelector("#askHint"),out=d.querySelector("#aiOut");if(!b)return;
  if(!claudeAvailable()){b.hidden=true;return;}b.hidden=false;
  b.onclick=async()=>{b.disabled=true;out.hidden=false;const lm=moment("loading",String(Date.now()));out.textContent=lm.line;const wasPose=(view.querySelector(".stage-rat")||{dataset:{}}).dataset.pose;ratPose(lm.pose);
    const top=r.fit.slice(0,5).map(x=>({name:x.p.name,price:x.pr.price,walkMin:x.walk,item:x.of.item,closes:x.o.closes||"",note:x.p.why||"",cardUsed:x.pr.label||"",dietNotes:x.ask.join("; ")}));
    const prompt="You help a student at "+(uniName()?uniName()+" in London":"a London university")+" decide where to eat. "+profileLine()+" They want "+[...state.cats].join(", ")+", have £"+state.budget+" and "+state.mins+" minutes.\nRanked options (cheapest first, all open and within reach):\n"+JSON.stringify(top)+"\n\nIn at most 3 short sentences, plain English, say which to pick and why, and name one alternative. If there are diet notes, remind them to ask staff. No bullet points, no preamble.";
    try{const text=await askClaude(prompt,{onText:({text})=>{out.textContent=text;}});out.textContent=text;}
    catch(e){out.textContent="";hint.textContent=claudeErr(e,"Claude didn’t answer. The ranking above still stands.");}
    finally{b.disabled=false;if(wasPose)ratPose(wasPose);}};
}
/* Mic on an input (Web Speech), and the one-line parse */
function wireSay(d,inp){
  const mic=d.querySelector("#mic");if(!mic)return;const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR||IN_CLAUDE)return;mic.hidden=false;let rec=null;const note=d.querySelector("#qNote");
  mic.onclick=()=>{if(rec){rec.stop();return;}rec=new SR();rec.lang="en-GB";rec.interimResults=true;mic.classList.add("live");if(note)note.textContent="Listening…";
    rec.onresult=e=>{let s="";for(const r of e.results)s+=r[0].transcript;inp.value=s;inp.dispatchEvent(new Event("input"));};
    rec.onerror=e=>{if(note)note.textContent=e.error==="not-allowed"||e.error==="service-not-allowed"?"The mic is blocked here. Allow it in the browser, or type.":"Didn’t catch that. Try again, or type.";};
    rec.onend=()=>{mic.classList.remove("live");rec=null;if(note&&note.textContent==="Listening…")note.textContent="";};
    try{rec.start();}catch(e){mic.hidden=true;}};
}
// "something hot and veggie, £4, back in 20 min" → filters. Returns {budgetGiven,minsGiven} or null if Claude failed (note set).
async function parseWish(text,note){
  const lm=moment("loading",String(Date.now()));note.textContent=lm.line;ratPose(lm.pose);const lb=view.querySelector(".bubble p");if(lb)lb.innerHTML=esc(lm.line);
  const prompt='A '+(uniName()||"London")+' student typed what they want to eat, possibly with typos, slang or Spanish words (fix them: "capuchino" is cappuccino, "pumkin spice late" is pumpkin spice latte, "sarnie" is sandwich). Turn it into JSON only, no prose: {"cats":[subset of "hot","deal","coffee","snack","sweet","free"] or null,"item":"the specific dish or drink they mean, spelled correctly, 1-3 words, chosen from this menu vocabulary when close: '+Object.values(SPECIFIC).flat().join(", ")+'; else null","budget":number in pounds or null,"mins":total minutes they have or null,"diet":[subset of "veg","vegan","gf","halal","df","nuts"] or null,"time":"HH:MM" 24h or null,"dayOffset":0-6 or null,"where":one of '+JSON.stringify(VENUES.map(v=>v.name))+' or null}. "hot" = hot food, "deal" = supermarket meal deal, "snack" = sandwiches, fruit, crisps, sushi rolls, "sweet" = cakes and doughnuts, "coffee" = any drink. Use null for anything not said. Text: "'+text.replace(/"/g,"'")+'"';
  try{const j=await askClaude(prompt,{json:true});
    if(Array.isArray(j.cats)&&j.cats.length)state.cats=new Set(j.cats.filter(c=>CATS.some(x=>x.id===c)));
    if(typeof j.item==="string"&&j.item.trim())state.q=j.item.trim();
    const bg=typeof j.budget==="number"&&j.budget>=0,mg=typeof j.mins==="number"&&j.mins>0;
    if(bg)state.budget=Math.min(10,Math.round(j.budget*2)/2);
    if(mg)state.mins=Math.max(10,Math.min(90,Math.round(j.mins/5)*5));
    if(Array.isArray(j.diet))for(const x of j.diet)if(DIETS.some(y=>y.id===x))state.diet.add(x);
    if(typeof j.time==="string"&&/^\d{1,2}:\d{2}$/.test(j.time))state.minute=hm(j.time);
    if(typeof j.dayOffset==="number")state.dayOff=Math.max(0,Math.min(6,j.dayOffset));
    if(typeof j.where==="string"){const v=VENUES.find(x=>x.name===j.where);if(v)state.where={lat:v.lat,lon:v.lon,label:v.name};}
    persist();note.textContent=state.q?"Looking for “"+state.q+"”.":"";return {budgetGiven:bg,minsGiven:mg};
  }catch(e){note.textContent=claudeErr(e,"Claude didn’t answer. Pick by hand and press Next again.");return null;}
}
/* "Snap a menu": photo → Claude vision → items under a fiver, added on this phone */
/* Snap a menu, in this order: where → which shop → photo → Claude checks the board against the shop → tick the items.
   Guards: prices £0.20–£15 only · the board's name must match the shop · far from the shop = "not verified yet" · 5 a day per phone. */
const TEACH_MAX=5;
function teachCount(){try{const j=JSON.parse(localStorage.getItem("fiver.teach")||"{}");const day=new Date().toISOString().slice(0,10);return j.d===day?(j.n||0):0;}catch(e){return 0;}}
function teachBump(){try{localStorage.setItem("fiver.teach",JSON.stringify({d:new Date().toISOString().slice(0,10),n:teachCount()+1}));}catch(e){}}
const NOISE=new Set(["the","a","cafe","café","coffee","bar","kitchen","london","ltd","and","&","shop","store","co","restaurant","bakery","deli","express","local","uk"]);
function nameKey(n){return String(n||"").toLowerCase().replace(/[’'`]/g,"").replace(/[^a-z0-9]+/g," ").trim().split(" ").filter(w=>w&&!NOISE.has(w));}
function nameMatch(a,b){const ka=nameKey(a),kb=nameKey(b);if(!ka.length||!kb.length)return true; // nothing readable on the board: can't contradict
  const ja=ka.join(""),jb=kb.join("");if(ja===jb||(ja.length>=3&&jb.includes(ja))||(jb.length>=3&&ja.includes(jb)))return true;
  return ka.some(w=>w.length>=4&&kb.some(v=>v===w||(v.length>=4&&lev(v,w)<=1)));}
function quietGeo(ms){return new Promise(res=>{let done=false;const end=v=>{if(!done){done=true;res(v);}};try{if(!navigator.geolocation)return end(null);setTimeout(()=>end(null),ms);
  navigator.geolocation.getCurrentPosition(p=>end({lat:p.coords.latitude,lon:p.coords.longitude}),()=>end(null),{enableHighAccuracy:true,timeout:ms,maximumAge:120000});}catch(e){end(null);}});}
const OSM_TAGS='[name][amenity~"^(cafe|restaurant|fast_food|bakery|pub|bar|food_court|ice_cream|juice_bar)$"]';
const OSM_SHOP='[name][shop~"^(bakery|convenience|supermarket|coffee|deli|tea|greengrocer|pastry|confectionery|chocolate|health_food|seafood|butcher|frozen_food)$"]';
async function osmShops(at,radius){ // cafés, restaurants, bakeries… around the point, from OpenStreetMap (only outside claude.ai)
  if(IN_CLAUDE||typeof fetch!=="function")return [];
  const q='[out:json][timeout:8];(nwr(around:'+radius+','+at.lat+','+at.lon+')'+OSM_TAGS+';nwr(around:'+radius+','+at.lat+','+at.lon+')'+OSM_SHOP+';);out center tags;';
  const ctl=typeof AbortController==="function"?new AbortController():null;const timer=ctl?setTimeout(()=>ctl.abort(),7000):null;
  try{const res=await fetch("https://overpass-api.de/api/interpreter",{method:"POST",body:"data="+encodeURIComponent(q),headers:{"Content-Type":"application/x-www-form-urlencoded"},signal:ctl?ctl.signal:undefined});
    const j=await res.json();return (j.elements||[]).map(e=>({name:e.tags&&e.tags.name,lat:e.lat!=null?e.lat:(e.center||{}).lat,lon:e.lon!=null?e.lon:(e.center||{}).lon,src:"osm"})).filter(x=>x.name&&x.lat!=null);}
  catch(e){return [];}finally{if(timer)clearTimeout(timer);}
}
const UCL_LL={lat:51.5245,lon:-0.1336};
const LONDON_BBOX="-0.51,51.28,0.33,51.70";
function abbrStreet(st){return String(st||"").replace(/\bRoad$/,"Rd").replace(/\bStreet$/,"St").replace(/\bAvenue$/,"Ave").replace(/\bSquare$/,"Sq").replace(/\bPlace$/,"Pl").replace(/\bGardens$/,"Gdns").replace(/\bLane$/,"Ln").replace(/\bTerrace$/,"Terr").replace(/\bCrescent$/,"Cres");}
const PHOTON_PLACE=new Set(["amenity","shop","railway","public_transport","tourism","leisure","office","building","craft","healthcare","station"]);
/* Photon (photon.komoot.io, OpenStreetMap) → rows {place:bool,name,sub,lat,lon}. Places (cafés, shops, stations) first, addresses after. */
function photonRows(j){const rows=[];
  for(const f of (j&&j.features)||[]){const p=f.properties||{},c=(f.geometry||{}).coordinates||[];if(c.length<2)continue;
    const street=p.housenumber&&p.street?p.housenumber+" "+abbrStreet(p.street):abbrStreet(p.street||"");
    const isPlace=!!p.name&&PHOTON_PLACE.has(p.osm_key)&&!["street","city","district","locality","county","state","country"].includes(p.type);
    const name=isPlace?p.name:(p.name||street||p.postcode||"");if(!name)continue;
    const sub=[isPlace?street:(p.name&&street&&street!==p.name?street:""),p.postcode||"",!p.postcode&&(p.district||p.city)?(p.district||p.city):""].filter(Boolean).join(", ");
    rows.push({place:isPlace,name:String(name).slice(0,48),sub,lat:c[1],lon:c[0]});}
  const seen=new Set();return rows.filter(r=>{const k=r.name+"|"+r.sub;if(seen.has(k))return false;seen.add(k);return true;}).sort((a,b)=>(b.place?1:0)-(a.place?1:0));
}
async function photon(q,bias){ // free, no key; London only; biased to the student's position
  if(IN_CLAUDE||typeof fetch!=="function")throw {code:"offline"};
  const u="https://photon.komoot.io/api/?q="+encodeURIComponent(q)+"&limit=8&lang=en&bbox="+LONDON_BBOX+"&lat="+bias.lat+"&lon="+bias.lon+"&zoom=14&location_bias_scale=0.5";
  const ctl=typeof AbortController==="function"?new AbortController():null;const timer=ctl?setTimeout(()=>ctl.abort(),6000):null;
  try{const res=await fetch(u,{signal:ctl?ctl.signal:undefined,headers:{"Accept":"application/json"}});if(!res.ok)throw {code:"offline"};return photonRows(await res.json());}
  catch(e){throw {code:"offline"};}finally{if(timer)clearTimeout(timer);}
}
async function osmLookup(name,near){try{const rows=await photon(name,near);return rows.find(r=>r.place&&metres(r,near)<=120)||null;}catch(e){return null;}}
/* No Claude? "Flat white £2.60, sausage roll £1.85" still parses: name + price per comma or line, category by keyword. */
const CAT_WORDS={coffee:/latte|coffee|tea\b|americano|cappuccino|flat white|espresso|mocha|chai|matcha|hot chocolate|juice|smoothie|drink|water|cola|coke|lemonade|cortado|macchiato/i,sweet:/cake|brownie|cookie|muffin|pastry|croissant|dessert|ice cream|doughnut|donut|bun\b|tart|flapjack|scone/i,hot:/soup|roll|pizza|pasta|curry|burger|wrap|toastie|jacket|rice|noodle|\bhot\b|bake|sausage|chicken|katsu|porridge|fries|wings|panini|bap|pie\b|stew|ramen|dumpling|gyoza|bowl/i};
const TAG_WORDS={pork:/sausage|bacon|ham\b|pork|salami|chorizo/i,meat:/chicken|beef|lamb|meat|burger|steak|turkey|duck/i,fish:/tuna|salmon|prawn|fish|cod\b|shrimp|crab/i,dairy:/latte|cappuccino|cheese|milk|flat white|mocha|cream|yogurt|butter|halloumi|mozzarella/i,gluten:/roll|bread|toast|sandwich|pasta|pizza|cake|croissant|pastry|bun\b|wrap|bap|panini|cookie|muffin|noodle/i,v:/veggie|vegetarian|\(v\)/i,vg:/vegan|\(ve\)|\(vg\)|plant/i};
function parseMenuText(text){const items=[];
  for(const part of String(text).split(/[\n,;•·]+/)){const m=part.match(/^\s*(.*?)\s*[-–:]?\s*£?\s*(\d+(?:[.,]\d{1,2})?)\s*(?:p\b)?\s*$/);if(!m||!m[1].trim())continue;
    let price=Number(m[2].replace(",","."));if(/\d+\s*p\s*$/i.test(part)&&price>=20)price=price/100;const name=m[1].replace(/^[-–•\s]+/,"").trim();
    const cat=Object.keys(CAT_WORDS).find(k=>CAT_WORDS[k].test(name))||"snack";const tags=Object.keys(TAG_WORDS).filter(k=>TAG_WORDS[k].test(name));
    items.push({item:name,price,cat,tags});}
  return {items};}
async function photonReverse(at,km){if(IN_CLAUDE||typeof fetch!=="function")return [];
  try{const res=await fetch("https://photon.komoot.io/reverse?lat="+at.lat+"&lon="+at.lon+"&radius="+km+"&limit=12&lang=en",{headers:{"Accept":"application/json"}});return photonRows(await res.json()).filter(r=>r.place);}catch(e){return [];}}
function wireMenu(d,place){
  const q=sel=>d.querySelector(sel);
  const file=q("#menuFile"),file2=q("#menuFile2"),note=q("#menuNote"),out=q("#menuOut"),atLine=q("#tAt"),find=q("#tFind"),check=q("#tCheck"),which=q("#tWhich"),shopAsk=q("#tShopAsk"),shopIn=q("#tShopIn"),near=q("#tNear");
  const inp=q("#tWhereIn"),list=q("#tWhereList"),clr=q("#tWhereClear"),wnote=q("#tWhereNote");
  const T={at:null,shop:null,via:"",items:null,board:""};const OFFLINE_MSG="Search works on the Fed for a Fiver website. Type the shop name instead.";
  const show=(id,on)=>{const e=q("#"+id);if(e)e.hidden=!on;};
  const canPhoto=claudeAvailable()&&!(sampleFn&&!getKey());
  const bias=()=>state.where||UCL_LL;
  // the three steps up top: done (wine + tick + summary) · current (wine, underlined) · pending (grey)
  const setStep=n=>{T.step=n;d.querySelectorAll(".trow .tst").forEach(b=>{const sn=Number(b.dataset.s);b.classList.toggle("cur",sn===n);b.classList.toggle("done",!!(sn<n||(sn===3&&T.sent)));b.disabled=sn>n;});
    ["t1","t2","t3"].forEach((id,k)=>show(id,k+1===n));
    q("#ts1").textContent=T.shop?T.shop.name:(T.at?T.at.label:"");q("#ts2").textContent=T.keep&&T.step>2?T.keep.length+" item"+(T.keep.length>1?"s":""):"";q("#ts3").textContent=T.sent?"sent":(T.via==="text"?"+3 crumbs":"+10 crumbs");};
  d.querySelectorAll(".trow .tst").forEach(b=>b.onclick=()=>{const sn=Number(b.dataset.s);if(T.sent||sn>=T.step)return;if(sn===1){atLine.hidden=true;find.hidden=false;inp.value="";wnote.textContent="";near.hidden=true;}setStep(sn);if(sn===1)inp.focus();});
  // --- 1 · where: fix the choice at the top, or ask for the shop's name when only an address was chosen ---
  const fixLine=()=>{const parts=[T.shop?'<b>'+esc(T.shop.name)+'</b>':'',T.at&&T.at.label&&(!T.shop||T.at.label!==T.shop.name)?esc(T.at.label):''].filter(Boolean);
    atLine.innerHTML=PIN+' '+parts.join(' · ');atLine.hidden=true;find.hidden=true;};
  const ready=()=>{shopAsk.hidden=true;fixLine();T.keep=null;T.sent=false;which.innerHTML="";check.textContent="";out.innerHTML="";setStep(2);
    const lock=!canPhoto||teachCount()>=TEACH_MAX;file.disabled=lock;if(file2)file2.disabled=lock;
    d.querySelectorAll("#tPhotoRow label").forEach(l=>l.hidden=!canPhoto);q("#tTypeBtn").hidden=!canPhoto;q("#tTypeBox").hidden=canPhoto;if(!canPhoto)q("#tTypeIn").focus();
    note.textContent=teachCount()>=TEACH_MAX?"Five a day is the limit. Even for rats. Back tomorrow.":canPhoto?"The board or the shelf label, close and straight. Or type it.":"Typing works. Photos are coming soon.";};
  const choosePlace=r=>{T.at={lat:r.lat,lon:r.lon,label:r.sub||r.name};T.shop={name:r.name,lat:r.lat,lon:r.lon,src:r.src||"photon",addr:r.sub||"",placeId:r.placeId||""};closeL();ready();};
  const chooseAddress=r=>{const ks=nameKey(abbrStreet(r.name)),st=new Set(nameKey(r.sub||""));const label=ks.length&&ks.every(w=>st.has(w))?r.sub:r.name+(r.sub?", "+r.sub:"");T.at={lat:r.lat,lon:r.lon,label};T.shop=null;closeL();fixLine();q("#ts1").textContent=label;shopAsk.hidden=false;shopIn.value="";shopIn.focus();};
  shopIn.oninput=()=>{const v=shopIn.value.trim();if(v.length>=2){T.shop={name:v.slice(0,40),lat:T.at.lat,lon:T.at.lon,src:"typed",addr:T.at.label};q("#ts1").textContent=T.shop.name;}else{T.shop=null;q("#ts1").textContent=T.at?T.at.label:"";}};
  shopIn.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();if(T.shop)ready();}};
  shopIn.onblur=()=>{if(T.shop&&T.step===1)setTimeout(()=>{if(T.shop&&T.step===1)ready();},150);};
  setStep(1);
  // suggestions: UCL buildings and stations instantly, Photon after a 300 ms pause (3 letters or more)
  let seq=0,timer=null,rows=[];
  const paintRows=(items,extra)=>{list.innerHTML=items.map((r,i)=>'<button type="button" data-i="'+i+'"><b>'+esc(r.name)+'</b>'+(r.sub?'<span class="meta">'+esc(r.sub)+'</span>':'')+'</button>').join("")+(extra||"")+(items.some(r=>r.src==="google")?'<div class="grp gpow">powered by Google</div>':'');rows=items;list.hidden=false;clr.hidden=false;};
  const localRows=qq=>VENUES.filter(v=>v.name.toLowerCase().includes(qq)||(v.addr||"").toLowerCase().includes(qq)).slice(0,4).map(v=>({place:true,name:v.name,sub:v.addr||"",lat:v.lat,lon:v.lon,src:"venue"}));
  const typedRow=qq=>'<button type="button" data-typed="1">Use “'+esc(qq)+'” as the shop name<span class="meta">near '+esc(bias().label||"UCL")+'</span></button>';
  const search=()=>{const raw=inp.value.trim(),qq=raw.toLowerCase();wnote.textContent="";if(qq.length<3){if(qq)paintRows(localRows(qq));else closeL();return;}
    const mine=++seq;const local=localRows(qq);paintRows(local,typedRow(raw));
    const paintAll=ph=>{const all=local.concat(ph.filter(r=>!local.some(l=>l.name===r.name))).sort((a,b)=>(b.place?1:0)-(a.place?1:0));paintRows(all,all.length?"":typedRow(raw));if(!all.length)wnote.textContent="Nothing called that in London.";};
    gpAutocomplete(raw,bias()).then(g=>{if(mine!==seq)return;paintAll(g);})
      .catch(()=>photon(raw,bias()).then(ph=>{if(mine!==seq)return;paintAll(ph);})
      .catch(()=>{if(mine!==seq)return;wnote.textContent=OFFLINE_MSG;paintRows(local,typedRow(raw));}));};
  const openL=()=>{if(inp.value.trim())search();};const closeL=()=>{list.hidden=true;clr.hidden=!inp.value;};
  inp.onfocus=openL;inp.oninput=()=>{clearTimeout(timer);timer=setTimeout(search,300);};inp.onblur=()=>setTimeout(closeL,180);
  clr.onclick=()=>{inp.value="";closeL();clr.hidden=true;wnote.textContent="";};
  inp.onkeydown=e=>{if(e.key==="Escape"){closeL();inp.blur();}if(e.key==="Enter"){e.preventDefault();clearTimeout(timer);const b=list.querySelector("button");if(b&&!list.hidden)b.click();else search();}};
  list.addEventListener("mousedown",e=>e.preventDefault());
  list.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
    if(b.dataset.typed){const nm=inp.value.trim().slice(0,40);const at=bias();T.at={lat:at.lat,lon:at.lon,label:at.label||"UCL"};T.shop={name:nm,lat:at.lat,lon:at.lon,src:"typed",addr:T.at.label};closeL();ready();return;}
    const r=rows[Number(b.dataset.i)];if(!r)return;
    if(r.src==="google"&&r.lat==null){b.innerHTML='<b>'+esc(r.name)+'</b><span class="meta">one sec…</span>';
      gpDetails(r.placeId).then(dt=>{const rr=Object.assign({},r,{lat:dt.lat,lon:dt.lon,sub:dt.addr||r.sub});if(rr.place)choosePlace(rr);else chooseAddress(rr);})
        .catch(()=>{wnote.textContent="Google didn’t answer. Try again, or type the shop name.";search();});return;}
    if(r.place)choosePlace(r);else chooseAddress(r);});
  // "Use my location": the shops within ~100 m, closest first
  q("#tGeo").onclick=async()=>{inp.value="";closeL();clr.hidden=true;wnote.textContent="Asking your phone…";near.hidden=true;const g=await quietGeo(6000);if(!g){wnote.textContent="Location is blocked here. Search instead.";return;}
    wnote.textContent="Looking 100 m around…";
    let found=PLACES.concat(state.added).map(p=>({place:true,name:p.name,sub:p.addr||"",lat:p.lat,lon:p.lon,src:"cat",m:Math.round(metres(g,p))})).filter(x=>x.m<=120);
    const gp=await gpNearby(g,100);for(const x of gp){if(!found.some(y=>nameMatch(y.name,x.name)&&nameKey(y.name).length))found.push(Object.assign({},x,{m:Math.round(metres(g,x))}));}
    const osm=gp.length?[]:await osmShops(g,100);for(const x of osm){if(!found.some(y=>nameMatch(y.name,x.name)&&nameKey(y.name).length))found.push({place:true,name:x.name,sub:"",lat:x.lat,lon:x.lon,src:"osm",m:Math.round(metres(g,x))});}
    if(!gp.length&&!osm.length){const rv=await photonReverse(g,0.1);for(const x of rv){const m=Math.round(metres(g,x));if(m<=120&&!found.some(y=>nameMatch(y.name,x.name)&&nameKey(y.name).length))found.push({...x,src:"photon",m});}}
    found.sort((a,b)=>a.m-b.m);found=found.slice(0,12);
    if(!found.length){wnote.textContent=IN_CLAUDE?OFFLINE_MSG:"Nothing listed within 100 m. Type the shop name.";chooseAddress({name:"your location",sub:"",lat:g.lat,lon:g.lon});return;}
    wnote.textContent="";near.innerHTML=found.map((r,i)=>'<button type="button" data-i="'+i+'"><b>'+esc(r.name)+'</b><span class="meta">'+r.m+' m'+(r.sub?' · '+esc(r.sub):'')+'</span></button>').join("")+'<button type="button" data-other="1">Somewhere else<span class="meta">type the shop name</span></button>';near.hidden=false;
    near.querySelectorAll("button").forEach(b=>b.onclick=()=>{near.hidden=true;if(b.dataset.other){chooseAddress({name:"your location",sub:"",lat:g.lat,lon:g.lon});return;}choosePlace(found[Number(b.dataset.i)]);});};
  if(place){T.at={lat:place.lat,lon:place.lon,label:place.addr||place.name};T.shop={name:place.name,lat:place.lat,lon:place.lon,src:"cat",addr:place.addr||""};ready();}
  // --- 2 · the menu: a photo (Claude reads it and checks the name on the board) or typed text (+3, not verified) ---
  const ITEM_SHAPE='"items":[{"item":"name","price":number in pounds,"cat":one of "hot","snack","coffee","sweet","deal","tags":[subset of "v","vg","gf","meat","pork","fish","dairy","egg","gluten","nuts"] you can tell from the name}]';
  const showItems=(items,odd,board)=>{T.board=board||"";check.textContent=(board?"The board says “"+board+"”. ":"")+(claudeAvailable()?"Claude read ":"Read ")+items.length+" item"+(items.length>1?"s":"")+(odd?" ("+odd+" skipped: under £0.20 or over £15)":"")+". Untick what’s wrong.";which.innerHTML="";note.textContent="";
    out.innerHTML='<div class="menuPrev">'+items.map((x,i)=>'<label><input type="checkbox" checked data-i="'+i+'">'+esc(x.item)+' · '+money(x.price)+(x.price<=5?'':' <span class="note">(over a fiver)</span>')+'</label>').join("")+'</div><div class="act" style="margin-top:8px">'+navNext("toSend","Send")+'</div><p class="note" id="tickNote"></p>';
    out.querySelector("#toSend").onclick=()=>{const keep=[...out.querySelectorAll("input:checked")].map(c=>items[Number(c.dataset.i)]);if(!keep.length){out.querySelector("#tickNote").textContent="Nothing ticked.";return;}T.keep=keep;sendScreen(keep,board);};};
  const sendScreen=(keep,board)=>{setStep(3);const sb=q("#sendBox");
    const needName=T.shop.src==="google"&&!(board&&nameMatch(board,T.shop.name)); // Google's name never goes into Fiver: the board's or the student's does
    const shown=needName?"":(board&&nameMatch(board,T.shop.name)&&T.shop.src==="google"?board:T.shop.name);
    const lk=nameKey(abbrStreet(T.at&&T.at.label||"")).filter(w=>!/^[a-z]{1,2}\d/.test(w)&&!/^\d[a-z]{2}$/.test(w)),nk=new Set(nameKey(abbrStreet(shown||"")));const showAddr=T.at&&T.at.label&&T.at.label!==shown&&!(lk.length&&lk.every(w=>nk.has(w)));
    sb.innerHTML='<p class="body"><b>'+esc(shown||"Name on the board")+'</b>'+(showAddr?' · '+esc(T.at.label):'')+'</p>'+
      (needName?'<input class="line" id="tNameIn" placeholder="Name as it is on the board" autocomplete="off" style="font-family:var(--body);font-style:normal;font-size:16px;margin-bottom:8px">':'')+
      '<div class="prices">'+keep.map(x=>'<div class="pr"><div>'+esc(x.item)+'</div><span class="ms wine" data-ms="'+money(x.price)+'" style="--ms:13px"></span></div>').join("")+'</div>'+
      '<p class="note">'+(T.via==="photo"?"Read by Claude from your photo. ":"Typed, so it goes in as “not verified yet”. ")+'Shows as “added by '+esc(firstName()||"you")+' · not verified yet”.</p>'+
      '<div class="act" style="margin-top:6px">'+navNext("menuAdd","Send to Fiver")+'</div><p class="note" id="menuSaved"></p>';msRender(sb);
    sb.querySelector("#menuAdd").onclick=async()=>{const btn=sb.querySelector("#menuAdd"),saved=sb.querySelector("#menuSaved");
      const typedName=needName?(sb.querySelector("#tNameIn").value||"").trim().slice(0,40):"";if(needName&&typedName.length<2){saved.textContent="Type the name as it is on the board.";return;}
      const finalName=needName?typedName:(board&&nameMatch(board,T.shop.name)&&T.shop.src==="google"?board:T.shop.name);
      btn.disabled=true;saved.textContent="Sending…";
      const here=await quietGeo(4000);const far=here?Math.round(metres(here,T.shop)):null;const nearby=T.via==="photo"&&far!=null&&far<=150;const pts=T.via==="photo"?10:3;
      let lat=T.shop.lat,lon=T.shop.lon,coordSource="manual",address=T.shop.src==="google"?"":(T.shop.addr||T.at.label||"");
      if(far!=null&&far<=150){lat=here.lat;lon=here.lon;coordSource="gps";}
      else if(T.shop.src==="osm"||T.shop.src==="photon")coordSource="osm";
      if(T.shop.src==="google"){const alt=await osmLookup(finalName,T.shop);if(alt){address=alt.sub||"";if(coordSource!=="gps"){lat=alt.lat;lon=alt.lon;coordSource="osm";}}else if(coordSource!=="gps")coordSource="google";}
      const offers=keep.map(x=>({cat:CATS.some(c=>c.id===x.cat)?x.cat:"snack",item:String(x.item).slice(0,60),price:Math.round(x.price*100)/100,status:"added",tags:Array.isArray(x.tags)?x.tags.filter(t=>typeof t==="string"):[]}));
      state.added.push({id:"menu-"+Date.now(),name:finalName,lat,lon,hoursUnknown:true,addr:address||T.shop.addr||T.at.label||"",status:"added",addedBy:firstName()||"you",nearby,via:T.via,placeId:T.shop.placeId||"",coordSource,offers,
        why:(T.via==="photo"?"Read by Claude from a photo"+(nearby?" taken on site":far!=null?" taken "+far+" m away":""):"Typed in by "+(firstName()||"a student"))+". Hours unknown. Not verified yet."});
      teachBump();persist();render();
      const everyone=await saveShared({kind:"menu",place_name:finalName,address,lat,lon,items:offers.map(x=>({item:x.item,price:x.price,cat:x.cat,diet:x.tags})),added_by:firstName()||"a student",place_id:T.shop.placeId||null,coord_source:coordSource});
      T.sent=true;setStep(3);btn.hidden=true;saved.textContent=(everyone?"Everyone nearby sees it. ":"Saved on this phone. ")+keep.length+" item"+(keep.length>1?"s":"")+" at "+finalName+" · not verified yet.";teachCelebrate(d,pts,"Cheers. That’s on the map now.");if(d.scrollTo)d.scrollTo({top:0,behavior:"smooth"});};};
  const cleanItems=j=>{const all=((j&&j.items)||[]).filter(x=>x&&typeof x.price==="number"&&x.item);const items=all.filter(x=>x.price>=0.2&&x.price<=15).slice(0,25);return {items,odd:all.length-items.length};};
  const onFile=async(input)=>{const f=input.files&&input.files[0];if(!f||!T.shop)return;
    if(teachCount()>=TEACH_MAX){note.textContent="Five a day is the limit. Even for rats. Back tomorrow.";input.value="";return;}
    note.textContent="Reading the board. Squinting…";teachFace(d,"f_sniff","Reading the board. Squinting…");out.innerHTML="";which.innerHTML="";check.textContent="";T.keep=null;T.via="photo";q("#ts3").textContent="+10 crumbs";
    try{const b64=await shrinkImage(f,1280);
      const prompt='This is a photo taken in London. First decide if it shows a menu, a menu board, a price list or shelf price labels. Reply with JSON only: {"isMenu":true or false,"place":"shop or café name if it appears anywhere in the photo, else \\"\\"",'+ITEM_SHAPE+'}. If it is not a menu or price list, reply {"isMenu":false,"place":"","items":[]}. Read prices carefully; if a price is unreadable, leave the item out. "hot" = hot food, "snack" = cold food, "coffee" = any drink, "sweet" = cakes and desserts.';
      const j=await askClaude(prompt,{json:true,image:b64,max:1400});
      if(!j||j.isMenu===false||!Array.isArray(j.items)||!j.items.length){check.textContent="That’s not a menu. Nice try.";teachFace(d,"f_sad","That’s not a menu. Nice try.");note.textContent="";return;}
      const {items,odd}=cleanItems(j);
      if(!items.length){check.textContent=odd?"Those prices don’t look right (under £0.20 or over £15). Not saved.":"Claude couldn’t read prices in that photo. Try closer, straighter, more light.";note.textContent="";return;}
      const board=String(j.place||"").slice(0,40);
      if(nameMatch(board,T.shop.name))showItems(items,odd,board);
      else{check.textContent="The board says "+board+", you picked "+T.shop.name+". Which is it?";teachFace(d,"f_oh","The board says "+board+", you picked "+T.shop.name+". Which is it?");note.textContent="";
        which.innerHTML='<button type="button" class="chip" id="wBoard">'+esc(board)+'</button><button type="button" class="chip" id="wPick">'+esc(T.shop.name)+'</button>';
        which.querySelector("#wBoard").onclick=()=>{T.shop={...T.shop,name:board,src:"board"};fixLine();showItems(items,odd,board);};which.querySelector("#wPick").onclick=()=>showItems(items,odd,board);}
    }catch(e){check.textContent=claudeErr(e,"Claude didn’t answer. Try again.");note.textContent="";}
    finally{input.value="";}};
  file.onchange=()=>onFile(file);if(file2)file2.onchange=()=>onFile(file2);
  q("#tTypeBtn").onclick=()=>{const box=q("#tTypeBox");box.hidden=!box.hidden;if(!box.hidden)q("#tTypeIn").focus();};
  q("#tTypeGo").onclick=async()=>{const text=q("#tTypeIn").value.trim();if(!text||!T.shop){note.textContent="Type the items and prices first.";return;}
    if(teachCount()>=TEACH_MAX){note.textContent="Five a day is the limit. Even for rats. Back tomorrow.";return;}
    if(!claudeAvailable()){note.textContent="";}
    const btn=q("#tTypeGo");btn.disabled=true;note.textContent="Sorting that out…";out.innerHTML="";which.innerHTML="";check.textContent="";T.keep=null;T.via="text";q("#ts3").textContent="+3 crumbs";
    try{const j=!claudeAvailable()?parseMenuText(text):await askClaude('A student typed items and prices from a menu at "'+T.shop.name.replace(/"/g,"")+'" in London. Reply with JSON only: {'+ITEM_SHAPE+'}. Keep only items with a clear price in pounds. "hot" = hot food, "snack" = cold food, "coffee" = any drink, "sweet" = cakes and desserts.\n\nTEXT:\n'+text.slice(0,2000),{json:true,max:1000});
      const {items,odd}=cleanItems(j);if(!items.length){check.textContent=odd?"Those prices don’t look right (under £0.20 or over £15). Not saved.":"Claude couldn’t find prices in that. Try “flat white £2.60, soup £3.20”.";note.textContent="";return;}
      showItems(items,odd,"");check.textContent="Typed, so it goes in as “not verified yet” (+3). A photo is +10.";}
    catch(e){check.textContent=claudeErr(e,"Claude didn’t answer. Try again.");note.textContent="";}
    finally{btn.disabled=false;}};
  d.__teach=T; // for tests
}
function shrinkImage(file,max){return new Promise((res,rej)=>{const img=new Image();const url=URL.createObjectURL(file);img.onload=()=>{const s=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement("canvas");c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);c.getContext("2d").drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);res(c.toDataURL("image/jpeg",0.82).split(",")[1]);};img.onerror=()=>rej({code:"bad_image"});img.src=url;});}
function wireEvents(d){
  const btn=d.querySelector("#evtBtn"),note=d.querySelector("#evtNote"),ta=d.querySelector("#evtText"),sel=d.querySelector("#evtVenue");
  sel.innerHTML=VENUES.map(v=>'<option value="'+v.id+'">'+esc(v.name)+'</option>').join("");
  if(!claudeAvailable()){btn.disabled=true;note.textContent="Reading invites needs Claude: add an API key under Cards & apps.";return;}
  btn.onclick=async()=>{const text=ta.value.trim();if(!text){note.textContent="Paste the event text first.";return;}btn.disabled=true;note.textContent="Checking every Pret in Bloomsbury… and the invite.";
    const venue=VENUES.find(v=>v.id===sel.value)||VENUES[0];
    const prompt='Read this event invite and reply with only a JSON object: {"freeFood": boolean, "what": string, "date": "YYYY-MM-DD" or "", "start": "HH:MM" or "", "end": "HH:MM" or "", "title": string}. freeFood is true only if food or drink is offered at no cost to attendees. Today is '+selectedTime().dateISO+'. If the end time is missing, use start + 2 hours.\n\nEVENT:\n'+text.slice(0,6000);
    try{const j=await askClaude(prompt,{json:true});
      if(!j||!j.freeFood){note.textContent="Claude read it: no free food mentioned. Not added.";}
      else if(!j.date||!j.start){note.textContent="Claude found food but no date or time. Add the date to the text and try again.";}
      else{const end=j.end||addHours(j.start,2);state.added.push({id:"add-"+Date.now(),name:j.title||"Event",lat:venue.lat,lon:venue.lon,when:{date:j.date,start:j.start,end},addr:venue.name,status:"added",offers:[{cat:"free",item:j.what||"free food",price:0,status:"added",tags:[]}],why:"Added from a pasted invite.",addedBy:firstName()||"you"});persist();ta.value="";render();
        const iso=(dt,hm)=>{const x=new Date(dt+"T"+hm+":00");return isNaN(x)?null:x.toISOString();};
        const everyone=await saveShared({kind:"event",place_name:(j.title||"Event").slice(0,48),address:venue.name,lat:venue.lat,lon:venue.lon,items:[{item:(j.what||"free food").slice(0,60),price:0,cat:"free",diet:[]}],starts_at:iso(j.date,j.start),ends_at:iso(j.date,end),added_by:firstName()||"a student",coord_source:"manual"});
        afterNote("#evtNote",(everyone?"Everyone nearby sees it. ":"Saved on this phone. ")+"Added: "+(j.what||"free food")+" on "+j.date+" at "+j.start+".");teachCelebrate(d,10);}
    }catch(e){note.textContent=claudeErr(e,"Claude didn’t answer. Try again later.");}
    finally{btn.disabled=false;}};
}
function afterNote(sel,text){const n=document.querySelector(sel);if(!n)return;n.textContent=text;const dt=n.closest("details");if(dt)dt.open=true;}
function addHours(hhmm,h){const m=hm(hhmm)+h*60;return String(Math.floor(m/60)%24).padStart(2,"0")+":"+String(m%60).padStart(2,"0");}

/* ---------- FOOT & BOOT ---------- */
const SOURCES='<p class="body">UCL outlet hours and addresses: the printed Food at UCL guide 2026/27 and the Food at UCL app.</p><p class="body">Chain prices: menus photographed in store (Pret, itsu, GAIL’s, Leon, Tortilla, Wasabi, atis, Costa) and UK price trackers, Oct 2026, takeaway. Sitting in can cost more.</p><p class="body">Meal deals: national press, Aug 2025. Shop addresses: store locators, Oct 2026.</p><p class="body">What students teach Fiver shows as “added by {name} · not verified yet” until someone checks it.</p><p class="body">Walking at 80 m/min; 6 minutes to eat on the go, 12 to sit down.</p><p class="body">Allergens change: always ask staff.</p>';
document.getElementById("foot").innerHTML='<div class="installBox"></div>';
if(DEMO.where){const v=VENUES.find(x=>x.id===DEMO.where);if(v){state.uni="ucl";state.where={lat:v.lat,lon:v.lon,label:v.name};state.setupDone=true;state.seenResults=true;state.step=S.results;}}
window.__fiver={state,render,rank,selectedTime,unlock,S,openMenu,openTeach,todayDeals,cardUnlocks,UI,addCrumbs,rankName,nameMatch,teachCount,photonRows,shared,loadShared,sharedPlace,ON_SITE,DEVICE_ID,DEMO,MOMENTS,moment,pickMoment,ART,ARTW,UNIS,UNI_LIST,uniPlaces,allPlaces,persist,openSheet,msRender,cardsFor,footText,isOpen,metres};
render();
(async()=>{try{if(window.claude&&claude.use){sampleFn=await claude.use("sample");}}catch(e){sampleFn=null;}if(state.step>=S.where)render();})();
