// Walks the whole flow in jsdom: welcome → where → results (chips) and the empty states.  npm i jsdom && node test/flow.test.js
const fs=require("fs");const {JSDOM}=require("jsdom");
const html=fs.readFileSync(__dirname+"/../index.html","utf8");
const dom=new JSDOM(html,{runScripts:"dangerously",pretendToBeVisual:true,url:"https://oliviagallego.github.io/fiver/"});
const w=dom.window,d=w.document;const errs=[];w.addEventListener("error",e=>errs.push(e.message||String(e.error)));w.console.error=(...a)=>errs.push(a.join(" "));w.confirm=()=>true;
const txt=sel=>{const el=d.querySelector(sel);return el?el.textContent.replace(/\s+/g," ").trim():"(none)";};
function step(name){const st=d.querySelector(".stage");console.log("\n=== "+name+" === step="+w.__fiver.state.step+" scene="+(st?st.dataset.scene:"-")+" pose="+(st?st.querySelector(".stage-rat").dataset.pose:"-"));console.log("line:",st?st.querySelector(".bubble p").dataset.line:"-");console.log("actions:",st?[...st.querySelectorAll(".act .btn, .act .linkbtn, .act .arrbtn")].map(b=>b.textContent.trim()).join(" | "):"-");console.log("chips on:",[...d.querySelectorAll("#catChips .cat-tile.on, #howChips .chip.on")].map(c=>c.textContent.trim()).join(" · "));console.log("said:",txt(".said-row"));if(errs.length){console.log("ERRORS:",errs);errs.length=0;}}
const F=()=>w.__fiver;let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log("FAIL:",m);}};
setTimeout(async()=>{try{
  console.log("HELLO line 1:",d.querySelector(".talk .bubble p").dataset.line,"| bubbles:",d.querySelectorAll(".bubble").length,"| nav:",!!d.querySelector("#prevLine"),!!d.querySelector("#nextLine"));
  d.querySelector("#nextLine").click();ok(F().state.intro===1,"› moves forward");d.querySelector("#prevLine").click();ok(F().state.intro===0,"‹ moves back");
  ok(d.querySelector(".talk .bubble p").dataset.line.startsWith("Hi, I’m Fiver. Yes, like the note."),"welcome opens with the note joke");
  F().state.intro=2;F().render();ok(!!d.querySelector("#nameIn")&&!!d.querySelector("#nameSkip"),"name input + Skip on line 3");d.querySelector("#nameIn").value="Olivia";d.querySelector("#nameGo").click();ok(F().state.intro===3,"name → cards line");
  ok(d.querySelector(".talk .bubble p").dataset.line.endsWith("Where do you study?")&&!!d.querySelector("#uniChips")&&!!d.querySelector("#uniSkip"),"line 4: Where do you study? with chips + Skip");
  ok(d.querySelector('#uniChips .chip[data-uni="ucl"]').classList.contains("on")&&d.querySelectorAll("#uniChips .chip").length===10,"UCL on by default, 10 chips (9 unis + Other)");
  d.querySelector('#uniChips .chip[data-uni="imperial"]').click();ok(F().state.uni==="imperial"&&F().state.where&&F().state.where.label.startsWith("South Kensington"),"Imperial → uni saved, where = South Kensington");
  d.querySelector('#uniChips .chip[data-uni="ucl"]').click();ok(F().state.uni==="ucl","back to UCL");d.querySelector("#uniGo").click();ok(F().state.intro===4,"uni → cards line");
  ok(d.querySelector(".talk .bubble p").dataset.line.startsWith("UCL. My home turf."),"Fiver's reply: UCL. My home turf.");
  console.log("line 5:",d.querySelector(".talk .bubble p").dataset.line,"| cards:",d.querySelectorAll("#cardChips label.chip").length,"+ more:",d.querySelectorAll("#moreChips label.chip").length);
  ok(d.querySelectorAll("#cardChips label.chip").length===6&&!!d.querySelector("#moreCards")&&!!d.querySelector("#cardsSkip"),"six cards + More… + Skip");
  d.querySelector("#moreCards").click();ok(!d.querySelector("#moreChips").hidden,"More… reveals the rest");
  d.querySelector("#cardsGo").click();ok(F().state.intro===5,"cards → sorted");ok(!d.querySelector("#dietChips"),"no diet step in the welcome");
  console.log("line 6:",d.querySelector(".talk .bubble p").dataset.line,"| follow me:",!!d.querySelector("#next"),"| lines:",txt(".talk-nav .meta"));
  d.querySelector("#next").click();
  step("where (after Follow me)");ok(F().state.step===F().S.where,"follow me → where");
  console.log("campus chips:",[...d.querySelectorAll("#campusChips .chip")].map(c=>c.textContent).join(" / "),"| map mounted:",!!d.querySelector("#mapbox1 svg"));
  const inp=d.querySelector("#venueIn");inp.dispatchEvent(new w.Event("focus"));ok(!d.querySelector("#venueList").hidden,"list opens on focus");inp.value="bart";inp.dispatchEvent(new w.Event("input"));
  console.log("list rows:",[...d.querySelectorAll("#venueList button")].map(b=>b.textContent).join(" / "));
  d.querySelector("#venueClear").click();ok(d.querySelector("#venueList").hidden,"list closes with ×");
  inp.dispatchEvent(new w.Event("focus"));inp.value="bart";inp.dispatchEvent(new w.Event("input"));d.querySelector('#venueList button[data-id="bartlett"]').click();step("results (search → tap)");ok(F().state.step===F().S.results,"venue → results");
  ok(!!d.querySelector("#catChips")&&!!d.querySelector("#howChips"),"filter chips present");
  // List · Map (P2.6): map view shows the big map, priced pins for the best 8, a tap puts that place in the card
  d.querySelector('.views button[data-view="map"]').click();await new Promise(r=>setTimeout(r,30));ok(F().UI.view==="map","map view on");ok(!!d.querySelector("#mapbox2.big svg"),"big map mounted");
  const priced=d.querySelectorAll("#mapbox2 .pin:not(.small):not(.dim)").length,small=d.querySelectorAll("#mapbox2 .pin.small").length;console.log("map pins priced:",priced,"small:",small,"| views:",txt(".views"));ok(priced<=8,"≤8 priced pins");
  console.log("mapCard:",txt("#mapCard").slice(0,160),"| ms:",[...d.querySelectorAll("#mapCard .ms")].map(e=>e.dataset.ms).join("/"));ok(d.querySelector("#mapCard .k")&&txt("#mapCard .k").includes("Fiver’s pick")&&[...d.querySelectorAll("#mapCard .ms")].some(e=>e.dataset.ms==="Walk there"),"card under the map with Walk there");
  const other=[...d.querySelectorAll("#mapbox2 .pin")].find(g=>g.dataset.id!==F().rank().fit[0].p.id);if(other){other.dispatchEvent(new w.Event("click"));console.log("tap:",other.getAttribute("class"),other.dataset.id,"→ card:",d.querySelector("#mapCard .hero").dataset.id,d.querySelector("#mapCard .hero").getAttribute("data-id"));ok(d.querySelector("#mapCard .hero").dataset.id===other.dataset.id,"tap pin → its card");ok(other.classList.contains("sel"),"tapped pin marked");}
  ok(!!d.querySelector("#catChips"),"filters stay on top in map view");
  d.querySelector('.views button[data-view="list"]').click();ok(F().UI.view==="list"&&!!d.querySelector("#seeAll"),"back to list");
  d.querySelector('#catChips .cat-tile[data-id="coffee"]').click();step("coffee added");ok(F().state.cats.has("coffee"),"coffee chip toggles");
  d.querySelector('#howChips button[data-b="3"]').click();step("£3");ok(F().state.budget===3,"budget chip");
  d.querySelector('#howChips button[data-m="15"]').click();step("15 min");ok(F().state.mins===15,"time chip");
  ok(txt("#laterChip")==="Now","Now chip");d.querySelector("#laterChip").click();ok(!d.querySelector("#laterBox").hidden,"Now ▾ opens the time");
  console.log("fit line:",txt("#fitLine"));ok(/\d+ places? fit · £3 · 15 min walk|Nothing fits yet · £3 · 15 min walk/.test(txt("#fitLine")),"fit line reads N places fit · £3 · 15 min walk");
  d.querySelector("#bOther").click();ok(!d.querySelector("#bBox").hidden,"Other opens the budget slider");const bR=d.querySelector("#bRange");bR.value="7.5";bR.dispatchEvent(new w.Event("input"));ok(txt("#bOther")==="£7.50"&&F().state.budget===7.5,"slider → chip shows £7.50");bR.dispatchEvent(new w.Event("change"));ok(txt("#bOther")==="£7.50"&&d.querySelector("#bOther").classList.contains("on"),"£7.50 chip stays on after render");
  d.querySelector("#mOther").click();const mR=d.querySelector("#mRange");mR.value="45";mR.dispatchEvent(new w.Event("input"));mR.dispatchEvent(new w.Event("change"));ok(F().state.mins===45&&txt("#mOther")==="45 min","time slider → 45 min");
  d.querySelector('#howChips button[data-b="3"]').click();d.querySelector('#howChips button[data-m="15"]').click();d.querySelector("#laterChip").click();
  d.querySelector('#dayChips button[data-off="1"]').click();step("tomorrow");ok(F().state.dayOff===1&&F().state.minute===720,"tomorrow noon");
  const tIn=d.querySelector("#timeIn");tIn.value="18:00";tIn.dispatchEvent(new w.Event("change"));console.log("when chip:",txt("#laterChip"));ok(txt("#laterChip")==="Tomorrow 18:00","chip shows Tomorrow 18:00");
  d.querySelector('#dayChips button[data-off="0"]').click();ok(txt("#laterChip")==="Today 18:00","chip shows Today 18:00");
  d.querySelector("#nowBtn").click();ok(F().state.dayOff===0&&F().state.minute===null,"back to now");
  d.querySelector("#specLink").click();ok(!d.querySelector("#specBox").hidden,"spec box reveals");
  d.querySelector("#qIn").value="cappuccino";d.querySelector("#qGo").click();await new Promise(r=>setTimeout(r,20));step("cappuccino");ok(F().state.q==="cappuccino","q applied");
  ok(txt("#specLink").includes("cappuccino"),"spec link shows q");
  ok(!d.querySelector(".said-row .said"),"no small 'change' next to the rat");ok(txt("#placeChip").includes("Bartlett"),"place is the first chip");
  d.querySelector("#placeChip").click();step("back to where via the place chip");ok(F().state.step===F().S.where,"place chip → where");
  d.querySelector("#home").click();step("logo → results");ok(F().state.step===F().S.results,"logo goes to results");
  // the pick with cards: Food at UCL voucher, closing-time window
  F().state.q="";F().state.cats=new w.Set(["sweet"]);F().state.budget=5;F().state.mins=30;F().state.dayOff=1;F().state.minute=14*60;F().state.cards=new w.Set(["foodatucl"]);F().render();step("sweet, Food at UCL card, tomorrow 2pm");
  F().state.cats=new w.Set(["snack","hot"]);F().state.where={lat:51.5235,lon:-0.1340,label:"Tottenham Court Rd"};F().state.minute=15*60+30;F().state.dayOff=1;F().render();step("Pret last hour (tomorrow 15:30, 67 TCR closes 16:00)");
  const r=F().rank();console.log("time rows:",r.fit.filter(x=>x.pr.time).slice(0,3).map(x=>x.p.name+" "+x.of.item+" £"+x.pr.price+" "+x.pr.label).join(" | "));ok(r.fit.some(x=>x.pr.time),"a last-hour price shows");
  F().state.seenResults=false;F().state.budget=5;F().state.mins=15;F().state.minute=12*60+30;F().state.dayOff=1;F().render();ok(d.querySelector(".bubble p").dataset.line==="Here’s what’s open near you. Change anything below, I’ll keep up.","first time in Results: the one-off line");
  F().render();ok(d.querySelector(".bubble p").dataset.line!=="Here’s what’s open near you. Change anything below, I’ll keep up.","then back to the usual joke");
  // universities: Imperial at South Kensington, King's at the Strand, Queen Mary at Mile End, City St George's at Clerkenwell (Thu 17:30 → the £3 dinner)
  const uniTry=(uni,label,budget,mins,minute)=>{const u=F().UNIS.find(x=>x.id===uni);const c=u.campuses[0];F().state.uni=uni;F().state.where={lat:c.lat,lon:c.lon,label:c.name};F().state.budget=budget;F().state.mins=mins;F().state.minute=minute;F().state.dayOff=1;F().state.cats=new w.Set(["hot","deal","free","coffee","snack","sweet"]);F().state.q="";F().render();const r=F().rank();console.log(label+":",r.fit.length,"fit |",r.fit.slice(0,4).map(x=>x.p.name+" "+x.of.item.slice(0,22)+" £"+x.pr.price).join(" | "),"| line:",d.querySelector(".bubble p").dataset.line);return r;};
  let ru=uniTry("imperial","Imperial SK £5/15",5,15,12*60+30);ok(ru.fit.some(x=>x.p.id.startsWith("uni-imp-"))&&ru.fit.some(x=>x.p.id.startsWith("cb-")),"Imperial: own outlets and chain branches fit");
  ok(!ru.fit.some(x=>x.p.id.startsWith("uni-kcl-")),"no King's-only prices for an Imperial student");
  ru=uniTry("kings","King's Strand £5/15",5,15,12*60+30);ok(ru.fit.some(x=>x.p.name==="Chapters"&&x.pr.price<=1.95),"King's: Chapters porridge/jacket for King's students");
  ru=uniTry("qmul","Queen Mary Mile End £5/15",5,15,12*60+30);ok(ru.fit.length>0,"Queen Mary: something near Mile End");
  ru=uniTry("citystgeorges","City St George's Clerkenwell Thu 17:30 £5/15",5,15,17*60+30);ok(ru.fit.some(x=>x.p.name.startsWith("The Bridge")&&x.pr.price===3),"City St George's: the £3 dinner at 17:30");
  // point 14: Imperial at South Kensington 12:30 shows the chains round the campus as well as its own cafés
  ru=uniTry("imperial","Imperial SK 12:30 £5/15",5,15,12*60+30);const names=new Set(ru.fit.map(x=>x.p.name+"|"+x.p.addr));
  ok([...names].some(n=>/^Pret\|.*Old Brompton/.test(n)),"Imperial SK: Pret Old Brompton Rd");ok([...names].some(n=>n.startsWith("Wasabi|")),"Imperial SK: Wasabi");ok([...names].some(n=>n.startsWith("Tesco Express|")),"Imperial SK: Tesco Express");
  ok(d.querySelector(".stage-foot").textContent==="Made for Imperial students · run by a rat with standards","foot follows the uni (Imperial)");
  F().state.uni="other";F().render();ok(d.querySelector(".stage-foot").textContent==="Made for London students · run by a rat with standards","foot for Other: London students");
  F().state.uni="lse";F().state.intro=4;F().state.step=F().S.hello;F().render();const lseCards=[...d.querySelectorAll("#cardChips label.chip")].map(x=>x.textContent.trim());console.log("LSE welcome cards:",lseCards.join(" · "));
  ok(lseCards.includes("Food Club by LSE")&&!lseCards.includes("Food at UCL app")&&lseCards.length===6&&!d.querySelector('#moreChips input[value="foodatucl"]'),"LSE: Food Club by LSE, no Food at UCL anywhere");
  ok(d.querySelector(".turn.me .note").textContent.includes("free with your uni email"),"cards note: uni email");
  F().state.uni="soas";F().render();ok([...d.querySelectorAll("#cardChips label.chip")].map(x=>x.textContent.trim()).includes("TOTUM"),"SOAS (no food app): TOTUM in the third slot");
  F().state.uni="kings";F().state.step=F().S.where;F().render();const camps=[...d.querySelectorAll("#campusChips .camp")];console.log("King's campuses:",camps.map(c=>c.querySelector("span").textContent+" ["+(c.querySelector("small")||{textContent:""}).textContent.slice(0,50)+"]").join(" | "),"| more:",!!d.querySelector("#moreCamps"));
  ok(camps.length===5&&camps[0].querySelector("small")&&/Arts & Humanities · The Dickson Poon School of Law · \+3 more/.test(camps[0].querySelector("small").textContent),"Where: faculties under the Strand (2 + more)");
  F().state.uni="imperial";F().render();d.querySelector("#moreCamps").click();ok(d.querySelectorAll("#campusChips .camp").length===7&&!d.querySelector("#moreCamps"),"Imperial: 5 campuses + '2 more' unfolds to 7");
  const bad=[...d.querySelectorAll("#campusChips .camp small")].filter(x=>/librar|café|microwave/i.test(x.textContent));ok(!bad.length,"no libraries or cafés listed as faculties");
  F().state.step=F().S.results;F().state.uni="ucl";ru=uniTry("imperial","UCL student at South Kensington",5,15,12*60+30);F().state.uni="ucl";F().render();const r2=F().rank();ok(!r2.fit.some(x=>x.p.id==="uni-imp-bakery"),"UCL student at Imperial: no student-only meal deal");F().state.uni="ucl";
  F().state.where={lat:51.5245,lon:-0.1336,label:"Main Quad / Wilkins"};F().state.cats=new w.Set(["hot","deal","free"]);
  // UCL East now has the Stratford chains (point 15): Marshgate Thu 12:30, £5 / 15 min → itsu, Pret, Greggs, GAIL's priced; the independents listed after them without a price
  F().state.where={lat:51.5392,lon:-0.0138,label:"UCL East · Marshgate"};F().state.budget=5;F().state.mins=15;F().state.minute=12*60+30;F().state.dayOff=1;F().state.cats=new w.Set(["hot","deal","free","coffee","snack","sweet"]);F().state.q="";F().render();step("Marshgate Thu 12:30 £5 / 15 min");
  { const r=F().rank();const nm=new Set(r.fit.map(x=>x.p.name));console.log("Marshgate fit:",r.fit.length,[...nm].join(", "),"| unpriced:",r.unpriced.map(x=>x.p.name+" "+x.walk+"m").join(", "));
    ok(["itsu","Pret","Greggs","GAIL’s"].every(n=>nm.has(n)),"Marshgate: itsu, Pret, Greggs and GAIL's fit");ok(!d.querySelector(".bubble p").dataset.line.startsWith("East London?"),"no tunnel line when there is data");
    ok(r.unpriced.length>=3&&r.unpriced.some(x=>x.p.name==="The Terrace Cafe")&&!r.fit.some(x=>x.p.unpriced),"independents listed unpriced, never in fit");
    ok(!r.fit.concat(r.rest,r.unpriced).some(x=>/Pool Street/.test(x.p.name)&&x.p.id.startsWith("cb-")),"Pool Street Café not duplicated");
    d.querySelector("#seeAll").click();const un=[...d.querySelectorAll("#unpriced .item.unp")];ok(un.length===r.unpriced.length&&un.every(b=>b.textContent.includes("Price not checked"))&&d.querySelector("#unpriced").compareDocumentPosition(d.querySelector("#fit"))&2,"unpriced rows after the priced list, 'Price not checked'");
    const lidl=r.unpriced.find(x=>x.p.name==="Lidl");ok(!!lidl&&!r.fit.some(x=>x.p.name==="Lidl"),"Lidl: no price, listed below");
    // Tortilla Stratford has no hours in the catalogue → "hours not checked"; a per-day window closes on the days it names
    const tort=F().allPlaces().find(p=>p.name==="Tortilla"&&p.uniBranch==="ucl:east");ok(!!tort&&tort.hoursUnknown,"Tortilla Stratford: hours not checked");
    const cj=F().allPlaces().find(p=>p.name==="Café Jikoni");ok(!!cj&&cj.hours.thu&&cj.hours.thu[1]==="22:00"&&F().isOpen(cj,{day:4,minutes:21*60,dateISO:""}).open&&!F().isOpen(cj,{day:3,minutes:21*60,dateISO:""}).open,"per-day hours: Jikoni open Thu 9pm, closed Wed 9pm");}
  // Canary Wharf: the app only offers today and tomorrow, so the weekend closures are checked on the places themselves (Sat 12:30)
  {const cw=F().allPlaces().filter(p=>p.uniBranch==="ucl:canary-wharf");const sat={day:6,minutes:12*60+30,dateISO:""};const shut=cw.filter(p=>!F().isOpen(p,sat).open);console.log("Canary Wharf:",cw.length,"branches,",shut.length,"closed on Saturday:",shut.map(p=>p.name+" "+p.addr).join(" | "));
    ok(shut.length>=4&&shut.every(p=>F().isOpen(p,sat).reason==="closed that day")&&shut.some(p=>p.name==="itsu"),"Canary Wharf: Sat-Sun closed respected (itsu Canada Place and the Prets)");
    const mid=F().allPlaces().find(p=>p.id.startsWith("cb-")&&p.hours&&p.hours.wk&&p.hours.wk[1]==="23:59");ok(!!mid&&F().isOpen(mid,{day:4,minutes:23*60,dateISO:""}).open,"'07:00-00:00' means open till midnight");}
  F().state.dayOff=1;
  // somewhere with nothing priced at all (Thamesmead): the tunnel line + Or try Main campus
  F().state.where={lat:51.50,lon:0.12,label:"Thamesmead"};F().render();ok(d.querySelector(".bubble p").dataset.line.startsWith("East London? I’m still digging the tunnel."),"far + nothing → tunnel line");ok(!!d.querySelector("#farTeach")&&!!d.querySelector("#farMain"),"Teach me a place there + Or try Main campus");
  d.querySelector("#farMain").click();ok(F().state.where.label.startsWith("Main Quad"),"Or try Main campus → quad");
  // Main Quad Thu 12:30: no Pret twice (the catalogue's branches that are already in PLACES are dropped)
  F().state.budget=5;F().state.mins=15;F().state.cats=new w.Set(["hot","deal","free","coffee","snack","sweet"]);F().render();{const r=F().rank();const all=r.fit.concat(r.rest);const prets=all.filter(x=>x.p.name==="Pret");const addrs=prets.map(x=>(x.p.addr||"").toLowerCase().replace(/street/,"st").replace(/road/,"rd").replace(/tottenham court/,"tottenham ct").split(",")[0]);
    console.log("Main Quad Prets:",prets.map(x=>x.p.id+" "+x.p.addr+" "+x.walk+"m").join(" | "));ok(new Set(addrs).size===addrs.length,"no Pret listed twice");
    const close=[];for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++)if(all[i].p.name===all[j].p.name&&F().metres(all[i].p,all[j].p)<40)close.push(all[i].p.name+" "+all[i].p.addr+" / "+all[j].p.addr);console.log("same chain <40 m:",close.join(" | ")||"none");ok(!close.length,"no same-chain pair within 40 m");}
  F().state.cats=new w.Set(["hot","deal","free"]);
  // empty states
  F().state.minute=3*60;F().state.budget=1;F().state.cats=new w.Set(["hot","deal","free"]);F().render();step("3am £1");
  F().state.budget=5;F().state.minute=null;F().state.dayOff=0;F().state.cats=new w.Set(["free"]);F().render();step("free only, now");
  F().state.cats=new w.Set(["hot"]);F().state.where={lat:51.5250,lon:-0.1319,label:"Bartlett"};F().state.minute=2*60;F().state.dayOff=1;F().render();step("2am tomorrow, hot");
  const tm=d.querySelector("#fixTm");console.log("Tomorrow 12:30 button:",!!tm);
  F().state.budget=1;F().state.mins=5;F().state.minute=12*60+30;F().state.dayOff=1;F().state.cats=new w.Set(["hot"]);F().render();step("£1 / 5 min at noon");
  const sug=[...d.querySelectorAll(".act .arrbtn .ms, .act .chip")].map(b=>b.dataset.ms||b.textContent).join(" | ");console.log("suggestions:",sug);ok(/(Try \d+ min|Up to £[\d.]+) · \d+ places?/.test(sug),"smallest change with a count");
  // Teach Fiver: 3 steps up top (Where · Menu · Send), Google-Maps-style search, menu by photo or text, Send screen
  F().state.where={lat:51.5245,lon:-0.1336,label:"Main Quad / Wilkins"};F().openTeach();await new Promise(r=>setTimeout(r,50));
  const sh=d.querySelector(".sheet.menu");ok(!!sh&&!d.querySelector("#tWhereIn").hidden,"teach opens on the search field");
  ok(d.querySelectorAll(".trow .tst").length===3&&d.querySelector('.trow .tst[data-s="1"]').classList.contains("cur")&&txt("#ts3")==="+10 crumbs"&&!d.querySelector('.trow .tst[data-s="3"]').classList.contains("done"),"3 steps in a row, Where current, Send pending, +10 crumbs");
  ok(!/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(d.body.textContent),"no emoji anywhere");
  ok(d.querySelector("#tWhereIn").placeholder==="Search a café, restaurant or address","one field, Google-Maps style");
  const ti=d.querySelector("#tWhereIn");ti.value="ioe";ti.dispatchEvent(new w.Event("input"));await new Promise(r=>setTimeout(r,400));
  console.log("search 'ioe' rows:",[...d.querySelectorAll("#tWhereList button")].map(b=>b.textContent).join(" / "),"| note:",txt("#tWhereNote"));
  ok(!!d.querySelector('#tWhereList button[data-i]'),"local building suggested instantly");ok(txt("#tWhereNote").includes("Search works on the Fed for a Fiver website"),"offline note, no 'Nothing listed'");
  d.querySelector('#tWhereList button[data-typed]').click();ok(sh.__teach.shop&&sh.__teach.shop.name==="ioe"&&!d.querySelector("#t2").hidden&&d.querySelector("#t1").hidden&&txt("#ts1")==="ioe","typed name → Where done (summary under the pin) → Menu step");
  ok(d.querySelector('.trow .tst[data-s="1"]').classList.contains("done")&&d.querySelector('.trow .tst[data-s="2"]').classList.contains("cur"),"step states: Where done, Menu current");
  d.querySelector('.trow .tst[data-s="1"]').click();ok(!d.querySelector("#t1").hidden&&d.querySelector("#t2").hidden,"tap a done step → back to it");
  ti.value="ioe";ti.dispatchEvent(new w.Event("input"));await new Promise(r=>setTimeout(r,400));d.querySelector('#tWhereList button[data-i]').click();
  ok(sh.__teach.shop&&sh.__teach.shop.name.includes("IOE")&&txt("#ts1").includes("IOE")&&!d.querySelector("#t2").hidden,"place row → name under Where, Menu step: "+txt("#ts1"));
  // no API key here: photos hidden, typing is the way; the plain parser reads "name £price"
  ok(d.querySelector("#tPhotoRow label").hidden&&!d.querySelector("#tTypeBox").hidden&&txt("#menuNote")==="Typing works. Photos are coming soon.","no key → photos hidden, typing first");
  d.querySelector("#tTypeIn").value="Flat white £2.60, sausage roll £1.85\nsoup of the day 3.20";d.querySelector("#tTypeGo").click();await new Promise(r=>setTimeout(r,80));
  console.log("typed →",[...d.querySelectorAll("#menuOut .menuPrev label")].map(l=>l.textContent).join(" / "),"| ts3:",txt("#ts3"));
  ok(d.querySelectorAll("#menuOut .menuPrev label").length===3&&txt("#ts3")==="+3 crumbs","typed menu parsed without Claude, +3 crumbs");
  d.querySelector("#toSend").click();ok(!d.querySelector("#t3").hidden&&d.querySelector('.trow .tst[data-s="3"]').classList.contains("cur")&&!!d.querySelector("#sendBox #menuAdd")&&txt("#ts2")==="3 items","Send screen: summary + Send to Fiver →");
  ok(!!d.querySelector("#evtOpen")&&d.querySelector("#evtBox").hidden,"invite is one line, closed");d.querySelector("#evtOpen").click();ok(!d.querySelector("#evtBox").hidden,"invite line opens the box");
  // address without a shop → ask for the shop name
  const pr=F().photonRows({features:[{geometry:{coordinates:[-0.1341,51.52]},properties:{osm_key:"highway",osm_value:"residential",type:"house",housenumber:"79",street:"Tottenham Court Road",postcode:"W1T 4TD"}},{geometry:{coordinates:[-0.134,51.521]},properties:{osm_key:"amenity",osm_value:"cafe",type:"house",name:"Costa Coffee",housenumber:"79",street:"Tottenham Court Road",postcode:"W1T 4TD"}},{geometry:{coordinates:[-0.1238,51.5308]},properties:{osm_key:"railway",osm_value:"station",type:"other",name:"King’s Cross",street:"Euston Road",postcode:"N1 9AL"}}]});
  ok(pr.length===3&&pr[0].place&&pr[0].name==="Costa Coffee"&&pr[0].sub==="79 Tottenham Court Rd, W1T 4TD"&&!pr[2].place&&pr[2].name==="79 Tottenham Court Rd","photon rows: places first, name + street + postcode");
  const nm=F().nameMatch;ok(nm("Pret A Manger","Pret")&&nm("PRET","Pret a Manger")&&nm("Greggs","greggs")&&nm("","Costa")&&nm("Sainsbury's","Sainsbury’s Local")&&!nm("Pret","Costa")&&!nm("Starbucks Coffee","Caffè Nero"),"name match rules");
  ok(F().teachCount()===0,"daily counter starts at 0");
  d.querySelector("#closeSheet").click();
  F().openMenu("cards");console.log("menu sections:",[...d.querySelectorAll(".sheet.menu details[id^=m-]")].map(x=>x.id).join(","),"cards:",d.querySelectorAll("#m-cards [data-cards] .chip").length,"| groups:",[...d.querySelectorAll(".sheet.menu .mgrp")].map(e=>e.textContent).join("·"));
  ok([...d.querySelectorAll(".sheet.menu .mgrp")].map(e=>e.textContent).join("·")==="You·Deals·Help"&&!!d.querySelector("#m-sources")&&!!d.querySelector("#m-crumbs"),"menu in You · Deals · Help with sources and crumbs");
  ok(!d.querySelector("#foot .estd")&&!d.querySelector("#foot").textContent.includes("UK price trackers"),"sources block gone from the screens");
  F().state.cats=new w.Set(["hot","deal","free"]);F().state.mins=30;F().state.minute=null;F().state.dayOff=0;F().render();d.querySelector('#howChips button[data-b="5"]').click(); // back to the demo defaults (persisted)
  // demo mode by URL: fixed time and place, invisible
  const dom3=new JSDOM(html,{runScripts:"dangerously",pretendToBeVisual:true,url:"https://oliviagallego.github.io/fiver/?at=2026-10-16T16:30&where=ioe",beforeParse(win){win.localStorage.setItem("fiver.v7",w.localStorage.getItem("fiver.v7"));}});
  await new Promise(r=>setTimeout(r,400));const f3=dom3.window.__fiver;const t3=f3.selectedTime();const r3=f3.rank();
  console.log("demo:",t3.label,"day",t3.day,"min",t3.minutes,"| where:",f3.state.where&&f3.state.where.label,"| pick:",r3.fit[0]&&r3.fit[0].p.name);
  ok(t3.day===5&&t3.minutes===16*60+30&&f3.state.where.label.startsWith("IOE")&&r3.fit[0]&&/Hackathon/.test(r3.fit[0].p.name)&&t3.isNow,"demo URL fixes Fri 16:30 at IOE → hackathon pizza");
  // uni outlet sheet: badge and price line name the university, not UCL
  F().state.uni="kings";const uK=F().UNIS.find(x=>x.id==="kings"),cK=uK.campuses[0];F().state.where={lat:cK.lat,lon:cK.lon,label:cK.name};F().state.cats=new w.Set(["hot","deal","free","coffee","snack","sweet"]);F().state.budget=5;F().state.mins=15;F().state.minute=12*60+30;F().state.dayOff=1;F().render();
  const rK=F().rank();const rowK=rK.fit.find(x=>x.p.id.startsWith("uni-kcl-"));if(rowK){F().openSheet(rowK);const sh=d.querySelector(".sheet");console.log("King's sheet:",sh.querySelector(".badge").textContent,"|",[...sh.querySelectorAll(".note")].map(n=>n.textContent).find(t=>t.startsWith("Price:")));
    ok(sh.querySelector(".badge").textContent==="King's food pages"&&!sh.textContent.includes("Food at UCL"),"King's outlet: badge names King's");d.querySelector("#sheetWrap").remove();}else ok(false,"a King's outlet fits at the Strand");
  F().state.uni="ucl";F().state.where={lat:51.5245,lon:-0.1336,label:"Main Quad / Wilkins"};F().state.cats=new w.Set(["hot","deal","free"]);F().render();
  const g8=d.querySelector('.ms .g img[style*="rotate"]');const digits=[...d.querySelectorAll(".ms .g img")];console.log("glyph imgs:",digits.length);
  { const box=d.createElement("div");const probe=d.createElement("span");probe.className="ms";probe.dataset.ms="SEE ALL 8";box.appendChild(probe);d.body.appendChild(box);F().msRender(box);const imgs=[...probe.querySelectorAll(".g img")];const hA=parseFloat(imgs[0].style.height.match(/\* ([\d.]+)/)[1]),h8=parseFloat(imgs[imgs.length-1].style.height.match(/\* ([\d.]+)/)[1]);
    console.log("glyph heights: S",hA,"8",h8);ok(h8>1.0&&Math.abs(h8-hA)<0.25,"the 8 is scaled to capital height");box.remove();}
  console.log("vytal unlocks:",F().cardUnlocks("vytal").slice(0,3).join(" · "));
  console.log("foodatucl unlocks:",F().cardUnlocks("foodatucl").slice(0,6).join(" · "));
  // reload with saved state lands on results
  const dom2=new JSDOM(html,{runScripts:"dangerously",pretendToBeVisual:true,url:"https://oliviagallego.github.io/fiver/",beforeParse(win){win.localStorage.setItem("fiver.v7",w.localStorage.getItem("fiver.v7"));}});
  setTimeout(()=>{console.log("\nreload step:",dom2.window.__fiver.state.step,"(results=2) where:",dom2.window.__fiver.state.where&&dom2.window.__fiver.state.where.label);ok(dom2.window.__fiver.state.step===2,"reload → results");
    if(errs.length)console.log("ERRORS END:",errs);console.log(fails?"\n"+fails+" FAILED":"\nALL OK");process.exit(fails?1:0);},300);
}catch(e){console.log("EXC",e.stack);process.exit(1);}},300);
