#!/usr/bin/env python3
"""Fiver build: joins src/ + data/ + img/ into one self-contained index.html (and dist/fiver-artifact.html for claude.ai).
Run from the repo root:  python3 build.py        (needs only the Python standard library)"""
import os, re, json, base64
ROOT=os.path.dirname(os.path.abspath(__file__))
P=lambda *a: os.path.join(ROOT,*a)
rd=lambda *a: open(P(*a),encoding='utf-8').read()
VERSION=str(int(rd('VERSION').strip())+1); open(P('VERSION'),'w').write(VERSION)  # auto-bump: every build is a new cache

# brand lettering: 85 glyph PNGs → MS table + renderer
F=json.load(open(P('data','glyphs.json')))
MSJS='const MS='+json.dumps({k:{'w':v['w'],'h':v['h'],'top':v['top'],'bot':v['bot'],'b64':v['b64']} for k,v in F['glyphs'].items()})+';\nconst MS_CAP='+str(F['capH'])+',MS_PAD='+str(F.get('pad',6))+';\n'+rd('src','glyphs.js')

# the rat: one SVG per pose, inlined as data URIs; ARTW = size on screen at 1x
def svgurl(svg): return "data:image/svg+xml,"+svg.replace('"',"'").replace('#','%23').replace('<','%3C').replace('>','%3E')
sizes=json.load(open(P('img','rat','sizes.json')))
ART={k:rd('img','rat',k+'.svg') for k in sizes}
ARTJS='const ART='+json.dumps({k:svgurl(v) for k,v in ART.items()})+';\nconst ARTW='+json.dumps(sizes)+';\n'

# food icons (the hands): PNGs → data URIs, in the order the app expects
order=json.load(open(P('img','icons','order.json')))
b64=lambda p: base64.b64encode(open(p,'rb').read()).decode()
ICONS='const ICONS={'+','.join(f'{k}:"data:image/png;base64,{b64(P("img","icons",k+".png"))}"' for k in order)+'};'

js=MSJS+"\n"+ARTJS+rd('src','data.js')+"\n"+rd('src','unis.js')+"\n"+ICONS+"\n"+rd('src','geom.js')+rd('src','pricing.js')+rd('src','rank.js')+rd('src','radar.js')+rd('src','shared.js')+rd('src','app.js')
shell=rd('src','shell.html').replace('WORDMARK_B64',b64(P('img','wordmark.png')))
out=shell.replace('/*STYLE*/\n',rd('src','style.css')).replace('/*SCRIPT*/\n',js)
open(P('index.html'),'w',encoding='utf-8').write(out)

# artifact variant for claude.ai: no doctype/head/body, no PWA tags
art=out.replace('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n','')
art=art.replace('</head>\n<body>\n','').replace('</body>\n</html>\n','')
art=re.sub(r'<!--PWA-->.*?<!--/PWA-->\n','',art,flags=re.S)
os.makedirs(P('dist'),exist_ok=True); open(P('dist','fiver-artifact.html'),'w',encoding='utf-8').write(art)
open(P('sw.js'),'w',encoding='utf-8').write(rd('src','sw.js').replace('{{VERSION}}',VERSION))
print('index.html',len(out.encode())//1024,'KB · sw.js cache fiver-v'+VERSION+' · dist/fiver-artifact.html',len(art.encode())//1024,'KB')
