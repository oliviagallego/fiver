"""claude/fiver-catalogo-unis.json → src/unis.js  (python3 tools/unis.py path/to/fiver-catalogo-unis.json)
   Universities, their campuses, their own outlets with the prices the catalogue states (never invented), and the chain branches
   near each campus (priced from the chain templates already in data.js). Google coordinates: cached_at / refresh_by kept."""
import json,re,sys,os
HERE=os.path.dirname(os.path.abspath(__file__));SRC=sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'..','data','fiver-catalogo-unis.json')
J=json.load(open(SRC,encoding='utf-8'))
DAYS=["mon","tue","wed","thu","fri","sat","sun"]
def t24(h,m,ap):
    h=int(h);m=int(m or 0)
    if ap:
        ap=ap.lower()
        if ap=="pm" and h<12:h+=12
        if ap=="am" and h==12:h=0
    return "%02d:%02d"%(h,m)
TIME=r'(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?'
RANGE=re.compile(TIME+r'\s*-\s*'+TIME,re.I)
def parse_hours(s):
    """'Mon-Fri 08:00-16:00, Sat 10am-4pm' → {wk,sat,sun} plus a key per weekday that differs from wk (null = closed that day); None when it can't be read."""
    if not s or not isinstance(s,str):return None
    s=s.replace('–','-').replace('—','-')
    if re.search(r'24\s*h',s,re.I):return {"wk":["00:00","23:59"],"sat":["00:00","23:59"],"sun":["00:00","23:59"]}
    day={}
    for seg in re.split(r'[;,]|\band\b(?=\s*(?:Sat|Sun|Mon|Tue|Wed|Thu|Fri))',s):
        seg=seg.strip()
        m=RANGE.search(seg)
        if not m:continue
        a=t24(m.group(1),m.group(2),m.group(3) or (m.group(6) if m.group(6) and int(m.group(1))<12 and int(m.group(1))>=7 else None));b=t24(m.group(4),m.group(5),m.group(6))
        if m.group(6) and not m.group(3) and int(m.group(1))<=int(m.group(4)) and m.group(6).lower()=="pm" and int(m.group(1))<8:a=t24(m.group(1),m.group(2),"pm")
        if b<=a:b="23:59"  # "07:00-00:00" closes at midnight
        head=seg[:m.start()].lower()
        if "daily" in head or "mon-sun" in head or "every day" in head or "7 days" in head or not re.search(r'mon|tue|wed|thu|fri|sat|sun',head):
            for d in DAYS:day.setdefault(d,[a,b])
            continue
        for dm in re.finditer(r'(mon|tue|wed|thu|fri|sat|sun)(?:\s*-\s*(mon|tue|wed|thu|fri|sat|sun))?',head):
            d1=DAYS.index(dm.group(1));d2=DAYS.index(dm.group(2)) if dm.group(2) else d1
            days=DAYS[d1:d2+1] if d2>=d1 else DAYS[d1:]+DAYS[:d2+1]
            for d in days:day.setdefault(d,[a,b])
    wkd=[tuple(day[d]) for d in DAYS[:5] if d in day]
    if not wkd:return None
    wk=list(max(set(wkd),key=wkd.count))
    out={"wk":wk}
    if "sat" in day:out["sat"]=day["sat"]
    if "sun" in day:out["sun"]=day["sun"]
    for d in DAYS[:5]:  # a weekday that differs from the usual (Tortilla Stratford: Tuesday only; a Monday that opens late)
        if d not in day:out[d]=None
        elif day[d]!=wk:out[d]=day[d]
    return out
CATS=[("deal",r'meal deal'),("coffee",r'coffee|tea\b|latte|juice|drink|chai|hot chocolate|bubble'),("sweet",r'cake|pastry|croissant|gelato|brownie|cookie|muffin|dessert|pudding|ice cream'),
      ("hot",r'soup|porridge|jacket|pizza|pasta|curry|katsu|burrito|bowl|wings|hot meal|hot food|bake|sausage|mash|stir-fry|wrap|panini|breakfast|wedges|slice|noodle|rice'),("snack",r'.')]
def cat_of(item):
    t=item.lower()
    for c,rx in CATS:
        if re.search(rx,t):return c
    return "snack"
TAGS=[("pork",r'sausage|bacon|ham\b|pork'),("meat",r'chicken|beef|lamb|meat|burger|steak|turkey|duck|bangers'),("fish",r'tuna|salmon|prawn|fish'),("dairy",r'cheese|milk|butter|latte|cappuccino|cream|yogurt'),("gluten",r'bread|roll|sandwich|pasta|pizza|cake|croissant|pastry|wrap|panini|cookie|muffin|noodle|baguette|ciabatta|pretzel|toastie|bake'),("vg",r'vegan|plant|\(ve\)|\(vg\)'),("v",r'veggie|vegetarian|\(v\)')]
def tags_of(item):
    t=item.lower();return [k for k,rx in TAGS if re.search(rx,t)]
OVER={ # the few windows the catalogue states in words
 "csg-bridge-food-court":{"hours":{"wk":["11:30","19:00"]},"item":{"Hot meal":{"from":"17:00","until":"19:00","cat":"hot","item":"£3 hot meal (Cost of Living Dinner, 5–7pm)"}}},
 "lse-bean-counter":{"item":{"Early bird":{"until":"09:30","cat":"deal"}}},"lse-beveridge":{"item":{"Early bird":{"until":"09:30","cat":"deal"}}},"lse-beavers-brew":{"item":{"Early bird":{"until":"09:30","cat":"deal"}}},"lse-plaza-cafe":{"item":{"Early bird":{"until":"09:30","cat":"deal"}}},
 "lse-garrick":{"item":{"Meal deal":{"until":"16:00","cat":"deal"}}},
 "qmul-curve-restaurant":{"item":{"Breakfast wrap":{"until":"10:30","cat":"hot"}}},
}
SKIP_ITEMS=re.compile(r'draught|pint|cocktail|beer|wine',re.I)
NOT_FAC=re.compile(r'librar|microwave|kitchen|caf[eé]|\bbar\b|shop|reception|residence|halls|office|not specified|teaching space|teaching location|teaching building|no single|per-school|bike|babylab|toddlerlab|gallery|cinema|great hall|lecture theatre|fridges|it help|administrat|research facilities|clinical teaching|mock-ward|listed as|professional services|students. union|study support|recitals|exhibitions|theatre space|restaurant|dawson hall',re.I)
def facs_of(lst):
    """campuses[].faculties → short names: no brackets, no 'Faculty of', nothing that is a library, a café or a hall of residence."""
    out=[]
    for f in lst or []:
        if not isinstance(f,str) or NOT_FAC.search(f):continue
        s=re.sub(r'\s*\([^)]*\)','',f)
        s=re.split(r'\s[-–]\s|:\s',s)[0].strip(' .;,')
        if not s:continue
        s=re.sub(r'^(Faculty of|Department of|College of|Institute of)\s+','',s,flags=re.I).strip()
        if len(s)>44:s=s[:42].rsplit(' ',1)[0]+'…'
        if s and s.lower() not in [x.lower() for x in out]:out.append(s)
    return out
CAMP_LABEL={"ucl:east":"UCL East · Marshgate","ucl:canary-wharf":"Canary Wharf · One Canada Sq"}
unis=[];places=[]
for u in J["unis"]:
    camps=[{"id":c["id"],"name":c["name"],"addr":(c.get("address","")+(", "+c["postcode"] if c.get("postcode") else "")).strip(", "),"lat":c["lat"],"lon":c["lon"],"main":bool(c.get("main")),"facs":facs_of(c.get("faculties"))} for c in u["campuses"] if c.get("lat") is not None and c.get("lon") is not None and c["id"]!="silwood-park"]
    for c in camps:c["name"]=CAMP_LABEL.get(u["id"]+":"+c["id"],c["name"])
    camps.sort(key=lambda c:(c["id"]!=u["default_campus"],not c["main"]))
    unis.append({"id":u["id"],"short":u["short"],"name":u["name"],"campuses":camps})
    cmap={c["id"]:c for c in camps}
    for o in u.get("outlets",[]):
        c=cmap.get(o.get("campus"))
        if not c:continue
        items=[x for x in (o.get("under_a_fiver") or []) if isinstance(x.get("price"),(int,float)) and x["price"]<=15 and not SKIP_ITEMS.search(x.get("item",""))]
        ov=OVER.get(o["id"],{})
        offers=[]
        for x in items:
            item=re.sub(r'\s*\([^)]*\)','',x["item"]).strip()  # the brackets hold the source notes
            of={"cat":cat_of(item),"item":item[:70],"price":round(float(x["price"]),2),"status":"uni","tags":tags_of(item)}
            for key,extra in ov.get("item",{}).items():
                if x["item"].startswith(key):of.update(extra)
            offers.append(of)
        aud=o.get("audience") or "open"
        # item-level audience: the catalogue's offers say who gets each price (porridge at King's is students-only, the fruit is for anyone)
        uoffers=u.get("offers",[])
        for of,x in zip(offers,items):
            key=" ".join(re.sub(r'[^a-z0-9 ]',' ',of["item"].lower()).split()[:2])
            hit=next((q for q in uoffers if key and key in re.sub(r'[^a-z0-9 ]',' ',q.get("text","").lower())),None)
            a=(hit or {}).get("audience") or ("uni_only" if "student" in x.get("item","").lower() else aud)
            if a=="uni_only":of["uniOnly"]=True
            if a=="unclear":of["check"]=True
        if offers and all(of.get("uniOnly") for of in offers):aud="uni_only"
        hours=ov.get("hours") or parse_hours(o.get("hours"))
        p={"id":"uni-"+o["id"],"name":re.sub(r'\s*\([^)]*\)|\s*-\s*Graysons','',o["name"]).strip()[:48],"lat":c["lat"],"lon":c["lon"],"addr":c["name"]+(", "+c["addr"].split(",")[0] if c["addr"] else ""),
           "status":"guide","uni":u["id"],"unis":[u["id"]],"audience":aud,"offers":offers,"why":u["short"]+"’s own food pages, Oct 2026."+(" Student price where it says so." if aud=="uni_only" else "")+(" Check at the till." if aud=="unclear" else "")}
        if hours:p["hours"]=hours
        else:p["hoursUnknown"]=True
        if not offers:p["unpriced"]=True
        places.append(p)
    # a free pantry is a FREE place at the main campus
    for of in u.get("offers",[]):
        if of["id"] in ("qmul-su-pantry",) and cmap.get(u["default_campus"]):
            c=cmap[u["default_campus"]]
            places.append({"id":"uni-"+of["id"],"name":"QMSU Food Pantry","lat":c["lat"],"lon":c["lon"],"addr":c["name"],"status":"guide","uni":u["id"],"unis":[u["id"]],"audience":"uni_only","hoursUnknown":True,"support":True,
                           "offers":[{"cat":"free","item":"Free food for short-term support (one of each item per visit)","price":0,"status":"uni","tags":[]}],"why":"QMSU Food Pantry: free, for students who need it. Hub hours; closed in holidays."})
# chain branches: every row of chain_branches (UCL campuses too). Priced chains clone a template in data.js (CHAIN); Blank Street, Lidl, Aldi and the
# independent cafés carry no price ("Price not checked. Snap the menu →"). Only the fields the app uses.
CHAIN={"pret":"pret-tcr67","greggs":"greggs-tcr","itsu":"itsu-tcr","wasabi":"wasabi-tcr","costa":"costa-tcr","starbucks":"starbucks-tcr","tesco_express":"tesco-goodge","sainsburys":"sains-tcr","coop":"coop-store","ms_food":"ms-tcr","tortilla":"tortilla-euston","caffe_nero":"nero-tpl",
       "gails":"gails-bayley","leon":"leon-euston","atis":"atis-kx","black_sheep":"bsc-goodge","boots":"boots-euston","waitrose":"waitrose-brunswick"}
def chain_name(chain,name):
    n=name or ""
    if chain=="pret":return "Pret"
    if chain=="caffe_nero":return "Nero Express" if "Express" in n else "Caffè Nero"
    if chain=="sainsburys":return "Sainsbury’s Local" if "Local" in n else "Sainsbury’s"
    if chain=="ms_food":return "M&S Simply Food" if "Simply" in n else "M&S Food"
    if chain=="waitrose":return "Little Waitrose" if "Little" in n else "Waitrose"
    if chain=="starbucks":return "Starbucks"
    if chain=="costa":return "Costa"
    if chain=="wasabi":return "Wasabi"
    if chain=="black_sheep":return "Black Sheep Coffee"
    if chain=="gails":return "GAIL’s"
    if chain=="leon":return "Leon"
    if chain=="tortilla":return "Tortilla"
    if chain=="tesco_express":return "Tesco Express"
    if chain=="coop":return "Co-op"
    if chain=="blank_street":return "Blank Street Coffee"
    return {"greggs":"Greggs","itsu":"itsu","atis":"atis","boots":"Boots","lidl":"Lidl","aldi":"Aldi"}.get(chain,n)
PC=re.compile(r'\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\b')
def postcode(a):
    m=PC.search(a or "");return (m.group(1)+" "+m.group(2)) if m else None
branches=[];seenB=set()
for b in J["chain_branches"]:
    if b.get("lat") is None or b.get("lon") is None:continue
    if not b.get("chain") and not b.get("independent"):continue  # 'Eastside Restaurant and Bar (Imperial)': a uni outlet, not a shop
    if b["place_id"] in seenB:continue  # the same shop listed for two campuses: one place, one id
    seenB.add(b["place_id"])
    addr=(b.get("address") or "").replace(", UK","").strip()
    segs=[x.strip() for x in re.split(r',',re.sub(r',?\s*London\b.*$','',addr)) if x.strip()]
    STREET=re.compile(r'\b(Rd|Road|St|Street|Sq|Square|Centre|Station|Pl|Place|Ln|Lane|Way|Walk|Row|Ave|Avenue|Market|Piazza|Circus|Hall|Cross|Hill|Gardens|Terrace|Yard|Wharf|Quay|Parade|Mall|Arcade|Green|Bridge)\b',re.I)
    short=next((x for x in segs if STREET.search(x) and not re.match(r'^(unit|u\d)',x,re.I)),None)
    if not short:short=", ".join(segs[:2]) if segs and (len(segs[0])<6 or re.match(r'^(unit\b|u\d|\d+[a-z]?$)',segs[0],re.I)) else (segs[0] if segs else "")
    if short and re.match(r'^(\d+[a-z]?|unit\b.*|u\d+\w*)$',short,re.I) and len(segs)>1:short=segs[0]+", "+segs[1]
    short=short.strip(" ,")
    row={"id":"cb-"+b["place_id"],"campus":b["campus"],"chain":b.get("chain"),"name":chain_name(b.get("chain"),b.get("name")),"addr":short,"pc":postcode(addr),"lat":b["lat"],"lon":b["lon"],"placeId":b["place_id"],"hours":parse_hours(b.get("hours"))}
    if b.get("chain") in CHAIN:row["tpl"]=CHAIN[b["chain"]]
    else:row["unpriced"]=True
    if b.get("independent"):row["independent"]=True
    branches.append(row)
js="/* Generated by tools/unis.py from claude/fiver-catalogo-unis.json (investigated 14/10/2026). Coordinates of chain branches are Google's: cached "+J["cached_at"]+", refresh by "+J["refresh_by"]+" via place_id. */\n"
js+="const UNIS_CACHED_AT="+json.dumps(J["cached_at"])+",UNIS_REFRESH_BY="+json.dumps(J["refresh_by"])+";\n"
js+="const UNIS="+json.dumps(unis,ensure_ascii=False)+";\n"
js+="const UNI_PLACES="+json.dumps(places,ensure_ascii=False)+";\n"
js+="const UNI_BRANCHES="+json.dumps(branches,ensure_ascii=False)+";\n"
open(os.path.join(HERE,'..','src','unis.js'),'w',encoding='utf-8').write(js)
print("unis",len(unis),"places",len(places),"priced",sum(1 for p in places if p["offers"]),"branches",len(branches),"priced",sum(1 for b in branches if b.get("tpl")),"unpriced",sum(1 for b in branches if b.get("unpriced")),"independent",sum(1 for b in branches if b.get("independent")),"| branch hours missing:",sum(1 for b in branches if not b["hours"]))
