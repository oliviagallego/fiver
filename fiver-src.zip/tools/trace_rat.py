"""How img/rat/*.svg were made: two-layer binary vectorisation of the cut sprites (cream silhouette + wine ink).
Input: one transparent PNG per pose, cut from the drawn sheets (ink #59211F, cream fill), in a folder `png/` next to this script.
Needs: pillow, numpy, scipy, vtracer. Output: svg/*.svg + assets10.json (name → {svg,w,h}); copy the svgs to img/rat/ and the sizes to img/rat/sizes.json."""
import os, re, json, sys
import numpy as np
from PIL import Image
from scipy import ndimage
import vtracer

HERE=os.path.dirname(os.path.abspath(__file__))
SRC=os.path.join(HERE,'png'); OUT=os.path.join(HERE,'svg'); os.makedirs(OUT,exist_ok=True)
TMP=os.path.join(HERE,'_t')

CREAM='#FFF7EB'; WINE='#59211F'; BLUR=1.3

def trace_bin(mask,tmp,lt,ct,fs):
    """mask: bool array (True = shape). Returns list of path d strings."""
    im=Image.fromarray(np.where(mask,0,255).astype('uint8')).convert('RGB')
    im.save(tmp+'.png')
    vtracer.convert_image_to_svg_py(tmp+'.png',tmp+'.svg',colormode='binary',mode='spline',
        filter_speckle=fs,corner_threshold=ct,length_threshold=lt,path_precision=0,
        splice_threshold=45,max_iterations=10,hierarchical='stacked')
    s=open(tmp+'.svg').read()
    out=[]
    for m in re.finditer(r'<path([^>]*)>',s):
        at=m.group(1);d=re.search(r' d="([^"]+)"',at).group(1)
        t=re.search(r'translate\(([-\d.]+),([-\d.]+)\)',at)
        if t:
            dx,dy=float(t.group(1)),float(t.group(2))
            toks=re.findall(r'[MLCZ]|-?\d+\.?\d*',d);o=[];i=0;cmd=None
            while i<len(toks):
                tk=toks[i]
                if tk in 'MLCZ':cmd=tk;o.append(tk);i+=1;continue
                x=float(tk)+dx;y=float(toks[i+1])+dy;o.append('%d %d'%(round(x),round(y)));i+=2
            d=' '.join(o).replace(' Z','Z')
        d=re.sub(r'(?<=[MLCZ]) ','',d)
        out.append(d)
    return out

def do(name,scale=2.0):
    im=Image.open(os.path.join(SRC,name+'.png')).convert('RGBA')
    w,h=im.size
    W,H=int(round(w*scale)),int(round(h*scale))
    big=im.resize((W,H),Image.LANCZOS)
    a=np.asarray(big).astype(float)
    al=ndimage.gaussian_filter(a[...,3],BLUR);gray=ndimage.gaussian_filter((a[...,0]+a[...,1]+a[...,2])/3,BLUR)
    alpha=al>127
    # ink = dark pixels inside the silhouette
    ink=alpha&(gray<140)
    sil=alpha
    sil2=ndimage.binary_erosion(ndimage.binary_dilation(sil,iterations=3),iterations=1)
    ps=trace_bin(sil2,TMP+'_s',14,140,20)
    pi=trace_bin(ink,TMP+'_i',4.0,70,4)
    svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d"><g fill="%s">%s</g><g fill="%s">%s</g></svg>'%(
        W,H,CREAM,''.join('<path d="%s"/>'%d for d in ps),WINE,''.join('<path d="%s"/>'%d for d in pi))
    svg=re.sub(r'\s+',' ',svg).replace('> <','><')
    open(os.path.join(OUT,name+'.svg'),'w').write(svg)
    return {'svg':svg,'w':int(round(W/scale)),'h':int(round(H/scale))}

LAM=['front','threeq','sniff','point','cheer','pizza','ticket','bag','sleep','walk1','walk2','walk3','walk4']
SEIS=['s_pockets','s_shrug','s_peek','s_follow','s_sign','s_sit']
ACC=['a_coffee','a_sandwich','a_apple','a_icecream','a_croissant','a_bubbletea','a_books','a_music','a_pizza','a_laptop','a_bags','a_map']
FACES={'f_neutral':'h01','f_smile':'h11','f_smug':'h08','f_laugh':'h16','f_hearts':'h25','f_wink':'h26','f_oh':'h14','f_sleep':'h18','f_sad':'h21','f_sniff':'h22','f_excited':'h13','f_tongue':'h24'}

if __name__=='__main__':
    only=sys.argv[1:]
    A={}
    jobs=[(n,n,2.0) for n in LAM]+[(n,n,1.5) for n in SEIS]+[(n,n,2.0) for n in ACC]+[(k,v,2.0) for k,v in FACES.items()]
    for key,src,sc in jobs:
        if only and key not in only:continue
        A[key]=do(src,sc) if src==key else None
        if A[key] is None:
            # face: rename source
            r=do(src,sc); os.replace(os.path.join(OUT,src+'.svg'),os.path.join(OUT,key+'.svg')); A[key]=r
        print(key,A[key]['w'],A[key]['h'],len(A[key]['svg'])//1024,'KB')
    if not only:
        json.dump(A,open(os.path.join(HERE,'..','assets10.json'),'w'))
        print('total KB',sum(len(v['svg']) for v in A.values())//1024,'n',len(A))
