"""Phone screenshots of the built index.html at the three test moments:
   Thu 12:30 Main Quad · Thu 23:30 Main Quad · Fri 16:30 IOE (the hackathon pizza must be the pick).
   python3 tools/shots.py <label>  → dist/shots/<label>-{thu1230,thu2330,fri1630}.png"""
import asyncio, os, sys
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
URL="file://"+os.path.join(HERE,"..","index.html")
OUT=os.path.join(HERE,"..","dist","shots"); os.makedirs(OUT,exist_ok=True)
LABEL=sys.argv[1] if len(sys.argv)>1 else "results"
FULL="--full" in sys.argv
VIEW="map" if "--map" in sys.argv else "list"   # --map → the Map view (point 6)
QUAD="{lat:51.5245,lon:-0.1336,label:'Main Quad / Wilkins'}"; IOE="{lat:51.5230,lon:-0.1279,label:'IOE, 20 Bedford Way'}"
SAVED="{cards:['unidays','beans','foodatucl'],cats:['hot','deal','free'],diet:[],budget:5,mins:30,name:'Olivia',note:'',where:"+QUAD+",added:[],setupDone:true}"
MOMENTS=[("thu1230","(4-new Date().getDay()+7)%7","12*60+30",QUAD),("thu2330","(4-new Date().getDay()+7)%7","23*60+30",QUAD),("fri1630","(5-new Date().getDay()+7)%7","16*60+30",IOE)]
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        pg=await b.new_page(viewport={"width":390,"height":844},device_scale_factor=2)
        pg.on("pageerror",lambda e:print("PAGEERROR",e))
        await pg.goto(URL); await pg.wait_for_timeout(1200)
        await pg.evaluate("localStorage.setItem('fiver.v7',JSON.stringify("+SAVED+"))")
        await pg.reload(); await pg.wait_for_timeout(1200)
        for name,day,minute,where in MOMENTS:
            await pg.evaluate("__fiver.state.where="+where+";__fiver.state.dayOff="+day+";__fiver.state.minute="+minute+";__fiver.state.cats=new Set(['hot','deal','free']);__fiver.UI.view='"+VIEW+"';__fiver.render()"); await pg.wait_for_timeout(3000)
            await pg.screenshot(path=f"{OUT}/{LABEL}-{name}.png",full_page=FULL)
            line=await pg.evaluate("(document.querySelector('.bubble p')||{}).dataset?.line||''")
            print(name,'|',line)
        await b.close()
asyncio.run(main())
